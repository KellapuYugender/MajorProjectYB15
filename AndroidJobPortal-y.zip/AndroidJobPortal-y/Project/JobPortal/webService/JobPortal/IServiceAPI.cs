﻿using System.Collections.Generic;

namespace JSONWebAPI
{
    public interface IServiceAPI
    {
        string Register(string firstName, string lastName, string emailId, string phoneNumber, string password, string summary);
        string UpdateUserDetails(string userId, string sscPercentage, string hscPercentage,
             string graduationPercentage, string postGraduationPercentage, string workExperience,
             string specialization, string cv);
        string Login(string emailId, string password);
        string GetProfile(string userId);
        string UpdateProfile(string userId, string firstName, string lastName, string phoneNumber, string summary);
        string ChangePassword(string userId, string oldPass, string newPass);
        string GetUserDetails(string userId);
        string AddUserSkills(string userId, string[] skillsArray);
        string GetUserSkills(string userId);
        string GetAllUserSkills();
        string AddUserApplicantion(string userId, string jobId, string dateOfApplication);
        string GetAllUserApplication();
        string GetUserApplicationByJobId(string jobId);
        string GetUserApplicationByUserId(string userId);
        string ViewFilteredJobs(string filterType, string filterValue);

        //////////////////////////////////////////FOR RECRUITER/////////////////////////////////////////

        string Recruiter(string firstName, string lastName, string emailId, string phoneNumber, string password, string summary);
        string RecruiterLogin(string emailId, string password);
        string GetRecruiterProfile(string recruiterId);
        string UpdateRecruiterProfile(string recruiterId, string firstName, string lastName, string phoneNumber, string summary);
        string ChangeRecruiterPassword(string recruiterId, string oldPass, string newPass);
        string AddCompany(string companyName, string companyDescription);
        string UpdateCompany(string companyId, string companyName, string companyDescription);
        string GetAllCompany();
        string GetCompanyById(string companyId);
        string AddJobPositions(string positionName, string description);
        string UpdateJobPositions(string jobPositionId, string positionName, string description);
        string GetAllJobPositions();
        string GetJobPositionsById(string jobPositionId);

        string AddJobs(string jobName, string description, string datePublished,
         string jobStartDate, string noOfVaccancy, string summary, string jobPositionId,
         string jobCategory, string jobPlatform, string companyId, string minExperience,
         string maxExperience, string recruiterId);
        string UpdateJobs(string jobId, string jobName, string description, string datePublished, string jobStartDate,
           string noOfVacancy, string summary, string jobPositionId, string jobCategory,
           string jobPlatform, string companyId, string minExperience, string maxExperience,
           string recruiterId);

        string DeleteJob(string jobId);
        string GetAllJobs();
        string GetJobByCompanyId(string companyId);
        string GetJobByPositionId(string jobPositionId);
        string AddJobDetails(string jobId, string sscPercentage, string hscPercentage,
            string graduationPercentage, string postGraduationPercentage,
            string specialization);
        string GetJobDetails(string jobId);
        string UpdateJobDetails(string jobId, string sscPercentage, string hscPercentage,
            string graduationPercentage, string postGraduationPercentage, string specialization);
        string AddJobSkillsRequirement(string jobId, string[] skillsArray);
        string GetJobSkillsRequirementSkills(string jobId);
        List<string> GetJobSkillsRequirementBySkill(string jobId, string[] skillsArray);
        string ViewAllApplicants(string status);
        string ViewFilteredApplicants(string filterType, string filterValue, string status);
        string ChangeUserApplicantStatus(string applicationId, string status);
        string AddChats(string userId, string recruiterId, string message,
            string sentBy, string dateTime);
        string GetChatList(string userId, string recruiterId);
        string GetUserNotification(string userId);
        string GetRecruiterNotification(string recruiterId);
        string AddNotification(string title, string message, string type,
              string userId);
    }
}