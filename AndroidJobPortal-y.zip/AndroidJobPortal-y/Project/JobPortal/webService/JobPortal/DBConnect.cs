﻿using System.Configuration;
using System.Data.SqlClient;

namespace JSONWebAPI
{
    public class DBConnect
    {

        private static SqlConnection NewCon = new SqlConnection(
            @"Data Source=SG2NWPLS14SQL-v09.shr.prod.sin2.secureserver.net;Initial Catalog=AJobportal;Persist Security Info=True;User ID=AJobportal;Password=~57p0ttB");

        public static SqlConnection getConnection()
        {
            return NewCon;
        }

        public DBConnect()
        {

        }

    }
}