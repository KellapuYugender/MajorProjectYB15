﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace JSONWebAPI
{
    public class ServiceAPI : IServiceAPI
    {
        SqlCommand cmd;
        JSONMaker jm = new JSONMaker();


        public string Register(string firstName, string lastName, string emailId, string phoneNumber, string password, string summary)
        {
            SqlConnection con = DBConnect.getConnection();
            string ans = "";

            try
            {
                SqlDataAdapter da = new SqlDataAdapter("Select userId from [Users] where emailId='" + emailId + "'", con);
                DataSet ds = new DataSet();
                da.Fill(ds);
                int count = ds.Tables[0].Rows.Count;
                if (count > 0)
                {
                    //already
                    ans = jm.Singlevalue("already");
                    return ans;
                }

                if (ans.Length == 0)
                {
                    string query = "Insert into [Users] values (@firstName,@lastName,@emailId,@phoneNumber,@password,@summary)";
                    cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@firstName", firstName);
                    cmd.Parameters.AddWithValue("@lastName", lastName);
                    cmd.Parameters.AddWithValue("@emailId", emailId);
                    cmd.Parameters.AddWithValue("@phoneNumber", phoneNumber);
                    cmd.Parameters.AddWithValue("@password", password);
                    cmd.Parameters.AddWithValue("@summary", summary);


                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();


                    ans = jm.Singlevalue("true");
                }

            }
            catch (Exception e)
            {
                con.Close();
                ans = jm.Error(e.Message);
            }

            return ans;
        }

        public string UpdateUserDetails(string userId, string sscPercentage, string hscPercentage,
            string graduationPercentage, string postGraduationPercentage, string workExperience,
            string specialization, string cv)
        {
            SqlConnection con = DBConnect.getConnection();
            string ans = "";

            try
            {
                SqlDataAdapter da = new SqlDataAdapter("Select userId from [UsersDetails] where userId='" + userId + "'", con);
                DataSet ds = new DataSet();
                da.Fill(ds);
                int count = ds.Tables[0].Rows.Count;
                if (count > 0)
                {
                    string query = "update [UsersDetails] set sscPercentage=@sscPercentage,hscPercentage=@hscPercentage,"
                        + "graduationPercentage=@graduationPercentage, postGraduationPercentage=@postGraduationPercentage,workExperience=@workExperience," +
                        "specialization=@specialization,cv=@cv "
                        + "where userId = '" + userId + "'";
                    cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@sscPercentage", sscPercentage);
                    cmd.Parameters.AddWithValue("@hscPercentage", hscPercentage);
                    cmd.Parameters.AddWithValue("@graduationPercentage", graduationPercentage);
                    cmd.Parameters.AddWithValue("@postGraduationPercentage", postGraduationPercentage);
                    cmd.Parameters.AddWithValue("@workExperience", workExperience);
                    cmd.Parameters.AddWithValue("@specialization", specialization);
                    cmd.Parameters.AddWithValue("@cv", cv);


                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();


                    ans = jm.Singlevalue("true");
                }
                else
                {
                    try
                    {
                        string query = "Insert into [UsersDetails] values (@userId,@sscPercentage,@hscPercentage,"
                        + "@graduationPercentage, @postGraduationPercentage, @specialization,"
                        + "@workExperience,@cv)";
                        cmd = new SqlCommand(query, con);
                        cmd.Parameters.AddWithValue("@userId", userId);
                        cmd.Parameters.AddWithValue("@sscPercentage", sscPercentage);
                        cmd.Parameters.AddWithValue("@hscPercentage", hscPercentage);
                        cmd.Parameters.AddWithValue("@graduationPercentage", graduationPercentage);
                        cmd.Parameters.AddWithValue("@postGraduationPercentage", postGraduationPercentage);
                        cmd.Parameters.AddWithValue("@specialization", specialization);
                        cmd.Parameters.AddWithValue("@workExperience", workExperience);
                        cmd.Parameters.AddWithValue("@cv", cv);


                        con.Open();
                        cmd.ExecuteNonQuery();
                        con.Close();


                        ans = jm.Singlevalue("true");

                    }
                    catch (Exception e)
                    {
                        con.Close();
                        ans = jm.Error(e.Message);
                    }
                }

            }
            catch (Exception e)
            {
                con.Close();
                ans = jm.Error(e.Message);
            }

            return ans;
        }

        public string Login(string emailId, string password)
        {
            SqlConnection con = DBConnect.getConnection();
            string ans = "";
            try
            {
                SqlDataAdapter da = new SqlDataAdapter("select * from [Users] where emailId='" + emailId + "' AND password='" + password + "'", con);
                DataSet ds = new DataSet();
                da.Fill(ds);
                int count = ds.Tables[0].Rows.Count;
                if (count > 0)
                {
                    ans = jm.Maker(ds);
                }
                else
                {
                    ans = jm.Singlevalue("false");
                }
            }
            catch (Exception e)
            {
                ans = jm.Error(e.Message);
            }
            return ans;
        }

        public string GetProfile(string userId)
        {
            string ans = "";
            SqlConnection con = DBConnect.getConnection();
            try
            {
                SqlDataAdapter da = new SqlDataAdapter("select * from [Users] where userId='" + userId + "'", con);
                DataSet ds = new DataSet();
                da.Fill(ds);
                int count = ds.Tables[0].Rows.Count;
                if (count > 0)
                {
                    ans = jm.Maker(ds);
                }
                else
                {
                    ans = jm.Singlevalue("no");
                }
            }
            catch (Exception e)
            {
                ans = e.Message;
            }
            return ans;
        }

        public string UpdateProfile(string userId, string firstName, string lastName, string phoneNumber, string summary)
        {
            SqlConnection con = DBConnect.getConnection();
            string ans = "";
            try
            {
                string query = "update [Users] set firstName=@firstName,lastName=@lastName,phoneNumber=@phoneNumber,summary=@summary where userId='" + userId + "'";
                cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@firstName", firstName);
                cmd.Parameters.AddWithValue("@lastName", lastName);
                cmd.Parameters.AddWithValue("@phoneNumber", phoneNumber);
                cmd.Parameters.AddWithValue("@summary", summary);

                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();

                ans = jm.Singlevalue("true");

            }
            catch (Exception e)
            {
                con.Close();
                ans = jm.Error(e.Message);
            }
            return ans;
        }

        public string ChangePassword(string userId, string oldPass, string newPass)
        {
            SqlConnection con = DBConnect.getConnection();
            string ans = "";
            try
            {
                SqlDataAdapter da = new SqlDataAdapter("select * from [Users] where password='" + oldPass + "' AND userId='" + userId + "'", con);
                DataSet ds = new DataSet();
                da.Fill(ds);
                int count = ds.Tables[0].Rows.Count;
                if (count > 0)
                {
                    cmd = new SqlCommand("update [Users] set password='" + newPass + "' where userId='" + userId + "'", con);
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();

                    //true
                    ans = jm.Singlevalue("true");
                }
                else
                {
                    //false
                    ans = jm.Singlevalue("false");
                }
            }
            catch (Exception e)
            {
                con.Close();
                ans = jm.Error(e.Message);
            }
            return ans;
        }

        public string GetUserDetails(string userId)
        {
            string ans = "";
            SqlConnection con = DBConnect.getConnection();
            try
            {
                SqlDataAdapter da = new SqlDataAdapter("select * from [UsersDetails] where userId='" + userId + "'", con);
                DataSet ds = new DataSet();
                da.Fill(ds);
                int count = ds.Tables[0].Rows.Count;
                if (count > 0)
                {
                    ans = jm.Maker(ds);
                }
                else
                {
                    ans = jm.Singlevalue("no");
                }
            }
            catch (Exception e)
            {
                ans = e.Message;
            }
            return ans;
        }

        public string AddUserSkills(string userId, string[] skillsArray)
        {
            SqlConnection con = DBConnect.getConnection();
            string ans = "";

            try
            {
                for (int i = 0; i < skillsArray.Length; i++)
                {
                    if (!skillsArray[i].Equals(""))
                    {
                        if (!skillsArray[i].Equals("null"))
                        {
                            SqlDataAdapter da = new SqlDataAdapter("Select userId from [UserSkills] where " +
                        "userId = '" + userId + "' AND " +
                        "skills = '" + skillsArray[i] + "'", con);
                            DataSet ds = new DataSet();
                            da.Fill(ds);
                            int count = ds.Tables[0].Rows.Count;
                            if (count > 0)
                            {
                                string queryDelete = "DELETE FROM [UserSkills] WHERE "
                                     + "userId = '" + userId + "' AND skills = '" + skillsArray[i] + "'";
                                cmd = new SqlCommand(queryDelete, con);
                                con.Open();
                                cmd.ExecuteNonQuery();
                                con.Close();
                            }

                            string query = "Insert into [UserSkills] values (@userId,@skills)";
                            cmd = new SqlCommand(query, con);
                            cmd.Parameters.AddWithValue("@userId", userId);
                            cmd.Parameters.AddWithValue("@skills", skillsArray[i]);


                            con.Open();
                            cmd.ExecuteNonQuery();
                            con.Close();


                            ans = jm.Singlevalue("true");

                        }
                        else
                        {
                            ans = jm.Singlevalue("no");
                        }

                    }
                    else
                    {
                        ans = jm.Singlevalue("no");
                    }
                }

            }
            catch (Exception e)
            {
                con.Close();
                ans = jm.Error(e.Message);
            }

            return ans;
        }
        public string GetUserSkills(string userId)
        {
            string ans = "";
            SqlConnection con = DBConnect.getConnection();
            try
            {
                SqlDataAdapter da = new SqlDataAdapter("select * from [UserSkills] where userId='"
                          + userId + "'", con);
                DataSet ds = new DataSet();
                da.Fill(ds);
                int count = ds.Tables[0].Rows.Count;
                if (count > 0)
                {
                    ans = jm.Maker(ds);
                }
                else
                {
                    ans = jm.Singlevalue("no");
                }
            }
            catch (Exception e)
            {
                ans = e.Message;
            }
            return ans;
        }
        public string GetAllUserSkills()
        {
            string ans = "";
            SqlConnection con = DBConnect.getConnection();
            try
            {
                SqlDataAdapter da = new SqlDataAdapter("select * from [UserSkills] ", con);
                DataSet ds = new DataSet();
                da.Fill(ds);
                int count = ds.Tables[0].Rows.Count;
                if (count > 0)
                {
                    ans = jm.Maker(ds);
                }
                else
                {
                    ans = jm.Singlevalue("no");
                }
            }
            catch (Exception e)
            {
                ans = e.Message;
            }
            return ans;
        }

        public string AddUserApplicantion(string userId, string jobId, string dateOfApplication)
        {
            SqlConnection con = DBConnect.getConnection();
            string ans = "";

            try
            {
                SqlDataAdapter da = new SqlDataAdapter("Select userId from [UserApplication] where " +
                    "jobId = '" + jobId + "' AND " +
                    "userId = '" + userId + "'", con);
                DataSet ds = new DataSet();
                da.Fill(ds);
                int count = ds.Tables[0].Rows.Count;
                if (count > 0)
                {
                    //already
                    ans = jm.Singlevalue("already");
                    return ans;
                }

                if (ans.Length == 0)
                {
                    string query = "Insert into [UserApplication] values (@userId,@jobId,@dateOfApplication,@status)";
                    cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@userId", userId);
                    cmd.Parameters.AddWithValue("@jobId", jobId);
                    cmd.Parameters.AddWithValue("@dateOfApplication", dateOfApplication);
                    cmd.Parameters.AddWithValue("@status", "Pending");


                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();


                    ans = jm.Singlevalue("true");
                }

            }
            catch (Exception e)
            {
                con.Close();
                ans = jm.Error(e.Message);
            }

            return ans;
        }

        public string GetAllUserApplication()
        {
            string ans = "";
            SqlConnection con = DBConnect.getConnection();
            try
            {
                SqlDataAdapter da = new SqlDataAdapter("select [UserApplication].*, " +
                    " (COALESCE([Users].firstName, '') + '' + COALESCE([Users].lastName, '')) " +
                    "As userName,[UsersDetails].* from [UserApplication] " +
                    "Left Join[Users] ON [UserApplication].userId = [Users].userId " +
                    "Left Join[UsersDetails] ON [UserApplication].userId = [UsersDetails].userId ", con);
                DataSet ds = new DataSet();
                da.Fill(ds);
                int count = ds.Tables[0].Rows.Count;
                if (count > 0)
                {
                    ans = jm.Maker(ds);
                }
                else
                {
                    ans = jm.Singlevalue("no");
                }
            }
            catch (Exception e)
            {
                ans = e.Message;
            }
            return ans;
        }

        public string GetUserApplicationByJobId(string jobId)
        {
            string ans = "";
            SqlConnection con = DBConnect.getConnection();
            try
            {
                SqlDataAdapter da = new SqlDataAdapter("select [UserApplication].*, " +
                    " (COALESCE([Users].firstName, '') + '' + COALESCE([Users].lastName, '')) " +
                    "As userName,[UsersDetails].* from[UserApplication] " +
                    "Left Join[Users] ON [UserApplication].userId = [Users].userId " +
                    "Left Join[UsersDetails] ON [UserApplication].userId = [UsersDetails].userId " +
                    "where jobId = '" + jobId + "'", con);
                DataSet ds = new DataSet();
                da.Fill(ds);
                int count = ds.Tables[0].Rows.Count;
                if (count > 0)
                {
                    ans = jm.Maker(ds);
                }
                else
                {
                    ans = jm.Singlevalue("no");
                }
            }
            catch (Exception e)
            {
                ans = e.Message;
            }
            return ans;
        }

        public string GetUserApplicationByUserId(string userId)
        {
            string ans = "";
            SqlConnection con = DBConnect.getConnection();
            try
            {
                SqlDataAdapter da = new SqlDataAdapter("select * from [UserApplication] where userId='"
                    + userId + "'", con);
                DataSet ds = new DataSet();
                da.Fill(ds);
                int count = ds.Tables[0].Rows.Count;
                if (count > 0)
                {
                    ans = jm.Maker(ds);
                }
                else
                {
                    ans = jm.Singlevalue("no");
                }
            }
            catch (Exception e)
            {
                ans = e.Message;
            }
            return ans;
        }

        public string ViewFilteredJobs(string filterType, string filterValue)
        {
            string ans = "";
            SqlConnection con = DBConnect.getConnection();
            try
            {
                SqlDataAdapter da;
                if (filterType.ToLower() == "all" || filterType == "" || filterType == "null")
                {
                    da = new SqlDataAdapter("select * from [Jobs] Left Join [Company] " +
                        "ON [Jobs].companyId = [Company].companyId Left Join [JobsPositions] " +
                        "ON [Jobs].jobPositionId = [JobsPositions].jobPositionId Left Join [JobDetails] " +
                        "ON [Jobs].jobId = [JobDetails].jobId", con);
                }
                else if (filterType.ToLower() == "skills")
                {
                    da = new SqlDataAdapter("select * from [Jobs] Left Join [Company] " +
                      "ON [Jobs].companyId = [Company].companyId Left Join [JobsPositions] " +
                      "ON [Jobs].jobPositionId = [JobsPositions].jobPositionId Left Join  [JobDetails]" +
                      "ON [Jobs].jobId = [JobDetails].jobId " +
                      "Left Join [JobSkillsRequirement] " +
                      "ON [Jobs].jobId = [JobSkillsRequirement].jobId " +
                      "where skills<> '" + filterValue + "'", con);
                }
                else if (filterType.ToLower() == "jobId")
                {
                    da = new SqlDataAdapter("select * from [Jobs] Left Join [Company] " +
                       "ON [Jobs].companyId = [Company].companyId Left Join [JobsPositions] " +
                       "ON [Jobs].jobPositionId = [JobsPositions].jobPositionId Left Join  [JobDetails] " +
                       "ON [Jobs].jobId = [JobDetails].jobId where [Jobs].jobId="
                   + "'" + filterValue + "'", con);
                }
                else
                {
                    da = new SqlDataAdapter("select * from [Jobs] Left Join [Company] " +
                        "ON [Jobs].companyId = [Company].companyId Left Join [JobsPositions] " +
                        "ON [Jobs].jobPositionId = [JobsPositions].jobPositionId Left Join  [JobDetails] " +
                        "ON [Jobs].jobId = [JobDetails].jobId where "
                    + filterType + "= '" + filterValue + "'", con);
                }
                DataSet ds = new DataSet();
                da.Fill(ds);
                int count = ds.Tables[0].Rows.Count;
                if (count > 0)
                {
                    ans = jm.Maker(ds);
                }
                else
                {
                    ans = jm.Singlevalue("no");
                }
            }
            catch (Exception e)
            {
                ans = e.Message;
            }
            return ans;
        }
            

        //////////////////////////////////////////FOR RECRUITER/////////////////////////////////////////

        public string Recruiter(string firstName, string lastName, string emailId, string phoneNumber, string password, string summary)
        {
            SqlConnection con = DBConnect.getConnection();
            string ans = "";

            try
            {
                SqlDataAdapter da = new SqlDataAdapter("Select recruiterId from [Recruiter] where emailId='" + emailId + "'", con);
                DataSet ds = new DataSet();
                da.Fill(ds);
                int count = ds.Tables[0].Rows.Count;
                if (count > 0)
                {
                    //already
                    ans = jm.Singlevalue("already");
                    return ans;
                }

                if (ans.Length == 0)
                {
                    string query = "Insert into [Recruiter] values (@firstName,@lastName,@emailId,@phoneNumber,@password,@summary)";
                    cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@firstName", firstName);
                    cmd.Parameters.AddWithValue("@lastName", lastName);
                    cmd.Parameters.AddWithValue("@emailId", emailId);
                    cmd.Parameters.AddWithValue("@phoneNumber", phoneNumber);
                    cmd.Parameters.AddWithValue("@password", password);
                    cmd.Parameters.AddWithValue("@summary", summary);


                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();


                    ans = jm.Singlevalue("true");
                }

            }
            catch (Exception e)
            {
                con.Close();
                ans = jm.Error(e.Message);
            }

            return ans;
        }

        public string RecruiterLogin(string emailId, string password)
        {
            SqlConnection con = DBConnect.getConnection();
            string ans = "";
            try
            {
                SqlDataAdapter da = new SqlDataAdapter("select * from [Recruiter] where emailId='" + emailId + "' AND password='" + password + "'", con);
                DataSet ds = new DataSet();
                da.Fill(ds);
                int count = ds.Tables[0].Rows.Count;
                if (count > 0)
                {
                    ans = jm.Maker(ds);
                }
                else
                {
                    ans = jm.Singlevalue("false");
                }
            }
            catch (Exception e)
            {
                ans = jm.Error(e.Message);
            }
            return ans;
        }

        public string GetRecruiterProfile(string recruiterId)
        {
            string ans = "";
            SqlConnection con = DBConnect.getConnection();
            try
            {
                SqlDataAdapter da = new SqlDataAdapter("select * from [Recruiter] where recruiterId='" + recruiterId + "'", con);
                DataSet ds = new DataSet();
                da.Fill(ds);
                int count = ds.Tables[0].Rows.Count;
                if (count > 0)
                {
                    ans = jm.Maker(ds);
                }
                else
                {
                    ans = jm.Singlevalue("no");
                }
            }
            catch (Exception e)
            {
                ans = e.Message;
            }
            return ans;
        }

        public string UpdateRecruiterProfile(string recruiterId, string firstName, string lastName, string phoneNumber, string summary)
        {
            SqlConnection con = DBConnect.getConnection();
            string ans = "";
            try
            {
                string query = "update [Recruiter] set firstName=@firstName," +
                    "lastName=@lastName,phoneNumber=@phoneNumber,summary=@summary " +
                    "where recruiterId='" + recruiterId + "'";
                cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@firstName", firstName);
                cmd.Parameters.AddWithValue("@lastName", lastName);
                cmd.Parameters.AddWithValue("@phoneNumber", phoneNumber);
                cmd.Parameters.AddWithValue("@summary", summary);


                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();

                ans = jm.Singlevalue("true");

            }
            catch (Exception e)
            {
                con.Close();
                ans = jm.Error(e.Message);
            }
            return ans;
        }

        public string ChangeRecruiterPassword(string recruiterId, string oldPass, string newPass)
        {
            SqlConnection con = DBConnect.getConnection();
            string ans = "";
            try
            {
                SqlDataAdapter da = new SqlDataAdapter("select * from [Recruiter] where password='" + oldPass + "' AND recruiterId='" + recruiterId + "'", con);
                DataSet ds = new DataSet();
                da.Fill(ds);
                int count = ds.Tables[0].Rows.Count;
                if (count > 0)
                {
                    cmd = new SqlCommand("update [Recruiter] set password='" + newPass + "' where recruiterId='" + recruiterId + "'", con);
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();

                    //true
                    ans = jm.Singlevalue("true");
                }
                else
                {
                    //false
                    ans = jm.Singlevalue("false");
                }
            }
            catch (Exception e)
            {
                con.Close();
                ans = jm.Error(e.Message);
            }
            return ans;
        }

        public string AddCompany(string companyName, string companyDescription)
        {
            SqlConnection con = DBConnect.getConnection();
            string ans = "";

            try
            {
                SqlDataAdapter da = new SqlDataAdapter("Select companyId from [Company] where companyName='" + companyName + "'", con);
                DataSet ds = new DataSet();
                da.Fill(ds);
                int count = ds.Tables[0].Rows.Count;
                if (count > 0)
                {
                    //already
                    ans = jm.Singlevalue("already");
                    return ans;
                }

                if (ans.Length == 0)
                {
                    string query = "Insert into [Company] values (@companyName,@companyDescription)";
                    cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@companyName", companyName);
                    cmd.Parameters.AddWithValue("@companyDescription", companyDescription);


                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();


                    ans = jm.Singlevalue("true");
                }

            }
            catch (Exception e)
            {
                con.Close();
                ans = jm.Error(e.Message);
            }

            return ans;
        }

        public string UpdateCompany(string companyId, string companyName, string companyDescription)
        {
            SqlConnection con = DBConnect.getConnection();
            string ans = "";


            try
            {
                SqlDataAdapter da = new SqlDataAdapter("select * from [Company] where companyId='" + companyId + "'", con);
                DataSet ds = new DataSet();
                da.Fill(ds);
                int count = ds.Tables[0].Rows.Count;
                if (count > 0)
                {
                    string query = "update [Company] set companyName=@companyName,companyDescription=@companyDescription where companyId='" + companyId + "'";
                    cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@companyName", companyName);
                    cmd.Parameters.AddWithValue("@companyDescription", companyDescription);

                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();


                    ans = jm.Singlevalue("true");
                }
            }
            catch (Exception e)
            {
                con.Close();
                ans = jm.Error(e.Message);
            }

            return ans;
        }

        public string GetAllCompany()
        {
            string ans = "";
            SqlConnection con = DBConnect.getConnection();
            try
            {
                SqlDataAdapter da = new SqlDataAdapter("select * from [Company]", con);
                DataSet ds = new DataSet();
                da.Fill(ds);
                int count = ds.Tables[0].Rows.Count;
                if (count > 0)
                {
                    ans = jm.Maker(ds);
                }
                else
                {
                    ans = jm.Singlevalue("no");
                }
            }
            catch (Exception e)
            {
                ans = e.Message;
            }
            return ans;
        }

        public string GetCompanyById(string companyId)
        {
            string ans = "";
            SqlConnection con = DBConnect.getConnection();
            try
            {
                SqlDataAdapter da = new SqlDataAdapter("select * from [Company] where companyId = " + companyId, con);
                DataSet ds = new DataSet();
                da.Fill(ds);
                int count = ds.Tables[0].Rows.Count;
                if (count > 0)
                {
                    ans = jm.Maker(ds);
                }
                else
                {
                    ans = jm.Singlevalue("no");
                }
            }
            catch (Exception e)
            {
                ans = e.Message;
            }
            return ans;
        }

        public string AddJobPositions(string positionName, string description)
        {
            SqlConnection con = DBConnect.getConnection();
            string ans = "";

            try
            {
                SqlDataAdapter da = new SqlDataAdapter("Select jobPositionId from [JobsPositions] where " +
                    "positionName='" + positionName + "'", con);
                DataSet ds = new DataSet();
                da.Fill(ds);
                int count = ds.Tables[0].Rows.Count;
                if (count > 0)
                {
                    //already
                    ans = jm.Singlevalue("already");
                    return ans;
                }

                if (ans.Length == 0)
                {
                    string query = "Insert into [JobsPositions] values (@positionName,@description)";
                    cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@positionName", positionName);
                    cmd.Parameters.AddWithValue("@description", description);


                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();


                    ans = jm.Singlevalue("true");
                }

            }
            catch (Exception e)
            {
                con.Close();
                ans = jm.Error(e.Message);
            }

            return ans;
        }

        public string UpdateJobPositions(string jobPositionId, string positionName, string description)
        {
            SqlConnection con = DBConnect.getConnection();
            string ans = "";


            try
            {
                SqlDataAdapter da = new SqlDataAdapter("select * from [JobsPositions] where jobPositionId='" + jobPositionId + "'", con);
                DataSet ds = new DataSet();
                da.Fill(ds);
                int count = ds.Tables[0].Rows.Count;
                if (count > 0)
                {
                    string query = "update [JobsPositions] set positionName=@positionName,description=@description where jobPositionId='" + jobPositionId + "'";
                    cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@positionName", positionName);
                    cmd.Parameters.AddWithValue("@description", description);

                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();


                    ans = jm.Singlevalue("true");
                }
            }
            catch (Exception e)
            {
                con.Close();
                ans = jm.Error(e.Message);
            }

            return ans;
        }

        public string GetAllJobPositions()
        {
            string ans = "";
            SqlConnection con = DBConnect.getConnection();
            try
            {
                SqlDataAdapter da = new SqlDataAdapter("select * from [JobsPositions]", con);
                DataSet ds = new DataSet();
                da.Fill(ds);
                int count = ds.Tables[0].Rows.Count;
                if (count > 0)
                {
                    ans = jm.Maker(ds);
                }
                else
                {
                    ans = jm.Singlevalue("no");
                }
            }
            catch (Exception e)
            {
                ans = e.Message;
            }
            return ans;
        }

        public string GetJobPositionsById(string jobPositionId)
        {
            string ans = "";
            SqlConnection con = DBConnect.getConnection();
            try
            {
                SqlDataAdapter da = new SqlDataAdapter("select * from [JobsPositions] where jobPositionId = " + jobPositionId, con);
                DataSet ds = new DataSet();
                da.Fill(ds);
                int count = ds.Tables[0].Rows.Count;
                if (count > 0)
                {
                    ans = jm.Maker(ds);
                }
                else
                {
                    ans = jm.Singlevalue("no");
                }
            }
            catch (Exception e)
            {
                ans = e.Message;
            }
            return ans;
        }

        public string AddJobs(string jobName, string description, string datePublished,
         string jobStartDate, string noOfVaccancy, string summary, string jobPositionId,
         string jobCategory, string jobPlatform, string companyId, string minExperience,
         string maxExperience, string recruiterId)
        {
            SqlConnection con = DBConnect.getConnection();
            string ans = "";


            try
            {
                SqlDataAdapter da = new SqlDataAdapter("select * from [Jobs] where " +
                    "jobName='" + jobName + "' AND jobCategory='" + jobCategory + "' "
                    + "AND companyId = '" + companyId + "' "
                    + "AND recruiterId = '" + recruiterId + "' "
                    + "AND jobPositionId = '" + jobPositionId + "'", con);
                DataSet ds = new DataSet();
                da.Fill(ds);
                int count = ds.Tables[0].Rows.Count;
                if (count > 0)
                {
                    //already
                    ans = jm.Singlevalue("already");
                    return ans;
                }

                if (ans.Length == 0)
                {

                    string query = "Insert into [Jobs] values (@jobName,@description," +
                        "@datePublished,@jobStartDate,@noOfVacancy,@summary," +
                        "@jobPositionId,@jobCategory,@jobPlatform,@companyId," +
                        "@minExperience,@maxExperience,@recruiterId)";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@jobName", jobName);
                    cmd.Parameters.AddWithValue("@description", description);
                    cmd.Parameters.AddWithValue("@datePublished", datePublished);
                    cmd.Parameters.AddWithValue("@jobStartDate", jobStartDate);
                    cmd.Parameters.AddWithValue("@noOfVacancy", noOfVaccancy);
                    cmd.Parameters.AddWithValue("@summary", summary);
                    cmd.Parameters.AddWithValue("@jobPositionId", jobPositionId);
                    cmd.Parameters.AddWithValue("@jobCategory", jobCategory);
                    cmd.Parameters.AddWithValue("@jobPlatform", jobPlatform);
                    cmd.Parameters.AddWithValue("@companyId", companyId);
                    cmd.Parameters.AddWithValue("@minExperience", minExperience);
                    cmd.Parameters.AddWithValue("@maxExperience", maxExperience);
                    cmd.Parameters.AddWithValue("@recruiterId", recruiterId);



                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();

                    String queryGetJobId = "Select jobId from [Jobs] where jobName = '"
                        + jobName + "' AND jobCategory = '" + jobCategory + "'"
                        + " AND companyId = '" + companyId + "' AND jobPositionId = '" + jobPositionId + "'";

                    SqlDataAdapter jobIdDa = new SqlDataAdapter(queryGetJobId, con);
                    DataSet jobIdDs = new DataSet();
                    jobIdDa.Fill(jobIdDs);
                    int jobIdCount = jobIdDs.Tables[0].Rows.Count;
                    if (jobIdCount > 0)
                    {
                        ans = jm.Maker(jobIdDs);
                    }
                    else
                    {
                        ans = jm.Singlevalue("no");
                    }

                }
            }
            catch (Exception e)
            {
                con.Close();
                ans = jm.Error(e.Message);
            }

            return ans;
        }


        public string UpdateJobs(string jobId, string jobName, string description, string datePublished, string jobStartDate,
           string noOfVacancy, string summary, string jobPositionId, string jobCategory,
           string jobPlatform, string companyId, string minExperience, string maxExperience,
           string recruiterId)
        {
            SqlConnection con = DBConnect.getConnection();
            string ans = "";


            try
            {
                SqlDataAdapter da = new SqlDataAdapter("select * from [Jobs] where " +
                    "jobName='" + jobName + "' AND jobCategory='" + jobCategory + "' " +
                    "AND recruiterId ='" + recruiterId + "' ", con);
                DataSet ds = new DataSet();
                da.Fill(ds);
                int count = ds.Tables[0].Rows.Count;
                if (count > 0)
                {
                    string query = "update [Jobs] set jobName=@jobName,description=@description," +
                       "datePublished=@datePublished,jobStartDate=@jobStartDate,noOfVacancy=@noOfVacancy,summary=@summary," +
                       "jobPositionId=@jobPositionId,jobCategory=@jobCategory,jobPlatform=@jobPlatform,companyId=@companyId," +
                       "minExperience=@minExperience,maxExperience=@maxExperience where jobId='" + jobId + "' " +
                       "AND recruiterId='" + recruiterId + "' ";
                    cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@jobName", jobName);
                    cmd.Parameters.AddWithValue("@description", description);
                    cmd.Parameters.AddWithValue("@datePublished", datePublished);
                    cmd.Parameters.AddWithValue("@jobStartDate", jobStartDate);
                    cmd.Parameters.AddWithValue("@noOfVacancy", noOfVacancy);
                    cmd.Parameters.AddWithValue("@summary", summary);
                    cmd.Parameters.AddWithValue("@jobPositionId", jobPositionId);
                    cmd.Parameters.AddWithValue("@jobCategory", jobCategory);
                    cmd.Parameters.AddWithValue("@jobPlatform", jobPlatform);
                    cmd.Parameters.AddWithValue("@companyId", companyId);
                    cmd.Parameters.AddWithValue("@minExperience", minExperience);
                    cmd.Parameters.AddWithValue("@maxExperience", maxExperience);



                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();


                    ans = jm.Singlevalue("true");
                }
            }
            catch (Exception e)
            {
                con.Close();
                ans = jm.Error(e.Message);
            }

            return ans;
        }

        public string DeleteJob(string jobId)
        {
            SqlConnection con = DBConnect.getConnection();
            string ans = "";
            try
            {
                SqlDataAdapter da = new SqlDataAdapter("Select jobId from [Jobs] where jobId='" + jobId + "'", con);
                DataSet ds = new DataSet();
                da.Fill(ds);
                int count = ds.Tables[0].Rows.Count;
                if (count < 0)
                {
                    //no
                    ans = jm.Singlevalue("no");
                    return ans;
                }
                else
                {
                    string query = "DELETE FROM [Jobs] WHERE jobId ='" + jobId + "'";
                    cmd = new SqlCommand(query, con);
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();

                    //true
                    ans = jm.Singlevalue("true");
                }

            }
            catch (Exception e)
            {
                con.Close();
                ans = jm.Error(e.Message);
            }
            return ans;
        }
        public string GetAllJobs()
        {
            string ans = "";
            SqlConnection con = DBConnect.getConnection();
            try
            {
                SqlDataAdapter da = new SqlDataAdapter("select * from [Jobs] " +
                    "Left Join [JobsPositions] " +
                    "ON [Jobs].jobPositionId = [JobsPositions].jobPositionId", con);
                DataSet ds = new DataSet();
                da.Fill(ds);
                int count = ds.Tables[0].Rows.Count;
                if (count > 0)
                {
                    ans = jm.Maker(ds);
                }
                else
                {
                    ans = jm.Singlevalue("no");
                }
            }
            catch (Exception e)
            {
                ans = e.Message;
            }
            return ans;
        }

        public string GetJobByCompanyId(string companyId)
        {
            string ans = "";
            SqlConnection con = DBConnect.getConnection();
            try
            {
                SqlDataAdapter da = new SqlDataAdapter("select * from [Jobs] " +
                    "Left Join [JobsPositions] " +
                    "ON [Jobs].jobPositionId = [JobsPositions].jobPositionId" +
                    " where companyId='" + companyId + "'", con);
                DataSet ds = new DataSet();
                da.Fill(ds);
                int count = ds.Tables[0].Rows.Count;
                if (count > 0)
                {
                    ans = jm.Maker(ds);
                }
                else
                {
                    ans = jm.Singlevalue("no");
                }
            }
            catch (Exception e)
            {
                ans = e.Message;
            }
            return ans;
        }

        public string GetJobByPositionId(string jobPositionId)
        {
            string ans = "";
            SqlConnection con = DBConnect.getConnection();
            try
            {
                SqlDataAdapter da = new SqlDataAdapter("select * from [Jobs] where jobPositionId='" + jobPositionId + "'", con);
                DataSet ds = new DataSet();
                da.Fill(ds);
                int count = ds.Tables[0].Rows.Count;
                if (count > 0)
                {
                    ans = jm.Maker(ds);
                }
                else
                {
                    ans = jm.Singlevalue("no");
                }
            }
            catch (Exception e)
            {
                ans = e.Message;
            }
            return ans;
        }

        public string AddJobDetails(string jobId, string sscPercentage, string hscPercentage,
    string graduationPercentage, string postGraduationPercentage, string specialization)
        {
            SqlConnection con = DBConnect.getConnection();
            string ans = "";

            try
            {
                SqlDataAdapter da = new SqlDataAdapter("Select jobId from [JobDetails] where jobId='" + jobId + "'", con);
                DataSet ds = new DataSet();
                da.Fill(ds);
                int count = ds.Tables[0].Rows.Count;
                if (count > 0)
                {
                    string query = "Insert into [JobDetails] values (@jobId,@sscPercentage,@hscPercentage,"
                        + "@graduationPercentage, @postGraduationPercentage, @specialization)";
                    cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@jobId", jobId);
                    cmd.Parameters.AddWithValue("@sscPercentage", sscPercentage);
                    cmd.Parameters.AddWithValue("@hscPercentage", hscPercentage);
                    cmd.Parameters.AddWithValue("@graduationPercentage", graduationPercentage);
                    cmd.Parameters.AddWithValue("@postGraduationPercentage", postGraduationPercentage);
                    cmd.Parameters.AddWithValue("@specialization", specialization);


                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();


                    ans = jm.Singlevalue("true");
                }
                else
                {
                    ans = jm.Singlevalue("no");
                }

            }
            catch (Exception e)
            {
                con.Close();
                ans = jm.Error(e.Message);
            }

            return ans;
        }

        public string GetJobDetails(string jobId)
        {
            string ans = "";
            SqlConnection con = DBConnect.getConnection();
            try
            {
                SqlDataAdapter da = new SqlDataAdapter("select * from [JobDetails] where jobId='" + jobId + "'", con);
                DataSet ds = new DataSet();
                da.Fill(ds);
                int count = ds.Tables[0].Rows.Count;
                if (count > 0)
                {
                    ans = jm.Maker(ds);
                }
                else
                {
                    ans = jm.Singlevalue("no");
                }
            }
            catch (Exception e)
            {
                ans = e.Message;
            }
            return ans;
        }

        public string UpdateJobDetails(string jobId, string sscPercentage, string hscPercentage,
            string graduationPercentage, string postGraduationPercentage, string specialization)
        {
            SqlConnection con = DBConnect.getConnection();
            string ans = "";

            try
            {
                SqlDataAdapter da = new SqlDataAdapter("Select jobId from [JobDetails] where jobId='" + jobId + "'", con);
                DataSet ds = new DataSet();
                da.Fill(ds);
                int count = ds.Tables[0].Rows.Count;
                if (count > 0)
                {
                    string query = "update [JobDetails] set sscPercentage=@sscPercentage,hscPercentage=@hscPercentage,"
                        + "graduationPercentage=@graduationPercentage, postGraduationPercentage=@postGraduationPercentage, specialization=@specialization "
                        + "where jobId = '" + jobId + "'";
                    cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@sscPercentage", sscPercentage);
                    cmd.Parameters.AddWithValue("@hscPercentage", hscPercentage);
                    cmd.Parameters.AddWithValue("@graduationPercentage", graduationPercentage);
                    cmd.Parameters.AddWithValue("@postGraduationPercentage", postGraduationPercentage);
                    cmd.Parameters.AddWithValue("@specialization", specialization);


                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();


                    ans = jm.Singlevalue("true");
                }
                else
                {
                    try
                    {
                        SqlDataAdapter insertDa = new SqlDataAdapter("Select jobId from [JobDetails] where jobId='" + jobId + "'", con);
                        DataSet insertDs = new DataSet();
                        insertDa.Fill(insertDs);
                        int insertCount = insertDs.Tables[0].Rows.Count;
                        if (insertCount > 0)
                        {

                            ans = jm.Singlevalue("no");
                        }
                        else
                        {
                            string query = "Insert into [JobDetails] values (@jobId,@sscPercentage,@hscPercentage,"
                                 + "@graduationPercentage, @postGraduationPercentage, @specialization)";
                            cmd = new SqlCommand(query, con);
                            cmd.Parameters.AddWithValue("@jobId", jobId);
                            cmd.Parameters.AddWithValue("@sscPercentage", sscPercentage);
                            cmd.Parameters.AddWithValue("@hscPercentage", hscPercentage);
                            cmd.Parameters.AddWithValue("@graduationPercentage", graduationPercentage);
                            cmd.Parameters.AddWithValue("@postGraduationPercentage", postGraduationPercentage);
                            cmd.Parameters.AddWithValue("@specialization", specialization);


                            con.Open();
                            cmd.ExecuteNonQuery();
                            con.Close();


                            ans = jm.Singlevalue("true");
                        }

                    }
                    catch (Exception e)
                    {
                        con.Close();
                        ans = jm.Error(e.Message);
                    }
                }

            }
            catch (Exception e)
            {
                con.Close();
                ans = jm.Error(e.Message);
            }

            return ans;
        }

        public string AddJobSkillsRequirement(string jobId, string[] skillsArray)
        {
            SqlConnection con = DBConnect.getConnection();
            string ans = "";

            try
            {
                for (int i = 0; i < skillsArray.Length; i++)
                {
                    if (!skillsArray[i].Equals(""))
                    {
                        if (!skillsArray[i].Equals("null"))
                        {
                            SqlDataAdapter da = new SqlDataAdapter("Select jobId from [JobSkillsRequirement] where " +
                        "jobId = '" + jobId + "' AND " +
                        "skills = '" + skillsArray[i] + "'", con);
                            DataSet ds = new DataSet();
                            da.Fill(ds);
                            int count = ds.Tables[0].Rows.Count;
                            if (count > 0)
                            {
                                string queryDelete = "DELETE FROM [JobSkillsRequirement] WHERE "
                                     + "jobId = '" + jobId + "' AND skills = '" + skillsArray[i] + "'";
                                cmd = new SqlCommand(queryDelete, con);
                                con.Open();
                                cmd.ExecuteNonQuery();
                                con.Close();
                            }

                            string query = "Insert into [JobSkillsRequirement] values (@jobId,@skills)";
                            cmd = new SqlCommand(query, con);
                            cmd.Parameters.AddWithValue("@jobId", jobId);
                            cmd.Parameters.AddWithValue("@skills", skillsArray[i]);


                            con.Open();
                            cmd.ExecuteNonQuery();
                            con.Close();


                            ans = jm.Singlevalue("true");

                        }
                        else
                        {
                            ans = jm.Singlevalue("no");
                        }

                    }
                    else
                    {
                        ans = jm.Singlevalue("no");
                    }
                }
            }
            catch (Exception e)
            {
                con.Close();
                ans = jm.Error(e.Message);
            }

            return ans;
        }

        public string GetJobSkillsRequirementSkills(string jobId)
        {
            string ans = "";
            SqlConnection con = DBConnect.getConnection();
            try
            {
                SqlDataAdapter da = new SqlDataAdapter("select * from [JobSkillsRequirement] where jobId='"
                   + jobId + "'", con);
                DataSet ds = new DataSet();
                da.Fill(ds);
                int count = ds.Tables[0].Rows.Count;
                if (count > 0)
                {
                    ans = jm.Maker(ds);
                }
                else
                {
                    ans = jm.Singlevalue("no");
                }
            }
            catch (Exception e)
            {
                ans = e.Message;
            }
            return ans;
        }

        public List<string> GetJobSkillsRequirementBySkill(string jobId, string[] skillsArray)
        {
            List<string> ans = new List<string>();
            SqlConnection con = DBConnect.getConnection();
            try
            {
                for (int i = 0; i < skillsArray.Length; i++)
                {
                    SqlDataAdapter da = new SqlDataAdapter("select * from [JobSkillsRequirement] where jobId='"
                  + jobId + "' AND skills<>'" + skillsArray[i] + "'", con);
                    DataSet ds = new DataSet();
                    da.Fill(ds);
                    int count = ds.Tables[0].Rows.Count;
                    if (count > 0)
                    {
                        ans.Add(jm.Maker(ds));
                    }

                }
            }
            catch (Exception e)
            {
                ans.Clear();
                ans.Add(e.Message);
            }
            return ans;
        }
        public string ViewAllApplicants(string status)
        {
            string ans = "";
            SqlConnection con = DBConnect.getConnection();
            try
            {
                SqlDataAdapter da;
                if (status == "All")
                {
                    da = new SqlDataAdapter("select * from [UserApplication]", con);

                }
                else
                {
                    da = new SqlDataAdapter("select * from [UserApplication] where status = " + status, con);
                }
                DataSet ds = new DataSet();
                da.Fill(ds);
                int count = ds.Tables[0].Rows.Count;
                if (count > 0)
                {
                    ans = jm.Maker(ds);
                }
                else
                {
                    ans = jm.Singlevalue("no");
                }
            }
            catch (Exception e)
            {
                ans = e.Message;
            }
            return ans;
        }
        public string ViewFilteredApplicants(string filterType, string filterValue, string status)
        {
            string ans = "";
            SqlConnection con = DBConnect.getConnection();
            try
            {
                SqlDataAdapter da;
                if (status == "All")
                {
                    da = new SqlDataAdapter("select * from [UserApplication] Left Join [UserDetails] " +
                    "ON [UserApplication].userDetailsId = [UserDetails].userDetailsId where "
                    + filterType + "=" + filterValue, con);
                }
                else
                {
                    da = new SqlDataAdapter("select * from [UserApplication] Left Join [UserDetails] " +
                    "ON [UserApplication].userDetailsId = [UserDetails].userDetailsId where "
                    + filterType + "=" + filterValue + " AND status = " + status, con);
                }
                DataSet ds = new DataSet();
                da.Fill(ds);
                int count = ds.Tables[0].Rows.Count;
                if (count > 0)
                {
                    ans = jm.Maker(ds);
                }
                else
                {
                    ans = jm.Singlevalue("no");
                }
            }
            catch (Exception e)
            {
                ans = e.Message;
            }
            return ans;
        }
        public string ChangeUserApplicantStatus(string applicationId, string status)
        {
            SqlConnection con = DBConnect.getConnection();
            string ans = "";
            try
            {
                SqlDataAdapter da = new SqlDataAdapter("select * from [UserApplication] where applicationId='" + applicationId + "'", con);
                DataSet ds = new DataSet();
                da.Fill(ds);
                int count = ds.Tables[0].Rows.Count;
                if (count > 0)
                {
                    string query = "update [UserApplication] set status=@status where applicationId='" + applicationId + "'";
                    cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@status", status);

                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();

                    ans = jm.Singlevalue("true");
                }
            }
            catch (Exception e)
            {
                con.Close();
                ans = jm.Error(e.Message);
            }
            return ans;
        }


        ///////////////// BOTH ///////////////////////

        public string AddChats(string userId, string recruiterId, string message,
            string sentBy, string dateTime)
        {
            SqlConnection con = DBConnect.getConnection();
            string ans = "";

            try
            {

                string query = "Insert into [Chats] values (@userId,@recruiterId," +
                    "@message,@sentBy,@dateTime)";
                cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@userId", userId);
                cmd.Parameters.AddWithValue("@recruiterId", recruiterId);
                cmd.Parameters.AddWithValue("@message", message);
                cmd.Parameters.AddWithValue("@sentBy", sentBy);
                cmd.Parameters.AddWithValue("@dateTime", dateTime);



                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();


                ans = jm.Singlevalue("true");

            }
            catch (Exception e)
            {
                con.Close();
                ans = jm.Error(e.Message);
            }

            return ans;
        }
        public string GetChatList(string userId, string recruiterId)
        {
            string ans = "";
            SqlConnection con = DBConnect.getConnection();
            try
            {
                SqlDataAdapter da = new SqlDataAdapter("select  [Chats].* , " +
                    "[Users].firstName,[Users].lastName," +
                    "[Recruiter].firstName ,[Recruiter].lastName " +
                    "from [Chats] Left Join [Recruiter] " +
                    "ON [Chats].recruiterId = [Recruiter].recruiterId " +
                    "Left Join [Users] ON [Chats].userId = [Users].userId " +
                    "where [Chats].userId='" + userId + "' " +
                    "AND  [Chats].recruiterId='" + recruiterId + "'", con);
                DataSet ds = new DataSet();
                da.Fill(ds);
                int count = ds.Tables[0].Rows.Count;
                if (count > 0)
                {
                    ans = jm.Maker(ds);
                }
                else
                {
                    ans = jm.Singlevalue("no");
                }
            }
            catch (Exception e)
            {
                ans = e.Message;
            }
            return ans;
        }
        public string GetUserNotification(string userId)
        {
            string ans = "";
            SqlConnection con = DBConnect.getConnection();
            try
            {
                SqlDataAdapter da = new SqlDataAdapter("Select * From [Notification] WHERE [Notification].userId = '" + userId + "'", con);
                DataSet ds = new DataSet();
                da.Fill(ds);
                int count = ds.Tables[0].Rows.Count;
                if (count > 0)
                {
                    //All
                    ans = jm.Maker(ds);

                    string query = "DELETE FROM [Notification] WHERE userId ='" + userId + "'";
                    cmd = new SqlCommand(query, con);
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();

                }
                else
                {
                    //no
                    ans = jm.Singlevalue("no");
                }
            }
            catch (Exception e)
            {
                ans = e.Message;
            }
            return ans;
        }
        public string GetRecruiterNotification(string recruiterId)
        {
            string ans = "";
            SqlConnection con = DBConnect.getConnection();
            try
            {
                SqlDataAdapter da = new SqlDataAdapter("Select * From [Notification] WHERE [Notification].recruiterId = '" + recruiterId + "'", con);
                DataSet ds = new DataSet();
                da.Fill(ds);
                int count = ds.Tables[0].Rows.Count;
                if (count > 0)
                {
                    //All
                    ans = jm.Maker(ds);

                    string query = "DELETE FROM [Notification] WHERE recruiterId ='" + recruiterId + "'";
                    cmd = new SqlCommand(query, con);
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();

                }
                else
                {
                    //no
                    ans = jm.Singlevalue("no");
                }
            }
            catch (Exception e)
            {
                ans = e.Message;
            }
            return ans;
        }
        public string AddNotification(string title, string message, string type,
            string userId)
        {
            SqlConnection con = DBConnect.getConnection();
            string ans = "";

            try
            {

                if (type.Equals("USER"))
                {
                    string query = "Insert into [Notification] values (@userId,@recruiterId,@title,@type,@message)";
                    cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@userId", "");
                    cmd.Parameters.AddWithValue("@recruiterId", userId);
                    cmd.Parameters.AddWithValue("@title", title);
                    cmd.Parameters.AddWithValue("@message", message);
                    cmd.Parameters.AddWithValue("@type", type);


                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();

                    ans = jm.Singlevalue("true");
                }
                else
                {
                    string query = "Insert into [Notification] values (@userId,@recruiterId,@title,@type,@message)";
                    cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@userId", userId);
                    cmd.Parameters.AddWithValue("@recruiterId", "");
                    cmd.Parameters.AddWithValue("@title", title);
                    cmd.Parameters.AddWithValue("@message", message);
                    cmd.Parameters.AddWithValue("@type", type);



                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();

                    ans = jm.Singlevalue("true");
                }
            }
            catch (Exception e)
            {
                con.Close();
                ans = jm.Error(e.Message);
            }

            return ans;
        }
    }
}