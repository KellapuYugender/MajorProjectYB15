package com.example.jobportal.activity;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Pair;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.jobportal.R;
import com.example.jobportal.activity.recruiter.RecruiterDashboardActivity;
import com.example.jobportal.activity.user.DashboardActivity;
import com.example.jobportal.utility.Constants;
import com.example.jobportal.utility.DialogUtils;
import com.example.jobportal.utility.Helper;
import com.example.jobportal.utility.UserPref;
import com.example.jobportal.utility.webServices.JSONParse;
import com.example.jobportal.utility.webServices.RestAPI;
import com.example.jobportal.utility.webServices.Utility;

import org.json.JSONArray;
import org.json.JSONObject;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener {

    private RelativeLayout rlLoginLayout;
    private EditText etUserName, etPassword;
    private TextView tvError, tvRegister;
    private Button btnLogin;

    private RestAPI restAPI;
    private JSONParse jsonParse;
    private String userType = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        checkForLoginStatusAndNavigate();
    }

    private void checkForLoginStatusAndNavigate() {
        boolean loginStatus = UserPref.getLoginStatus(this);

        if (loginStatus) {
            int flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
                    | Intent.FLAG_ACTIVITY_CLEAR_TASK
                    | Intent.FLAG_ACTIVITY_NEW_TASK;
            String userType = UserPref.getStringValue(this, Constants.USER_TYPE);
            if (userType.equalsIgnoreCase(Constants.TYPE_RECRUITER)) {
                Helper.goToWithFlags(this, RecruiterDashboardActivity.class, flags);
            } else {
                Helper.goToWithFlags(this, DashboardActivity.class, flags);
            }
            finish();
        } else {
            setContentView(R.layout.activity_login);
            initUI();
            initObj();
        }
    }

    private void initUI() {

        rlLoginLayout = findViewById(R.id.rlLoginLayout);

        etUserName = findViewById(R.id.etUserName);
        etPassword = findViewById(R.id.etPassword);

        tvError = findViewById(R.id.tvError);
        tvRegister = findViewById(R.id.tvRegister);

        btnLogin = findViewById(R.id.btnLogin);

        tvError.setVisibility(View.GONE);
        tvRegister.setOnClickListener(this);
        btnLogin.setOnClickListener(this);

    }

    private void initObj() {

        restAPI = new RestAPI();
        jsonParse = new JSONParse();
        userType = getIntent().getStringExtra(Constants.USER_TYPE);
    }

    @SuppressLint("NonConstantResourceId")
    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.tvRegister:
                onCLickRegister();
                break;
            case R.id.btnLogin:
                onClickLogin();
                break;
        }
    }

    private void onCLickRegister() {
        Helper.goTo(this, RegistrationActivity.class, Constants.USER_TYPE, userType);
    }

    private void onClickLogin() {

        if (isValidate()) {
            String userName = etUserName.getText().toString().trim();
            String password = etPassword.getText().toString().trim();
            if (userType.equalsIgnoreCase(Constants.TYPE_RECRUITER))
                new AsyncRecruiterLogin().execute(userName, password);
            else new AsyncLogin().execute(userName, password);
        }
    }

    private boolean isValidate() {
        String error = "";
        if (etUserName.getText().toString().trim().equals("")) {
            error = error + "User Name required\n";
            etUserName.setError("required");
        }
        if (etPassword.getText().toString().trim().equals("")) {
            error = error + "Password required\n";
            etPassword.setError("required");
        }
        if (error.equals("")) {
            tvError.setVisibility(View.GONE);
            return true;
        } else {
            tvError.setVisibility(View.VISIBLE);
            return false;
        }

    }

    private void saveToSharedPrefAndNavigate(JSONObject json) {
        try {
            JSONArray jsonArray = json.getJSONArray("Data");
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObj = jsonArray.getJSONObject(i);
                UserPref.setUserId(this, jsonObj.getString("data0"));
                UserPref.setValue(this, Constants.USER_TYPE, userType);
            }
            UserPref.setLoginStatus(this, true);
            int flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
                    | Intent.FLAG_ACTIVITY_CLEAR_TASK
                    | Intent.FLAG_ACTIVITY_NEW_TASK;
            if(userType.equalsIgnoreCase(Constants.TYPE_RECRUITER)){
                Helper.goToWithFlags(this, RecruiterDashboardActivity.class, flags);
            }else {
                Helper.goToWithFlags(this, DashboardActivity.class, flags);
            }
            finish();
        } catch (Exception exception) {
            exception.printStackTrace();
        }

    }

    private class AsyncLogin extends AsyncTask<String, String, String> {

        private Dialog dialog;
        private final Context context = LoginActivity.this;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            dialog = DialogUtils.showLoadingDialog(context, "");
        }

        @Override
        protected String doInBackground(String... strings) {
            String a;

            try {
                JSONObject json = restAPI.Login(strings[0], strings[1]);
                a = jsonParse.parse(json);
            } catch (Exception e) {
                a = e.getMessage();
            }
            return a;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            dialog.dismiss();

            try {
                if (Utility.checkConnection(s)) {
                    Pair<String, String> pair = Utility.GetErrorMessage(s);
                    Utility.ShowAlertDialog(context, pair.first, pair.second, false);
                } else {
                    //main
                    JSONObject json = new JSONObject(s);

                    //string value
                    String StatusValue = json.getString("status");

                    if (StatusValue.compareToIgnoreCase("false") == 0) {
                        Helper.makeSnackBar(rlLoginLayout, "Invalid Password Or Email Id");

                    } else if (StatusValue.compareToIgnoreCase("ok") == 0) {
                        saveToSharedPrefAndNavigate(json);
                    } else {
                        Helper.makeSnackBar(rlLoginLayout, "Something Went Wrong");
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
                Helper.makeSnackBar(rlLoginLayout, "Something Went Wrong");
            }

        }
    }

    private class AsyncRecruiterLogin extends AsyncTask<String, String, String> {

        private Dialog dialog;
        private final Context context = LoginActivity.this;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            dialog = DialogUtils.showLoadingDialog(context, "");
        }

        @Override
        protected String doInBackground(String... strings) {
            String a;

            try {
                JSONObject json = restAPI.RecruiterLogin(strings[0], strings[1]);
                a = jsonParse.parse(json);
            } catch (Exception e) {
                a = e.getMessage();
            }
            return a;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            dialog.dismiss();

            try {
                if (Utility.checkConnection(s)) {
                    Pair<String, String> pair = Utility.GetErrorMessage(s);
                    Utility.ShowAlertDialog(context, pair.first, pair.second, false);
                } else {
                    //main
                    JSONObject json = new JSONObject(s);

                    //string value
                    String StatusValue = json.getString("status");

                    if (StatusValue.compareToIgnoreCase("false") == 0) {
                        Helper.makeSnackBar(rlLoginLayout, "Invalid Password Or Email Id");

                    } else if (StatusValue.compareToIgnoreCase("ok") == 0) {
                        saveToSharedPrefAndNavigate(json);
                    } else {
                        Helper.makeSnackBar(rlLoginLayout, "Something Went Wrong");
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
                Helper.makeSnackBar(rlLoginLayout, "Something Went Wrong");
            }

        }
    }

}