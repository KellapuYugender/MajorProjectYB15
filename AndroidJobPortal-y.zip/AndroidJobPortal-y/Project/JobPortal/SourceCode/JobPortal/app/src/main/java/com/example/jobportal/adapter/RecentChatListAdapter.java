package com.example.jobportal.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.jobportal.R;
import com.example.jobportal.activity.ChatsActivity;
import com.example.jobportal.activity.RecentChatsActivity;
import com.example.jobportal.model.Chats;
import com.example.jobportal.utility.Constants;
import com.example.jobportal.utility.Helper;
import com.example.jobportal.utility.UserPref;

import java.util.List;

public class RecentChatListAdapter extends RecyclerView.Adapter<RecentChatListAdapter.ViewHolder> {

    private Context context;
    private List<Chats> chatsList;

    public RecentChatListAdapter(Context context, List<Chats> chatsList) {
        this.context = context;
        this.chatsList = chatsList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        context = parent.getContext();
        LayoutInflater inflater = LayoutInflater.from(context);
        View detailItem = inflater.inflate(R.layout.list_recent_chats, parent, false);
        return new ViewHolder(detailItem);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        if (chatsList.size() != 0) {
            holder.tvUserName.setText(chatsList.get(position).getUserName());
            holder.tvMessage.setText(chatsList.get(position).getMessage());
            holder.rlChat.setOnClickListener(view -> {
                onClickRelativeLayoutChat(chatsList.get(position));
            });
        }
    }

    private void onClickRelativeLayoutChat(Chats chats) {
        if (UserPref.getUserType(context).equalsIgnoreCase(Constants.TYPE_RECRUITER)) {
            Helper.goTo(context, ChatsActivity.class, Constants.CHATS, chats.getUserId());
        } else {
            Helper.goTo(context, ChatsActivity.class, Constants.CHATS, chats.getRecruiterId());
        }
    }

    @Override
    public int getItemCount() {
        return chatsList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        private RelativeLayout rlChat;
        private TextView tvUserName, tvMessage;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            rlChat = itemView.findViewById(R.id.rlChat);
            tvUserName = itemView.findViewById(R.id.tvUserName);
            tvMessage = itemView.findViewById(R.id.tvMessage);
        }
    }
}
