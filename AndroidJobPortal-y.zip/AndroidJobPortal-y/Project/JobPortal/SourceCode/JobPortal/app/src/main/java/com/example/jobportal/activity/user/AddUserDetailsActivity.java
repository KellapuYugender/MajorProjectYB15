package com.example.jobportal.activity.user;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.Manifest;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.util.Pair;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.jobportal.R;
import com.example.jobportal.activity.recruiter.AddJobDetailsActivity;
import com.example.jobportal.model.JobDetails;
import com.example.jobportal.model.UserDetails;
import com.example.jobportal.utility.Constants;
import com.example.jobportal.utility.DateUtils;
import com.example.jobportal.utility.DialogUtils;
import com.example.jobportal.utility.Helper;
import com.example.jobportal.utility.PathUtils;
import com.example.jobportal.utility.PermissionUtils;
import com.example.jobportal.utility.UploadFileFTP;
import com.example.jobportal.utility.UserPref;
import com.example.jobportal.utility.webServices.JSONParse;
import com.example.jobportal.utility.webServices.RestAPI;
import com.example.jobportal.utility.webServices.Utility;

import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Objects;

public class AddUserDetailsActivity extends AppCompatActivity
        implements View.OnClickListener, UploadFileFTP.AsyncResponseFTP {

    private RelativeLayout rlAddUserDetailsLayout;
    private EditText etSSCPercentage, etHscPercentage, etGraduationPercentage,
            etPostGraduationPercentage, etWorkExperience, etSpecialization,
            etSkills, etCV;

    private ImageButton ibUpload;
    private Button btnAddDetails;

    private RestAPI restAPI;
    private JSONParse jsonParse;
    private Context context;
    private UserDetails entity;
    private String userId;
    private ArrayList<String> skillList;

    private Intent data = null;
    private UploadFileFTP.AsyncResponseFTP asyncResponseFTP;

    private static final int PICK_FILE_RESULT_CODE = 100;
    private static final int PERMISSION_REQUEST_CODE = 0;
    private boolean permissionGrantedAndLocationEnabled = false;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_user_details);

        initToolbar();
        initUI();
        initObj();

    }

    @Override
    protected void onResume() {
        super.onResume();
        checkPermissions();
    }

    private void initToolbar() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        TextView tvTitle = toolbar.findViewById(R.id.tvTitle);
        tvTitle.setText(Constants.ADD_DETAILS);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null)
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

    private void initUI() {

        rlAddUserDetailsLayout = findViewById(R.id.rlAddUserDetailsLayout);
        etSSCPercentage = findViewById(R.id.etSSCPercentage);
        etHscPercentage = findViewById(R.id.etHscPercentage);
        etGraduationPercentage = findViewById(R.id.etGraduationPercentage);
        etPostGraduationPercentage = findViewById(R.id.etPostGraduationPercentage);
        etWorkExperience = findViewById(R.id.etWorkExperience);
        etSpecialization = findViewById(R.id.etSpecialization);
        etSkills = findViewById(R.id.etSkills);
        etCV = findViewById(R.id.etCV);
        ibUpload = findViewById(R.id.ibUpload);
        btnAddDetails = findViewById(R.id.btnAddDetails);

        Helper.bulletPointsEditTextListener(etSkills);
        etCV.setOnClickListener(this);
        ibUpload.setOnClickListener(this);
        btnAddDetails.setOnClickListener(this);
    }

    private void initObj() {
        context = this;
        entity = new UserDetails();
        restAPI = new RestAPI();
        jsonParse = new JSONParse();

        skillList = new ArrayList<>();
        userId = UserPref.getUser(this);

        asyncResponseFTP = this;
    }

    private void checkPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (PermissionUtils.neverAskAgainSelected(this)) {
                PermissionUtils.displayNeverAskAgainDialog(this);
            } else {
                permissionGrantedAndLocationEnabled = PermissionUtils.requestPermission(this, PERMISSION_REQUEST_CODE);
            }
        }
    }

    @Override
    public void onClick(View view) {
        if (view.getId() == R.id.btnAddDetails) {
            onClickBtnAddDetails();
        } else if (view.getId() == R.id.ibUpload) {
            onClickImageBtnUpload();
        } else if (view.getId() == R.id.etCV) {
            onClickImageBtnUpload();
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (PermissionUtils.permissionGranted(requestCode, PERMISSION_REQUEST_CODE, grantResults)) {
            permissionGrantedAndLocationEnabled = true;
        } else {
            permissionGrantedAndLocationEnabled = false;
            PermissionUtils.setShouldShowStatus(this, Manifest.permission.ACCESS_COARSE_LOCATION);
        }

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_FILE_RESULT_CODE) {
            if (resultCode == RESULT_OK) {
                this.data = data;
                if (data != null) {
                    Uri uri = data.getData();
                    String path = PathUtils.getPath(this, uri);
                    File file = new File(path);
                    etCV.setText(file.getName());
                }
            } else if (resultCode == RESULT_CANCELED) {
                Toast.makeText(this, "You cancelled the operation", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    public void onAsyncResponseFTP(String s) {
        new AsyncAddUserDetails().execute(entity.getUserId(), entity.getSscPercentage(),
                entity.getHscPercentage(), entity.getGraduationPercentage(),
                entity.getPostGraduationPercentage(), entity.getWorkExperience(),
                entity.getSpecialization(), entity.getCv());
    }

    private void onClickImageBtnUpload() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("application/pdf");
        intent = Intent.createChooser(intent, "Choose a file");
        startActivityForResult(intent, PICK_FILE_RESULT_CODE);
    }

    private void onClickBtnAddDetails() {
        if (permissionGrantedAndLocationEnabled) {
            setDataToEntity();
            if (data != null) {
                Uri uri = data.getData();
                String path = PathUtils.getPath(this, uri);
                File file = new File(path);
                String fileName = userId + "_CV_" + DateUtils.formatDateStringForName();
                entity.setCv(Constants.DB_DIR_FILE_UPLOAD + fileName + ".pdf");
                new UploadFileFTP(this,
                        rlAddUserDetailsLayout, asyncResponseFTP)
                        .execute(file.getPath(), Constants.DB_DIR_FILE_UPLOAD,
                                fileName);
            }else{
                Helper.makeSnackBar(rlAddUserDetailsLayout,"Add Documents to proceed");
            }
        }

    }

    private void setDataToEntity() {
        entity.setUserId(userId);
        entity.setSscPercentage(etSSCPercentage.getText().toString().trim());
        entity.setHscPercentage(etHscPercentage.getText().toString().trim());
        entity.setGraduationPercentage(etGraduationPercentage.getText().toString().trim());
        entity.setPostGraduationPercentage(etPostGraduationPercentage.getText().toString().trim());
        entity.setWorkExperience(etWorkExperience.getText().toString().trim());
        entity.setSpecialization(etSpecialization.getText().toString().trim());
        entity.setCv("");
    }

    private class AsyncAddUserDetails extends AsyncTask<String, String, String> {

        private Dialog dialog;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            dialog = DialogUtils.showLoadingDialog(context, Constants.SAVING);

        }

        @Override
        protected String doInBackground(String... strings) {
            String a;
            try {
                JSONObject json = restAPI.UpdateUserDetails(strings[0],
                        strings[1], strings[2], strings[3], strings[4],
                        strings[5], strings[6], strings[7]);
                a = jsonParse.parse(json);
            } catch (Exception e) {
                a = e.getMessage();
            }
            return a;
        }

        @RequiresApi(api = Build.VERSION_CODES.N)
        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            DialogUtils.dismissLoadingDialog(dialog);
            if (Utility.checkConnection(s)) {
                Pair<String, String> pair = Utility.GetErrorMessage(s);
                Utility.ShowAlertDialog(context, pair.first, pair.second, false);
            } else {
                try {
                    JSONObject jsonObject = new JSONObject(s);
                    String statusValue = jsonObject.getString("status");
                    if (statusValue.compareTo("true") == 0) {
                        if (!etSkills.getText().toString().trim().isEmpty()) {
                            UserPref.setProfileStatus(context, true);
                            String[] split = etSkills.getText().toString().
                                    replaceAll("\\n", "").split("➼");
                            skillList = new ArrayList<>(Arrays.asList(split));
                            skillList.replaceAll(t -> Objects.isNull(t) ? "null" : t);
                            new AsyncAddSkills().execute(userId);
                        }
                        DialogUtils.openAlertDialog(context,
                                "Details Added",
                                "OK",
                                false,
                                true);
                    } else {
                        Helper.makeSnackBar(rlAddUserDetailsLayout, Constants.SOMETHING_WENT_WRONG);
                    }
                } catch (Exception e) {
                    Helper.makeSnackBar(rlAddUserDetailsLayout, Constants.SOMETHING_WENT_WRONG);
                    e.printStackTrace();
                }
            }
        }
    }

    private class AsyncAddSkills extends AsyncTask<String, String, String> {

        private Dialog dialog;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            dialog = DialogUtils.showLoadingDialog(context, Constants.SAVING);

        }

        @Override
        protected String doInBackground(String... strings) {
            String a;
            try {
                JSONObject json = restAPI.AddUserSkills(strings[0], skillList);
                a = jsonParse.parse(json);
            } catch (Exception e) {
                a = e.getMessage();
            }
            return a;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            DialogUtils.dismissLoadingDialog(dialog);
            if (Utility.checkConnection(s)) {
                Pair<String, String> pair = Utility.GetErrorMessage(s);
                Utility.ShowAlertDialog(context, pair.first, pair.second, false);
            } else {
                try {
                    JSONObject jsonObject = new JSONObject(s);
                    String statusValue = jsonObject.getString("status");
                    if (statusValue.compareTo("true") == 0) {
                        finish();
                    } else {
                        Toast.makeText(context, Constants.SOMETHING_WENT_WRONG
                                + "\nSkills cannot be added", Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception e) {
                    Helper.makeSnackBar(rlAddUserDetailsLayout, Constants.SOMETHING_WENT_WRONG);
                    e.printStackTrace();
                }
            }
        }
    }
}