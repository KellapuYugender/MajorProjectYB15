package com.example.jobportal.utility;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.os.Build;
import android.widget.EditText;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;

public class DateUtils {

    public static String[] currentDateTime() {

        Date date = new Date();
        SimpleDateFormat dateTimeFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        SimpleDateFormat monthFormat = new SimpleDateFormat("MMMM");
        SimpleDateFormat yearFormat = new SimpleDateFormat("yyyy");
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
        SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm");

        String currentDateTime = dateTimeFormat.format(date);
        String currentMonth = monthFormat.format(date);
        String currentYear = yearFormat.format(date);
        String currentDate = dateFormat.format(date);
        String currentTime = timeFormat.format(date);

        return new String[]{currentDateTime, currentMonth, currentYear, currentDate,currentTime};
    }

    public static String subtractMonth(String subtractMonth) {
        Date date = new Date();
        SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        int subtractMonthAmount = getMonthNumberFromMonthName(subtractMonth);
        cal.add(Calendar.MONTH, -subtractMonthAmount);
        Date time = cal.getTime();
        String formatDate = format.format(time);
        return formatDate;

    }

    public static String subtractMonthToCurrentDate(int subtractMonthAmount) {

        String formatDate = null;
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                formatDate = LocalDateTime.now().minusMonths(6).
                        format(DateTimeFormatter.ofPattern("yyyy/MM/dd"));

            } else {
                Date date = new Date();
                SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");
                SimpleDateFormat yearFormat = new SimpleDateFormat("yyyy");
                Calendar cal = Calendar.getInstance();
                cal.setTime(date);
                cal.add(Calendar.MONTH, subtractMonthAmount);
                cal.add(Calendar.YEAR, Integer.parseInt(yearFormat.format(date)));
                Date time = cal.getTime();
                formatDate = format.format(time);
            }

        } catch (Exception exception) {
            exception.printStackTrace();
        }
        return formatDate;

    }

    public static String[] getFirstAndLastDateMonth(String month) {

        int monthNumberFromMonthName = getMonthNumberFromMonthName(month);
        Calendar calendar = new GregorianCalendar();
        calendar.set(Calendar.MONTH, monthNumberFromMonthName);
        calendar.set(Calendar.DAY_OF_MONTH, 1);
        Date monthStart = calendar.getTime();
        calendar.add(Calendar.MONTH, 1);
        calendar.add(Calendar.DAY_OF_MONTH, -1);
        Date monthEnd = calendar.getTime();
        SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");

        return new String[]{format.format(monthStart), format.format(monthEnd)};
    }

    public static int getMonthNumberFromMonthName(String monthName) {
        int monthNumber = 0;
        try {
            Date date = new SimpleDateFormat("MMMM").parse(monthName);
            Calendar cal = Calendar.getInstance();
            assert date != null;
            cal.setTime(date);
            monthNumber = cal.get(Calendar.MONTH);
        } catch (Exception exception) {
            exception.printStackTrace();
        }
        return monthNumber;
    }

    public static String formatDateString(String inputDate) {
        try {
            DateFormat outputFormat = new SimpleDateFormat("yyyy/MM/dd", Locale.US);
            DateFormat inputFormat = new SimpleDateFormat("dd/MM/yyyy", Locale.US);
            Date date = inputFormat.parse(inputDate);
            String outputDate = outputFormat.format(date);
            return outputDate;
        } catch (Exception exception) {
            exception.printStackTrace();
        }
        return null;
    }

    public static String formatDateStringForName() {
        try {
            Date date = new Date();
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy_MM_dd_HH_mm_ss");
            String currentDateTime = simpleDateFormat.format(date);
            return currentDateTime;
        } catch (Exception exception) {
            exception.printStackTrace();
        }
        return null;
    }

    public static String formatDate(Date date) {
        try {
            return new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(date);
        } catch (Exception exception) {
            exception.printStackTrace();
        }
        return null;
    }

    public static boolean timeValidation(String startTime, String closeTime) {

        try {
            String pattern = "HH:mm";
            SimpleDateFormat sdf = new SimpleDateFormat(pattern);
            Date startTimeFormat = sdf.parse(startTime);
            Date closeTimeFormat = sdf.parse(closeTime);
            assert startTimeFormat != null;
            if (startTimeFormat.after(closeTimeFormat)) {
                return true;
            }
        } catch (Exception exception) {
            exception.printStackTrace();
        }
        return false;
    }

    public static void openDatePickerDialog(Context context, EditText editText) {
        try {

            Calendar mcurrentDate = Calendar.getInstance();
            int calendarDay = mcurrentDate.get(Calendar.DAY_OF_MONTH);
            int calendarMonth = mcurrentDate.get(Calendar.MONTH);
            int calendarYear = mcurrentDate.get(Calendar.YEAR);
            DatePickerDialog datePickerDialog = new DatePickerDialog(context, (view, year, month, dayOfMonth) -> {
                month = month + 1;
                try {
                    String monthString = String.valueOf(month);
                    if (monthString.length() == 1) {
                        monthString = "0" + monthString;
                    }
                    String dayString = String.valueOf(dayOfMonth);

                    if (dayString.length() == 1) {
                        dayString = "0" + dayString;
                    }
                    String date = year + "/" + monthString + "/" + dayString;

                    editText.setText(date);


                } catch (Exception exception) {
                    exception.printStackTrace();
                }

            }, calendarYear, calendarMonth, calendarDay);
            datePickerDialog.show();

        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    public static void openTimePickerDialog(Context context, EditText editText) {
        Calendar currentTime = Calendar.getInstance();
        int hour = currentTime.get(Calendar.HOUR_OF_DAY);
        int minute = currentTime.get(Calendar.MINUTE);
        TimePickerDialog timePickerDialog;
        timePickerDialog = new TimePickerDialog(context,
                (timePicker, selectedHour, selectedMinute) -> {
                    String timeString = selectedHour + ":" + selectedMinute;
                    editText.setText(timeString);
                }, hour, minute, true);
        timePickerDialog.setTitle("Select Time 24hr only");
        timePickerDialog.show();
    }
}
