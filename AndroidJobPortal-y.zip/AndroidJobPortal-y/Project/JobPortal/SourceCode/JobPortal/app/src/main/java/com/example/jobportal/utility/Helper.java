package com.example.jobportal.utility;


import static android.content.Context.ACTIVITY_SERVICE;

import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;

import com.google.android.material.snackbar.Snackbar;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Helper {

    public static void makeSnackBar(View view, String message) {
        Snackbar.make(view, message, Snackbar.LENGTH_LONG).show();
    }

    public static void makeSnackBarWithAction(View view, String message,
                                              String button, View.OnClickListener onClick) {
        Snackbar.make(view, message, Snackbar.LENGTH_LONG).setAction(button, onClick).show();
    }

    public static void hideKeyBoard(Context context, View view) {
        InputMethodManager inputMethodManager = (InputMethodManager) context.getSystemService(Context.INPUT_METHOD_SERVICE);
        inputMethodManager.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }

    public static boolean validateCardExpiryDate(String expiryDate) {
        return expiryDate.matches("(?:0[1-9]|1[0-2])/[0-9]{2}");
    }

    public static boolean isMyServiceRunning(Context context) {
        ActivityManager manager = (ActivityManager) context.getSystemService(ACTIVITY_SERVICE);
        for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
            if (MyNotificationService.class.getName().equals(service.service.getClassName())) {
                Log.d("TAG", "isMyServiceRunning() called with: context = [" + context + "] is true");
                return true;
            }
        }
        return false;
    }

    public static final boolean checkPercentageValidation(EditText editText, View view) {
        if (!editText.getText().toString().trim().isEmpty()) {
            if (editText.length() > 100) {
                Helper.makeSnackBar(view, "Percentage Value Not Valid");
                return false;
            } else return true;
        } else return true;
    }

    public static boolean emailValidation(CharSequence charSequence) {
        return (!TextUtils.isEmpty(charSequence) && Patterns.EMAIL_ADDRESS.matcher(charSequence).matches());
    }

    public static boolean phoneValidation(CharSequence charSequence) {
        return (!TextUtils.isEmpty(charSequence) && Patterns.PHONE.matcher(charSequence).matches());
    }

    public static boolean expiryDateCheck(String input) {
        try {

            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MM/yy");
            simpleDateFormat.setLenient(false);
            Date expiry = simpleDateFormat.parse(input);
            boolean expired = expiry.before(new Date());
            if (expired)
                return true;
            else
                return false;
        } catch (Exception exception) {
            return false;
        }

    }

    public static void goTo(Context context, Class<?> activity) {
        Intent intent = new Intent(context, activity);
        context.startActivity(intent);
    }

    public static void goTo(Context context, Class<?> activity, String name, String value) {
        Intent intent = new Intent(context, activity);
        intent.putExtra(name, value);
        context.startActivity(intent);
    }

    public static void goTo(Context context, Class<?> activity, String name, Serializable value) {
        Intent intent = new Intent(context, activity);
        intent.putExtra(name, value);
        context.startActivity(intent);
    }

    public static void goToWithFlags(Context context, Class<?> activity, int flags) {
        Intent intent = new Intent(context, activity);
        intent.setFlags(flags);
        context.startActivity(intent);
    }

    public static void expiryEditTextListener(EditText editText) {
        editText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String str = editText.getText().toString();
                int textLength = editText.getText().length();
                if (textLength == 3) {
                    if (!str.contains("/")) {
                        editText.setText(new StringBuilder(editText.getText().toString()).insert(str.length() - 1, "/").toString());
                        editText.setSelection(editText.getText().length());
                    }
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });
    }

    public static void bulletPointsEditTextListener(EditText editText) {
        editText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence text, int start, int lengthBefore, int lengthAfter) {
                if (lengthAfter > lengthBefore) {
                    if (text.toString().length() == 1) {
                        text = "➼ " + text;
                        editText.setText(text);
                        editText.setSelection(editText.getText().length());
                    }
                    if (text.toString().endsWith("\n")) {
                        text = text.toString().replace("\n", "\n➼ ");
                        text = text.toString().replace("➼ ➼", "➼");
                        editText.setText(text);
                        editText.setSelection(editText.getText().length());
                    }
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });
    }


    public static void disableAllEditTexts(ViewGroup viewGroup) {

        for (int i = 0, count = viewGroup.getChildCount(); i < count; ++i) {
            View view = viewGroup.getChildAt(i);
            if (view instanceof EditText) {
                ((EditText) view).setEnabled(false);
            }
            if (view instanceof ViewGroup && (((ViewGroup) view).getChildCount() > 0))
                disableAllEditTexts((ViewGroup) view);
        }
    }

    public static void clearText(ViewGroup viewGroup) {

        for (int i = 0, count = viewGroup.getChildCount(); i < count; ++i) {
            View view = viewGroup.getChildAt(i);
            if (view instanceof EditText) {
                ((EditText) view).getText().clear();
            }

            if (view instanceof RadioGroup) {
                ((RadioButton) ((RadioGroup) view).getChildAt(0)).setChecked(true);
            }

            if (view instanceof Spinner) {
                ((Spinner) view).setSelection(0);
            }

            if (view instanceof ViewGroup && (((ViewGroup) view).getChildCount() > 0))
                clearText((ViewGroup) view);
        }
    }

}
