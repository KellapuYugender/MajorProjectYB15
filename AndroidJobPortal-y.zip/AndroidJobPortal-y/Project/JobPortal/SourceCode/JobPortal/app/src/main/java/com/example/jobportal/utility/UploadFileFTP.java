package com.example.jobportal.utility;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.example.jobportal.R;
import com.example.jobportal.utility.webServices.Utility;
import com.google.android.material.snackbar.Snackbar;

import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPFile;
import org.apache.commons.net.io.CopyStreamAdapter;
import org.apache.commons.net.io.CopyStreamListener;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;

public class UploadFileFTP extends AsyncTask<String, String, String> {

    private FTPClient ftpClient;
    private final Context context;
    private final RelativeLayout relativeLayout;
    private CopyStreamListener streamListener;
    private Dialog dialog;

    private AsyncResponseFTP asyncResponseFTP;

    public UploadFileFTP(Context context, RelativeLayout relativeLayout, AsyncResponseFTP asyncResponseFTP) {
        this.ftpClient = new FTPClient();
        this.context = context;
        this.relativeLayout = relativeLayout;
        this.asyncResponseFTP = asyncResponseFTP;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
        dialog = DialogUtils.showLoadingDialog(context, Constants.UPLOADING);

    }

    @Override
    protected String doInBackground(String... strings) {
        String ans = "";
        try {
            ftpClient.connect(Constants.SITE_NAME);
            if (ftpClient.login(Constants.USER_NAME, Constants.PASSWORD)) {
                ftpClient.setFileType(FTP.BINARY_FILE_TYPE);
                ftpClient.enterLocalPassiveMode();

                BufferedInputStream bufferedInputStream = null;
                final File file = new File(strings[0]);

                ftpClient.changeWorkingDirectory(Constants.DB_DIR_FILE_UPLOAD);
                FTPFile[] filesFTP = ftpClient.listFiles(Constants.DB_DIR_FILE_UPLOAD);

                if (filesFTP.length > 0) {
                    for (FTPFile ftpFile : filesFTP) {
                        if (ftpFile.getName().contains(strings[2])) {
                            ftpClient.deleteFile(Constants.DB_DIR_FILE_UPLOAD + strings[2]);
                        }
                    }
                }

                bufferedInputStream = new BufferedInputStream(new FileInputStream(file));

                streamListener = new CopyStreamAdapter() {
                    @Override
                    public void bytesTransferred(long totalBytesTransferred,
                                                 int bytesTransferred, long streamSize) {

                        int percent = (int) (totalBytesTransferred * 100 / file.length());
                        publishProgress();

                        if (totalBytesTransferred == file.length()) {
                            System.out.println("100% transfered");
                            removeCopyStreamListener(streamListener);
                        }
                    }
                };

                ftpClient.setCopyStreamListener(streamListener);


                boolean status = ftpClient.storeFile(strings[1], bufferedInputStream);

                if (status) {
                    ans = "true";

                } else {
                    ans = "false";
                }
                String replyString = ftpClient.getReplyString();

                bufferedInputStream.close();

                ftpClient.logout();
                ftpClient.disconnect();
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return ans;
    }


    @Override
    protected void onPostExecute(String s) {
        super.onPostExecute(s);
        DialogUtils.dismissLoadingDialog(dialog);

        if (s.compareTo("true") == 0) {
            Snackbar.make(relativeLayout, "UPLOADED", Snackbar.LENGTH_LONG).show();
            asyncResponseFTP.onAsyncResponseFTP(s);
        } else if (s.compareTo("already") == 0) {
            Snackbar.make(relativeLayout, "CV ALREADY EXISTS", Snackbar.LENGTH_LONG).show();
        } else
            Snackbar.make(relativeLayout, "FAILED TO UPLOAD/UPDATE CV", Snackbar.LENGTH_LONG).show();
    }

    public interface AsyncResponseFTP {
        void onAsyncResponseFTP(String s);
    }


}
