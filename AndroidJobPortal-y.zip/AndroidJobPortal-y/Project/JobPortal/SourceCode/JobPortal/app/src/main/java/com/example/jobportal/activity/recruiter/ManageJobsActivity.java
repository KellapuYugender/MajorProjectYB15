package com.example.jobportal.activity.recruiter;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Dialog;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.util.Pair;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.jobportal.R;
import com.example.jobportal.adapter.CompanyListAdapter;
import com.example.jobportal.adapter.JobListAdapter;
import com.example.jobportal.model.Company;
import com.example.jobportal.model.Jobs;
import com.example.jobportal.utility.Constants;
import com.example.jobportal.utility.DialogUtils;
import com.example.jobportal.utility.Helper;
import com.example.jobportal.utility.webServices.JSONParse;
import com.example.jobportal.utility.webServices.RestAPI;
import com.example.jobportal.utility.webServices.Utility;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class ManageJobsActivity extends AppCompatActivity implements View.OnClickListener {

    private RelativeLayout rlManageJobsLayout;
    private TextView  tvNoData;
    private RecyclerView rvJobs;
    private FloatingActionButton fabAddJobs;

    private Context context;
    private RestAPI restAPI;
    private JSONParse jsonParse;
    private Jobs entity;
    private List<Jobs> jobsList;
    private JobListAdapter jobsListAdapter;

    private Company company;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_jobs);

        initToolbar();
        initUI();
        initObj();

    }

    private void initToolbar() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        TextView tvTitle = toolbar.findViewById(R.id.tvTitle);
        tvTitle.setText(Constants.JOBS);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null)
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);

    }

    private void initUI() {
        rlManageJobsLayout = findViewById(R.id.rlManageJobsLayout);
        fabAddJobs = findViewById(R.id.fabAddJobs);
        tvNoData = findViewById(R.id.tvNoData);
        rvJobs = findViewById(R.id.rvJobs);

        fabAddJobs.setOnClickListener(this);

        tvNoData.setVisibility(View.VISIBLE);
        rvJobs.setVisibility(View.GONE);
    }

    private void initObj() {
        context = this;
        restAPI = new RestAPI();
        jsonParse = new JSONParse();
        entity = new Jobs();
        jobsList = new ArrayList<>();

        company = (Company) getIntent().getSerializableExtra(Constants.COMPANY);
    }

    private void loadItems() {
        new AsyncGetJobs().execute();
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (jobsListAdapter != null) {
            jobsList.clear();
            entity = new Jobs();
            rvJobs.setAdapter(null);
        }
        loadItems();
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.fabAddJobs) {
            Helper.goTo(this, AddJobsActivity.class);
        }
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void setUpRecyclerView() {
        jobsListAdapter = new JobListAdapter(this,
                jobsList);
        rvJobs.setAdapter(jobsListAdapter);
        rvJobs.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL,
                false));
        jobsListAdapter.notifyDataSetChanged();
    }

    private void saveDataToEntityAndSetupRecyclerView(JSONObject json) {
        try {
            JSONArray jsonArray = json.getJSONArray("Data");
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObj = jsonArray.getJSONObject(i);
                entity.setJobId(jsonObj.getString("data0"));
                entity.setJobName(jsonObj.getString("data1"));
                entity.setDescription(jsonObj.getString("data2"));
                entity.setDatePublished(jsonObj.getString("data3"));
                entity.setJobStartDate(jsonObj.getString("data4"));
                entity.setNoOfVacancy(jsonObj.getString("data5"));
                entity.setSummary(jsonObj.getString("data6"));
                entity.setJobPositionId(jsonObj.getString("data7"));
                entity.setJobCategory(jsonObj.getString("data8"));
                entity.setJobPlatform(jsonObj.getString("data9"));
                entity.setCompanyId(jsonObj.getString("data10"));
                entity.setMinExperience(jsonObj.getString("data11"));
                entity.setMaxExperience(jsonObj.getString("data12"));
                entity.setJobPositionName(jsonObj.getString("data15"));
                jobsList.add(entity);
                entity = new Jobs();
            }
            setUpRecyclerView();
        } catch (Exception exception) {
            exception.printStackTrace();
            Log.e(Constants.COMPANY, exception.getMessage());
        }
    }

    private class AsyncGetJobs extends AsyncTask<String, String, String> {

        private Dialog dialog;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            dialog = DialogUtils.showLoadingDialog(context, Constants.PLEASE_WAIT);
        }


        @Override
        protected String doInBackground(String... strings) {
            String a;
            try {
                JSONObject json = restAPI.GetJobByCompanyId(company.getCompanyId());
                a = jsonParse.parse(json);
            } catch (Exception e) {
                a = e.getMessage();
            }
            return a;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            DialogUtils.dismissLoadingDialog(dialog);
            try {
                if (Utility.checkConnection(s)) {
                    Pair<String, String> pair = Utility.GetErrorMessage(s);
                    Utility.ShowAlertDialog(context, pair.first, pair.second, false);
                } else {
                    //main
                    JSONObject json = new JSONObject(s);

                    //string value
                    String jsonString = json.getString("status");

                    if (jsonString.compareToIgnoreCase("no") == 0) {
                        Helper.makeSnackBar(rlManageJobsLayout, "No Data found");

                    } else if (jsonString.compareToIgnoreCase("ok") == 0) {
                        tvNoData.setVisibility(View.GONE);
                        rvJobs.setVisibility(View.VISIBLE);
                        saveDataToEntityAndSetupRecyclerView(json);
                    } else {

                        Helper.makeSnackBar(rlManageJobsLayout, "Something Went Wrong");
                    }

                }
            } catch (Exception e) {
                Helper.makeSnackBar(rlManageJobsLayout, "Something Went Wrong");
            }

        }
    }

}