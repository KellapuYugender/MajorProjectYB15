package com.example.jobportal.activity;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.Manifest;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.util.Pair;
import android.util.Patterns;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.jobportal.R;
import com.example.jobportal.activity.recruiter.AddJobsActivity;
import com.example.jobportal.model.Registration;
import com.example.jobportal.model.UserDetails;
import com.example.jobportal.utility.Constants;
import com.example.jobportal.utility.DateUtils;
import com.example.jobportal.utility.DialogUtils;
import com.example.jobportal.utility.Helper;
import com.example.jobportal.utility.PathUtils;
import com.example.jobportal.utility.PermissionUtils;
import com.example.jobportal.utility.UploadFileFTP;
import com.example.jobportal.utility.UserPref;
import com.example.jobportal.utility.webServices.JSONParse;
import com.example.jobportal.utility.webServices.RestAPI;
import com.example.jobportal.utility.webServices.Utility;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Objects;

public class ProfileActivity extends AppCompatActivity implements View.OnClickListener,
        UploadFileFTP.AsyncResponseFTP {

    private RelativeLayout rlProfileLayout;
    private LinearLayout llDetailsLayout;
    private TextView etChangePass;
    private EditText etFirstName, etLastName, etEmailId,
            etContactNumber, etSummary;
    private EditText etSSCPercentage, etHscPercentage, etGraduationPercentage,
            etPostGraduationPercentage, etWorkExperience, etSpecialization,
            etSkills, etCV;
    private ImageButton ibUpload;
    private Button btnUpdate;

    private EditText alertEtOldPass, alertEtNewPass;
    private Button alertBtnSubmitChangePass;


    private RestAPI restAPI;
    private Dialog dialog;
    private JSONParse jsonParse;
    private Context context;
    private Registration entity;
    private String userType = "";
    private String userId = "";

    private UserDetails userDetails;
    private ArrayList<String> skillList;

    private String candidateUserId = "";

    private static final int PICK_FILE_RESULT_CODE = 100;
    private static final int PERMISSION_REQUEST_CODE = 0;
    private boolean permissionGrantedAndLocationEnabled = false;
    private Intent data = null;
    private UploadFileFTP.AsyncResponseFTP asyncResponseFTP;

    private boolean updateCV = false;
    private AlertDialog alertDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        initToolbar();
        initUI();
        initObj();

    }

    private void initToolbar() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        TextView tvTitle = toolbar.findViewById(R.id.tvTitle);
        tvTitle.setText(Constants.PROFILE);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null)
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

    private void initUI() {
        rlProfileLayout = findViewById(R.id.rlProfileLayout);
        llDetailsLayout = findViewById(R.id.llDetailsLayout);
        etChangePass = findViewById(R.id.etChangePass);
        etFirstName = findViewById(R.id.etFirstName);
        etLastName = findViewById(R.id.etLastName);
        etEmailId = findViewById(R.id.etEmailId);
        etContactNumber = findViewById(R.id.etContactNumber);
        etSummary = findViewById(R.id.etSummary);
        etSSCPercentage = findViewById(R.id.etSSCPercentage);
        etHscPercentage = findViewById(R.id.etHscPercentage);
        etGraduationPercentage = findViewById(R.id.etGraduationPercentage);
        etPostGraduationPercentage = findViewById(R.id.etPostGraduationPercentage);
        etWorkExperience = findViewById(R.id.etWorkExperience);
        etSpecialization = findViewById(R.id.etSpecialization);
        etSkills = findViewById(R.id.etSkills);
        etCV = findViewById(R.id.etCV);
        ibUpload = findViewById(R.id.ibUpload);
        btnUpdate = findViewById(R.id.btnUpdate);

        etChangePass.setOnClickListener(this);
        ibUpload.setOnClickListener(this);
        btnUpdate.setOnClickListener(this);

        etCV.setEnabled(false);
        etEmailId.setEnabled(false);
        Helper.bulletPointsEditTextListener(etSkills);
        if (!UserPref.getUserType(this).trim().isEmpty()) {
            if (UserPref.getUserType(this).equalsIgnoreCase(Constants.TYPE_USER)) {
                llDetailsLayout.setVisibility(View.VISIBLE);
            } else {
                llDetailsLayout.setVisibility(View.GONE);
            }
        }
    }

    private void initObj() {
        context = this;
        entity = new Registration();
        restAPI = new RestAPI();
        jsonParse = new JSONParse();
        userType = UserPref.getUserType(this);
        userId = UserPref.getUser(this);
        userDetails = new UserDetails();

        asyncResponseFTP = this;
        candidateUserId = getIntent().getStringExtra(Constants.CANDIDATES);
        skillList = new ArrayList<>();

        if (candidateUserId != null) {
            if (!candidateUserId.trim().isEmpty()) {
                Helper.disableAllEditTexts(rlProfileLayout);
                ibUpload.setVisibility(View.GONE);
                btnUpdate.setVisibility(View.GONE);
                llDetailsLayout.setVisibility(View.VISIBLE);
                etChangePass.setVisibility(View.GONE);
                new AsyncGetProfile().execute(candidateUserId);
                new AsyncGetUserDetails().execute(candidateUserId);
                new AsyncGetSkills().execute(candidateUserId);
            }
        }
    }

    private void checkPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (PermissionUtils.neverAskAgainSelected(this)) {
                PermissionUtils.displayNeverAskAgainDialog(this);
            } else {
                permissionGrantedAndLocationEnabled = PermissionUtils.requestPermission(this, PERMISSION_REQUEST_CODE);
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        checkPermissions();
        if (candidateUserId != null) {
            if (!candidateUserId.trim().isEmpty()) {
                new AsyncGetProfile().execute(candidateUserId);
            } else {
                new AsyncGetProfile().execute(UserPref.getUser(context));
            }
        } else {
            new AsyncGetProfile().execute(UserPref.getUser(context));
        }
    }

    @Override
    public void onClick(View view) {
        if (view.getId() == R.id.btnUpdate) {
            onClickBtnUpdate();
        } else if (view.getId() == R.id.ibUpload) {
            onClickImageBtnUpload();
        } else if (view.getId() == R.id.etChangePass) {
            onClickChangePass();
        }
    }


    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (PermissionUtils.permissionGranted(requestCode, PERMISSION_REQUEST_CODE, grantResults)) {
            permissionGrantedAndLocationEnabled = true;
        } else {
            permissionGrantedAndLocationEnabled = false;
            PermissionUtils.setShouldShowStatus(this, Manifest.permission.ACCESS_COARSE_LOCATION);
        }

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_FILE_RESULT_CODE) {
            if (resultCode == RESULT_OK) {
                this.data = data;
                updateCV = true;
                if (data != null) {
                    Uri uri = data.getData();
                    String path = PathUtils.getPath(this, uri);
                    File file = new File(path);
                    etCV.setText(file.getName());
                }
            } else if (resultCode == RESULT_CANCELED) {
                Toast.makeText(this, "You cancelled the operation", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    public void onAsyncResponseFTP(String s) {
        Toast.makeText(context, "CV UPDATED", Toast.LENGTH_SHORT).show();
    }

    private void onClickChangePass() {
        View alertView = getLayoutInflater().inflate(R.layout.alert_change_password, null);

        alertEtOldPass = alertView.findViewById(R.id.etOldPass);
        alertEtNewPass = alertView.findViewById(R.id.etNewPass);
        alertBtnSubmitChangePass = alertView.findViewById(R.id.btnSubmitChangePass);

        alertBtnSubmitChangePass.setOnClickListener(view -> {
            if (isValidateForChangePass()) {
                new changePass().execute(UserPref.getUser(context),
                        alertEtOldPass.getText().toString(),
                        alertEtNewPass.getText().toString()
                );
            }
        });

        AlertDialog.Builder alert = new AlertDialog.Builder(this);
        if (alertView.getParent() != null) {
            ((ViewGroup) alertView.getParent()).removeView(alertView);
        }
        alert.setView(alertView);
        alertDialog = alert.show();
    }

    private void onClickImageBtnUpload() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("application/pdf");
        intent = Intent.createChooser(intent, "Choose a file");
        startActivityForResult(intent, PICK_FILE_RESULT_CODE);
    }

    private void onClickBtnUpdate() {
        try {
            if (isValidate()) {
                String firstName = etFirstName.getText().toString();
                String lastName = etLastName.getText().toString();
                String emailId = etEmailId.getText().toString();
                String contactNumber = etContactNumber.getText().toString();
                String summary = etSummary.getText().toString();

                if (userType.equalsIgnoreCase(Constants.TYPE_RECRUITER))
                    new AsyncUpdateRecruiterProfile().execute(
                            userId, firstName, lastName, contactNumber, summary
                    );
                else {
                    if(isDetailsValidate()){
                        setUserDetailsDataToEntity();
                        if (!etSkills.getText().toString().trim().isEmpty()) {
                            String[] split = etSkills.getText().toString().
                                    replaceAll("\\n", "").split("➼");
                            skillList = new ArrayList<>(Arrays.asList(split));
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                                skillList.replaceAll(t -> Objects.isNull(t) ? "" : t);
                            }
                        }
                        new AsyncUpdateProfile().execute(
                                userId, firstName, lastName, contactNumber, emailId, summary
                        );
                    }
                }
            }
        } catch (Exception exception) {
            Helper.makeSnackBar(rlProfileLayout, Constants.SOMETHING_WENT_WRONG);
        }
    }

    private void updateCv() {
        if (permissionGrantedAndLocationEnabled) {
            if (data != null) {
                Uri uri = data.getData();
                String path = PathUtils.getPath(this, uri);
                File file = new File(path);
                String fileName = userId + "_CV_" + DateUtils.formatDateStringForName();
                userDetails.setCv(Constants.DB_DIR_FILE_UPLOAD + fileName + ".pdf");
                new UploadFileFTP(this,
                        rlProfileLayout, asyncResponseFTP)
                        .execute(file.getPath(), Constants.DB_DIR_FILE_UPLOAD,
                                fileName);
            }
        }

    }

    private void passwordChangedRedirectToLoginDialog() {

        UserPref.deleteAll(this);
        android.app.AlertDialog.Builder alertDialog = new android.app.AlertDialog.Builder(context);
        alertDialog.setTitle("Password Changed Successfully!");
        alertDialog.setCancelable(false);
        alertDialog.setMessage("You will be redirected " +
                "to Login into the App once again, " +
                "since Password has been changed.");
        alertDialog.setNeutralButton("OK", (dialog, which) -> {
            dialog.cancel();
            Intent i = new Intent(context, MainActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
            finish();
        });
        alertDialog.show();
    }

    private boolean isValidate() {
        String required = "required";
        String error = "";

        if (etFirstName.getText().toString().trim().equals("")) {
            etFirstName.setError(required);
            etFirstName.requestFocus();
            error = required;

        } else if (etLastName.getText().toString().trim().equals("")) {
            etLastName.setError(required);
            etLastName.requestFocus();
            error = required;

        } else if (etEmailId.getText().toString().trim().equals("")) {
            etEmailId.setError(required);
            etEmailId.requestFocus();
            error = required;
        } else if (!Patterns.EMAIL_ADDRESS.matcher(etEmailId.getText().toString()).matches()) {
            etEmailId.setError("Invalid email id");
            etEmailId.requestFocus();
            error = required;
            return false;
        } else if (etContactNumber.getText().toString().equals("")) {
            etContactNumber.setError(required);
            etContactNumber.requestFocus();
            error = required;
            return false;
        } else if (!Patterns.PHONE.matcher(etContactNumber.getText().toString()).matches()) {
            etContactNumber.setError("Invalid contact");
            etContactNumber.requestFocus();
            error = required;
            return false;
        } else if (etContactNumber.getText().toString().length() < 10) {
            etContactNumber.setError("Invalid contact");
            etContactNumber.requestFocus();
            error = required;
            return false;
        } else if (UserPref.getUserType(this).equalsIgnoreCase(Constants.TYPE_USER)) {
            if (etCV.getText().toString().trim().isEmpty()) {
                etCV.setError("Documents Required");
                etCV.requestFocus();
                error = required;
                return false;
            }
        }
        return error.equals("");
    }

    private boolean isDetailsValidate() {
        String required = "required";
        String error = "";

        if (!Helper.checkPercentageValidation(etSSCPercentage, rlProfileLayout)) {
            etSSCPercentage.setError(required);
            etSSCPercentage.requestFocus();
            error = required;
        } else if (!Helper.checkPercentageValidation(etHscPercentage, rlProfileLayout)) {
            etHscPercentage.setError(required);
            etHscPercentage.requestFocus();
            error = required;
        } else if (!Helper.checkPercentageValidation(etGraduationPercentage, rlProfileLayout)) {
            etGraduationPercentage.setError(required);
            etGraduationPercentage.requestFocus();
            error = required;
        } else if (!Helper.checkPercentageValidation(etPostGraduationPercentage, rlProfileLayout)) {
            etPostGraduationPercentage.setError(required);
            etPostGraduationPercentage.requestFocus();
            error = required;
        }
        return error.equals("");
    }

    private boolean isValidateForChangePass() {
        if (alertEtOldPass.getText().toString().isEmpty()) {
            Helper.makeSnackBar(rlProfileLayout, "Enter Old Password");
            return false;
        }
        if (alertEtNewPass.getText().toString().isEmpty()) {
            Helper.makeSnackBar(rlProfileLayout, "Enter New Password");
            return false;
        } else {
            return true;
        }
    }

    private void setProfileDataToEntityAndSetText(JSONObject jsonObj) {
        try {
            entity.setFirstName(jsonObj.getString("data1"));
            entity.setLastName(jsonObj.getString("data2"));
            entity.setEmailId(jsonObj.getString("data3"));
            entity.setContactNumber(jsonObj.getString("data4"));
            entity.setPassword(jsonObj.getString("data5"));
            entity.setSummary(jsonObj.getString("data6"));

            etFirstName.setText(entity.getFirstName());
            etLastName.setText(entity.getLastName());
            etEmailId.setText(entity.getEmailId());
            etContactNumber.setText(entity.getContactNumber());
            etSummary.setText(entity.getSummary());

            if (UserPref.getUserType(this).equalsIgnoreCase(Constants.TYPE_USER)) {
                new AsyncGetUserDetails().execute(userId);
                new AsyncGetSkills().execute(userId);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void setUserDetailsDataToEntity() {
        userDetails.setUserId(userId);
        userDetails.setSscPercentage(etSSCPercentage.getText().toString());
        userDetails.setHscPercentage(etHscPercentage.getText().toString());
        userDetails.setGraduationPercentage(etGraduationPercentage.getText().toString());
        userDetails.setPostGraduationPercentage(etPostGraduationPercentage.getText().toString());
        userDetails.setWorkExperience(etWorkExperience.getText().toString());
        userDetails.setSpecialization(etSpecialization.getText().toString());
    }

    private void setUserDetailsDataToText(JSONObject json) {
        try {
            JSONArray jsonArray = json.getJSONArray("Data");
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObj = jsonArray.getJSONObject(i);
                etSSCPercentage.setText(jsonObj.getString("data2"));
                etHscPercentage.setText(jsonObj.getString("data3"));
                etGraduationPercentage.setText(jsonObj.getString("data4"));
                etPostGraduationPercentage.setText(jsonObj.getString("data5"));
                etSpecialization.setText(jsonObj.getString("data6"));
                etWorkExperience.setText(jsonObj.getString("data7"));
                etCV.setText(jsonObj.getString("data8").replace("/AJobportal/UserDocuments/", ""));
            }
        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    private void setSkillsDataToText(JSONObject json) {
        try {
            etSkills.setText("➼ ");
            JSONArray jsonArray = json.getJSONArray("Data");
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObj = jsonArray.getJSONObject(i);
                String skillName = jsonObj.getString("data2");
                etSkills.setText(etSkills.getText().toString().trim() + skillName + "\n");
            }

        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }


    private class AsyncGetProfile extends AsyncTask<String, String, String> {

        private Dialog dialog;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            dialog = DialogUtils.showLoadingDialog(context, Constants.PLEASE_WAIT);

        }

        @Override
        protected String doInBackground(String... strings) {
            String data = null;
            try {
                if (UserPref.getUserType(context).equalsIgnoreCase(Constants.TYPE_RECRUITER)) {
                    JSONObject json = restAPI.GetRecruiterProfile(strings[0]);
                    JSONParse jp = new JSONParse();
                    data = jp.parse(json);
                } else {
                    JSONObject json = restAPI.GetProfile(strings[0]);
                    JSONParse jp = new JSONParse();
                    data = jp.parse(json);
                }
            } catch (Exception e) {
                data = e.getMessage();
            }
            return data;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            DialogUtils.dismissLoadingDialog(dialog);
            try {
                if (Utility.checkConnection(s)) {
                    Pair<String, String> pair = Utility.GetErrorMessage(s);
                    Utility.ShowAlertDialog(context, pair.first, pair.second, false);
                } else {
                    JSONObject json = new JSONObject(s);
                    String StatusValue = json.getString("status");
                    if (StatusValue.compareTo("ok") == 0) {
                        JSONArray jsonArray = json.getJSONArray("Data");

                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject jsonObj = jsonArray.getJSONObject(i);
                            setProfileDataToEntityAndSetText(jsonObj);
                        }


                    } else {
                        Helper.makeSnackBar(rlProfileLayout, "Something Went Wrong");
                    }
                }
            } catch (Exception e) {
                Helper.makeSnackBar(rlProfileLayout, "Something Went Wrong");
            }
        }

    }

    private class AsyncUpdateProfile extends AsyncTask<String, String, String> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            dialog = DialogUtils.showLoadingDialog(context, "Please Wait");

        }

        @Override
        protected String doInBackground(String... strings) {
            String a;
            try {
                JSONObject json = restAPI.UpdateProfile(strings[0],
                        strings[1], strings[2], strings[3], strings[4]);
                a = jsonParse.parse(json);
            } catch (Exception e) {
                a = e.getMessage();
            }
            return a;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            DialogUtils.dismissLoadingDialog(dialog);
            if (Utility.checkConnection(s)) {
                Pair<String, String> pair = Utility.GetErrorMessage(s);
                Utility.ShowAlertDialog(context, pair.first, pair.second, false);
            } else {
                try {
                    JSONObject jsonObject = new JSONObject(s);
                    String statusValue = jsonObject.getString("status");

                    if (statusValue.compareTo("true") == 0) {
                        DialogUtils.openAlertDialog(context,
                                "Profile Updated",
                                "OK",
                                false, false).show();
                        if (updateCV) {
                            updateCv();
                        } else {
                            userDetails.setCv(Constants.DB_DIR_FILE_UPLOAD
                                    + etCV.getText().toString() + ".pdf");
                        }
                        new AsyncUpdateUserDetails().execute(
                                userId,
                                userDetails.getSscPercentage(),
                                userDetails.getHscPercentage(),
                                userDetails.getGraduationPercentage(),
                                userDetails.getPostGraduationPercentage(),
                                userDetails.getWorkExperience(),
                                userDetails.getSpecialization(),
                                userDetails.getCv()
                        );

                    } else {
                        Helper.makeSnackBar(rlProfileLayout, Constants.SOMETHING_WENT_WRONG);
                    }
                } catch (Exception e) {
                    Helper.makeSnackBar(rlProfileLayout, Constants.SOMETHING_WENT_WRONG);
                    e.printStackTrace();
                }
            }
        }
    }

    private class AsyncUpdateUserDetails extends AsyncTask<String, String, String> {

        private Dialog dialog;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            dialog = DialogUtils.showLoadingDialog(context, Constants.SAVING);

        }

        @Override
        protected String doInBackground(String... strings) {
            String a;
            try {
                JSONObject json = restAPI.UpdateUserDetails(strings[0],
                        strings[1], strings[2], strings[3], strings[4],
                        strings[5], strings[6], strings[7]);
                a = jsonParse.parse(json);
            } catch (Exception e) {
                a = e.getMessage();
            }
            return a;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            DialogUtils.dismissLoadingDialog(dialog);
            if (Utility.checkConnection(s)) {
                Pair<String, String> pair = Utility.GetErrorMessage(s);
                Utility.ShowAlertDialog(context, pair.first, pair.second, false);
            } else {
                try {
                    JSONObject jsonObject = new JSONObject(s);
                    String statusValue = jsonObject.getString("status");
                    if (statusValue.compareTo("true") == 0) {
                        if (skillList.size() > -1) {
                            new AsyncAddSkills().execute(userId);
                        }
                        DialogUtils.openAlertDialog(context,
                                "Details Updated",
                                "OK",
                                false,
                                true);
                    } else {
                        Helper.makeSnackBar(rlProfileLayout, Constants.SOMETHING_WENT_WRONG);
                    }
                } catch (Exception e) {
                    Helper.makeSnackBar(rlProfileLayout, Constants.SOMETHING_WENT_WRONG);
                    e.printStackTrace();
                }
            }
        }
    }

    private class AsyncUpdateRecruiterProfile extends AsyncTask<String, String, String> {


        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            dialog = DialogUtils.showLoadingDialog(context, "Please Wait");

        }

        @Override
        protected String doInBackground(String... strings) {
            String a;
            try {
                JSONObject json = restAPI.UpdateRecruiterProfile(strings[0], strings[1],
                        strings[2], strings[3], strings[4]);
                a = jsonParse.parse(json);
            } catch (Exception e) {
                a = e.getMessage();
            }
            return a;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            DialogUtils.dismissLoadingDialog(dialog);
            if (Utility.checkConnection(s)) {
                Pair<String, String> pair = Utility.GetErrorMessage(s);
                Utility.ShowAlertDialog(context, pair.first, pair.second, false);
            } else {
                try {
                    JSONObject jsonObject = new JSONObject(s);
                    String statusValue = jsonObject.getString("status");

                    if (statusValue.compareTo("true") == 0) {
                        UserPref.deleteAll(context);
                        DialogUtils.openAlertDialog(context,
                                "Profile Updated",
                                "OK",
                                false, false).show();

                    } else {
                        Helper.makeSnackBar(rlProfileLayout, Constants.SOMETHING_WENT_WRONG);
                    }
                } catch (Exception e) {
                    Helper.makeSnackBar(rlProfileLayout, Constants.SOMETHING_WENT_WRONG);
                    e.printStackTrace();
                }
            }
        }
    }

    private class AsyncAddSkills extends AsyncTask<String, String, String> {

        private Dialog dialog;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            dialog = DialogUtils.showLoadingDialog(context, Constants.SAVING);

        }

        @Override
        protected String doInBackground(String... strings) {
            String a;
            try {
                JSONObject json = restAPI.AddUserSkills(strings[0], skillList);
                a = jsonParse.parse(json);
            } catch (Exception e) {
                a = e.getMessage();
            }
            return a;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            DialogUtils.dismissLoadingDialog(dialog);
            if (Utility.checkConnection(s)) {
                Pair<String, String> pair = Utility.GetErrorMessage(s);
                Utility.ShowAlertDialog(context, pair.first, pair.second, false);
            } else {
                try {
                    JSONObject jsonObject = new JSONObject(s);
                    String statusValue = jsonObject.getString("status");
                    if (statusValue.compareTo("true") != 0) {
                        Toast.makeText(context, Constants.SOMETHING_WENT_WRONG
                                + "\nSkills cannot be updated", Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception e) {
                    Helper.makeSnackBar(rlProfileLayout, Constants.SOMETHING_WENT_WRONG);
                    e.printStackTrace();
                }
            }
        }
    }

    private class AsyncGetUserDetails extends AsyncTask<String, String, String> {

        private Dialog dialog;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            dialog = DialogUtils.showLoadingDialog(context, Constants.PLEASE_WAIT);
        }


        @Override
        protected String doInBackground(String... strings) {
            String a;
            try {
                JSONObject json = restAPI.GetUserDetails(strings[0]);
                a = jsonParse.parse(json);
            } catch (Exception e) {
                a = e.getMessage();
            }
            return a;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            dialog.dismiss();
            try {
                if (Utility.checkConnection(s)) {
                    Pair<String, String> pair = Utility.GetErrorMessage(s);
                    Utility.ShowAlertDialog(context, pair.first, pair.second, false);
                } else {
                    //main
                    JSONObject json = new JSONObject(s);

                    //string value
                    String jsonString = json.getString("status");

                    if (jsonString.compareToIgnoreCase("no") == 0) {
                    } else if (jsonString.compareToIgnoreCase("ok") == 0) {
                        setUserDetailsDataToText(json);
                    }

                }
            } catch (Exception e) {
                e.printStackTrace();
            }

        }
    }

    private class AsyncGetSkills extends AsyncTask<String, String, String> {

        private Dialog dialog;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            dialog = DialogUtils.showLoadingDialog(context, Constants.PLEASE_WAIT);
        }


        @Override
        protected String doInBackground(String... strings) {
            String a;
            try {
                JSONObject json = restAPI.GetUserSkills(userId);
                a = jsonParse.parse(json);
            } catch (Exception e) {
                a = e.getMessage();
            }
            return a;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            dialog.dismiss();
            try {
                if (Utility.checkConnection(s)) {
                    Pair<String, String> pair = Utility.GetErrorMessage(s);
                    Utility.ShowAlertDialog(context, pair.first, pair.second, false);
                } else {
                    //main
                    JSONObject json = new JSONObject(s);

                    //string value
                    String jsonString = json.getString("status");

                    if (jsonString.compareToIgnoreCase("no") == 0) {
                    } else if (jsonString.compareToIgnoreCase("ok") == 0) {
                        setSkillsDataToText(json);
                    }

                }
            } catch (Exception e) {
                e.printStackTrace();
            }

        }
    }

    private class changePass extends AsyncTask<String, JSONObject, String> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            dialog = DialogUtils.showLoadingDialog(context, Constants.PLEASE_WAIT);
        }

        @Override
        protected String doInBackground(String... strings) {
            String data = null;
            JSONObject json = null;

            try {
                if (UserPref.getUserType(context).equalsIgnoreCase(Constants.TYPE_USER)) {
                    json = restAPI.ChangePassword(strings[0], strings[1], strings[2]);
                } else {
                    json = restAPI.ChangeRecruiterPassword(strings[0], strings[1], strings[2]);
                }
                JSONParse jp = new JSONParse();
                data = jp.parse(json);
            } catch (Exception e) {
                data = e.getMessage();
            }
            return data;
        }


        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            DialogUtils.dismissLoadingDialog(dialog);
            try {
                if (Utility.checkConnection(s)) {
                    Pair<String, String> pair = Utility.GetErrorMessage(s);
                    Utility.ShowAlertDialog(context, pair.first, pair.second, false);
                } else {
                    JSONObject json = new JSONObject(s);
                    String StatusValue = json.getString("status");
                    if (StatusValue.compareTo("false") == 0) {
                        Helper.makeSnackBar(rlProfileLayout, "Wrong Password");
                    } else if (StatusValue.compareTo("true") == 0) {
                        Helper.makeSnackBar(rlProfileLayout, "Password Updated Successfully");
                        alertEtOldPass.setText("");
                        alertEtNewPass.setText("");
                        if (alertDialog != null) {
                            if (alertDialog.isShowing()) {
                                alertDialog.dismiss();
                            }
                        }
                        passwordChangedRedirectToLoginDialog();

                    } else {
                        Helper.makeSnackBar(rlProfileLayout, "Something Went Wrong");
                    }
                }
            } catch (Exception e) {
                Helper.makeSnackBar(rlProfileLayout, "Something Went Wrong");
            }
        }
    }

}