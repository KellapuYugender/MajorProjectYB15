package com.example.jobportal.utility;

public class Constants {

    ////////////////////// SHARED PREF //////////////////////

    public static final String SITE_NAME = "182.50.132.7";
    public static final String USER_NAME = "Hostoise";
    public static final String PASSWORD = "ys73!e2P";
    public static final String DB_DIR_FILE_UPLOAD = "/AJobportal/UserDocuments/";

    ////////////////////// SHARED PREF //////////////////////

    public static final String SHARED_PREF = "jobPortal";
    public static final String BOOL_IS_LOGGED_IN = "isLoggedIn";

    public static final String LOGGED_IN_ID = "userId";
    public static final String USER_TYPE = "userType";
    public static final String TYPE_RECRUITER = "loggedInAsRecruiter";
    public static final String TYPE_USER = "loggedInAsUser";
    public static final String BOOL_PROFILE_COMPLETION_STATUS = "profileCompletionStatus";


    ////////////////////// SCREENS/ACTIVITY //////////////////////

    public static final String REGISTER = "Register";
    public static final String UPDATE_PROFILE = "Update Profile";

    ////////////////////// SCREENS/ACTIVITY //////////////////////

    public static final String PROFILE = "Profile";
    public static final String POST_JOB = "Post Job";
    public static final String JOB_POSITION = "Job Position";
    public static final String JOB_DETAILS = "Job Details";
    public static final String HISTORY = "Application History";
    public static final String CHATS = "Chats";



    ////////////////////// OTHERS //////////////////////
    public static final String SOMETHING_WENT_WRONG = "Something Went Wrong!!!";
    public static final String UPDATE = "Update";
    public static final String COMPANY = "Company";
    public static final String CANDIDATES = "Candidates";
    public static final String JOBS = "Jobs";
    public static final String ADD_DETAILS = "Add Details";
    public static final String UPDATE_DETAILS = "Update Details";
    public static final String SEARCH_JOB = "Search Job";
    public static final String USER = "User";
    public static final String RECRUITER = "RECRUITER";


    ////////////////////// DIALOG //////////////////////
    public static final String PLEASE_WAIT = "PLEASE WAIT!!!";
    public static final String UPDATING = "Updating...";
    public static final String SAVING = "Saving...";
    public static final String UPLOADING = "Uploading Documents...";


    ////////////////////// JOB_FILTERS //////////////////////

    public static final String SKILLS = "skills: ";
    public static final String SSC_PERCENT = "ssc: ";
    public static final String HSC_PERCENT = "hsc: ";
    public static final String GRADUATE_PERCENT = "graduation: ";
    public static final String POST_GRADUATE_PERCENT = "pg: ";
    public static final String SPECIALIZATION = "sp: ";
    public static final String COMPANY_FILTER = "companyName: ";
    public static final String ALL_JOBS = "all: ";
    public static final String JOB_NAME = "jobName: ";
    public static final String NAME = "name: ";
    public static final String WORK_EXPERIENCE = "exp: ";
    public static final String ACCEPTED = "Accepted";
    public static final String PENDING = "Pending";
    public static final String REJECTED = "Rejected";
}
