package com.example.jobportal.utility;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.StrictMode;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;


import com.example.jobportal.R;
import com.example.jobportal.activity.user.DashboardActivity;

import java.util.Random;


public class NotificationUtil {
    private static final String TAG = NotificationUtil.class.getSimpleName();
    private static final String CHANNELID = "JobPortal";
    private Context context;

    public NotificationUtil(Context context) {
        this.context = context;
    }

    public void showNotification(String title, String message) {

        StrictMode.VmPolicy.Builder sb = new StrictMode.VmPolicy.Builder();
        StrictMode.setVmPolicy(sb.build());
        sb.detectFileUriExposure();

        int randomValue = new Random().nextInt(10000) + 1;

        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);

        createNotificationChannel(context, CHANNELID);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNELID);

        builder.setSmallIcon(R.drawable.logo_24px)
                .setWhen(System.currentTimeMillis())
                .setContentTitle(title)
                .setContentText(message);

        Notification n = builder.build();
        nm.notify("NotiTag", randomValue, n);
    }

    public static void createNotificationChannel(@NonNull Context context, @NonNull String CHANNEL_ID) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "JobPortal";
            String description = "Job Portal notification";
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, name, importance);
            channel.setDescription(description);
            NotificationManager notificationManager = context.getSystemService(NotificationManager.class);
            if (notificationManager != null) {
                notificationManager.createNotificationChannel(channel);
            } else {
                Log.d("NotificationLog", "NotificationManagerNull");
            }
        }
    }
}
