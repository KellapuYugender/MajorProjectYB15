package com.example.jobportal.adapter;

import android.app.Dialog;
import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;
import android.util.Pair;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.jobportal.R;
import com.example.jobportal.activity.ChatsActivity;
import com.example.jobportal.activity.user.ViewJobDetailsOrApplyActivity;
import com.example.jobportal.model.Jobs;
import com.example.jobportal.model.UserApplicant;
import com.example.jobportal.utility.Constants;
import com.example.jobportal.utility.DialogUtils;
import com.example.jobportal.utility.Helper;
import com.example.jobportal.utility.webServices.JSONParse;
import com.example.jobportal.utility.webServices.RestAPI;
import com.example.jobportal.utility.webServices.Utility;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class UserApplicantHistoryAdapter extends RecyclerView.Adapter<UserApplicantHistoryAdapter.ViewHolder> {
    private Context context;
    private RelativeLayout relativeLayout;
    private final List<UserApplicant> userApplicantList;
    private UserApplicant userApplicant;

    private RestAPI restAPI;
    private JSONParse jsonParse;
    private Jobs jobs;
    private List<Jobs> jobsList;

    private boolean isChat = false;


    public UserApplicantHistoryAdapter(Context context, RelativeLayout relativeLayout, List<UserApplicant> userApplicantList) {
        this.context = context;
        this.userApplicantList = userApplicantList;
        this.relativeLayout = relativeLayout;

        restAPI = new RestAPI();
        jsonParse = new JSONParse();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        context = parent.getContext();
        LayoutInflater inflater = LayoutInflater.from(context);
        View detailItem = inflater.inflate(R.layout.list_user_applicant_history, parent, false);
        return new ViewHolder(detailItem);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        if (userApplicantList.size() != 0) {
            userApplicant = userApplicantList.get(position);
            holder.tvDateOfApplications.setText(userApplicant.getDateOfApplication());
            holder.tvStatus.setText(userApplicant.getStatus());
            holder.tvChat.setOnClickListener(view -> {
                isChat = true;
                new AsyncSearchJobByParams().execute("[Jobs].jobId", userApplicant.getJobId());
            });
            holder.tvViewJobDetails.setOnClickListener(view -> {
                isChat = false;
                new AsyncSearchJobByParams().execute("[Jobs].jobId", userApplicant.getJobId());
            });
        }
    }

    @Override
    public int getItemCount() {
        return userApplicantList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        private final RelativeLayout rlListApplicantLayout;
        private final TextView tvDateOfApplications;
        private final TextView tvStatus;
        private final TextView tvViewJobDetails;
        private final TextView tvChat;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            rlListApplicantLayout = itemView.findViewById(R.id.rlListApplicantLayout);
            tvDateOfApplications = itemView.findViewById(R.id.tvDateOfApplications);
            tvStatus = itemView.findViewById(R.id.tvStatus);
            tvViewJobDetails = itemView.findViewById(R.id.tvViewJobDetails);
            tvChat = itemView.findViewById(R.id.tvChat);
        }
    }

    private void saveDataToEntityAndSetupRecyclerView(JSONObject json) {
        try {
            JSONArray jsonArray = json.getJSONArray("Data");
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObj = jsonArray.getJSONObject(i);
                jobs.setJobId(jsonObj.getString("data0"));
                jobs.setJobName(jsonObj.getString("data1"));
                jobs.setDescription(jsonObj.getString("data2"));
                jobs.setJobStartDate(jsonObj.getString("data4"));
                jobs.setNoOfVacancy(jsonObj.getString("data5"));
                jobs.setSummary(jsonObj.getString("data6"));
                jobs.setJobCategory(jsonObj.getString("data8"));
                jobs.setJobPlatform(jsonObj.getString("data9"));
                jobs.setMinExperience(jsonObj.getString("data11"));
                jobs.setMaxExperience(jsonObj.getString("data12"));
                jobs.setRecruiterId(jsonObj.getString("data13"));
                jobs.setCompanyName(jsonObj.getString("data15"));
                jobs.setJobPositionName(jsonObj.getString("data18"));
                jobsList.add(jobs);
                jobs = new Jobs();
            }
        } catch (Exception exception) {
            exception.printStackTrace();
            Log.e(Constants.COMPANY, exception.getMessage());
        }
    }

    private class AsyncSearchJobByParams extends AsyncTask<String, String, String> {
        private Dialog dialog;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            jobsList = new ArrayList<>();
            jobs = new Jobs();
            dialog = DialogUtils.showLoadingDialog(context, Constants.PLEASE_WAIT);

        }

        @Override
        protected String doInBackground(String... strings) {
            String a;
            try {
                JSONObject json = restAPI.ViewFilteredJobs(strings[0], strings[1]);
                a = jsonParse.parse(json);
            } catch (Exception e) {
                a = e.getMessage();
            }
            return a;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            try {
                if (Utility.checkConnection(s)) {
                    Pair<String, String> pair = Utility.GetErrorMessage(s);
                    Utility.ShowAlertDialog(context, pair.first, pair.second, false);
                } else {
                    //main
                    JSONObject json = new JSONObject(s);

                    //string value
                    String jsonString = json.getString("status");

                    if (jsonString.compareToIgnoreCase("no") == 0) {
                        DialogUtils.dismissLoadingDialog(dialog);
                        Helper.makeSnackBar(relativeLayout, "No Data found");

                    } else if (jsonString.compareToIgnoreCase("ok") == 0) {
                        saveDataToEntityAndSetupRecyclerView(json);
                        DialogUtils.dismissLoadingDialog(dialog);
                        if (isChat){
                            Helper.goTo(context, ChatsActivity.class,
                                    Constants.CHATS, jobsList.get(0).getRecruiterId());
                        }else{
                            Helper.goTo(context, ViewJobDetailsOrApplyActivity.class,
                                    Constants.JOBS, jobsList.get(0));
                        }

                    } else {
                        DialogUtils.dismissLoadingDialog(dialog);
                        Helper.makeSnackBar(relativeLayout, "Something Went Wrong");
                    }

                }
            } catch (Exception e) {
                DialogUtils.dismissLoadingDialog(dialog);
                Helper.makeSnackBar(relativeLayout, "Something Went Wrong");
            }
        }
    }
}
