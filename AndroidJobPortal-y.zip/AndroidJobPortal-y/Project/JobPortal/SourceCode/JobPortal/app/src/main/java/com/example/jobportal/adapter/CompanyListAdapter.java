package com.example.jobportal.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.jobportal.R;
import com.example.jobportal.activity.recruiter.AddCompanyActivity;
import com.example.jobportal.activity.recruiter.ManageJobsActivity;
import com.example.jobportal.model.Company;
import com.example.jobportal.utility.Constants;
import com.example.jobportal.utility.Helper;

import java.io.Serializable;
import java.util.List;

public class CompanyListAdapter extends RecyclerView.Adapter<CompanyListAdapter.ViewHolder> implements View.OnClickListener {

    private Context context;
    private final List<Company> companyList;
    private Company company;


    public CompanyListAdapter(Context context, List<Company> companyList) {
        this.context = context;
        this.companyList = companyList;
    }

    @NonNull
    @Override
    public CompanyListAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        context = parent.getContext();
        LayoutInflater inflater = LayoutInflater.from(context);
        View detailItem = inflater.inflate(R.layout.list_company, parent, false);
        return new ViewHolder(detailItem);
    }

    @Override
    public void onBindViewHolder(@NonNull CompanyListAdapter.ViewHolder holder, int position) {
        if (companyList.size() != 0) {
            company = companyList.get(position);
            holder.tvCompanyName.setText(company.getCompanyName());
            holder.tvDescription.setText(company.getCompanyDescription());
            holder.tvEdit.setOnClickListener(this);
            holder.tvViewJobs.setOnClickListener(this);
        }
    }

    @Override
    public int getItemCount() {
        return companyList.size();
    }

    @SuppressLint("NonConstantResourceId")
    @Override
    public void onClick(View view) {
        try {
            switch (view.getId()) {
                case R.id.tvEdit:
                    Helper.goTo(context, AddCompanyActivity.class, Constants.COMPANY,
                            (Serializable) company);
                    break;
                case R.id.tvViewJobs:
                    Helper.goTo(context, ManageJobsActivity.class, Constants.COMPANY,
                            (Serializable) company);
                    break;
            }
        } catch (Exception e) {
            Toast.makeText(context, Constants.SOMETHING_WENT_WRONG, Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        private final RelativeLayout rlListCompanyLayout;
        private final TextView tvCompanyName;
        private final TextView tvDescription;
        private final TextView tvEdit;
        private final TextView tvViewJobs;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            rlListCompanyLayout = itemView.findViewById(R.id.rlListCompanyLayout);
            tvCompanyName = itemView.findViewById(R.id.tvCompanyName);
            tvDescription = itemView.findViewById(R.id.tvDescription);
            tvEdit = itemView.findViewById(R.id.tvEdit);
            tvViewJobs = itemView.findViewById(R.id.tvViewJobs);
        }
    }
}
