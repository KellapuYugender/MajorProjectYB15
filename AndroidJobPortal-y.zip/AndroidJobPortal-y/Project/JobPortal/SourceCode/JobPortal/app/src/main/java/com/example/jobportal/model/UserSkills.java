package com.example.jobportal.model;

public class UserSkills {

    private String userSkillsId,userId,skills;

    public String getUserSkillsId() {
        return userSkillsId;
    }

    public void setUserSkillsId(String userSkillsId) {
        this.userSkillsId = userSkillsId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getSkills() {
        return skills;
    }

    public void setSkills(String skills) {
        this.skills = skills;
    }
}
