package com.example.jobportal.utility.webServices;

import org.json.JSONObject;

public class JSONParse {

    public String parse(JSONObject json) {
        try {
            return json.getString("Value");
        } catch (Exception e) {
            return e.getMessage();
        }
    }
}

