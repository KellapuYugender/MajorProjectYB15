package com.example.jobportal.activity.user;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.jobportal.R;

public class UserDetailsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_details);
    }
}