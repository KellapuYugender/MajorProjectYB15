package com.example.jobportal.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Dialog;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.util.Pair;
import android.view.MenuItem;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.jobportal.R;
import com.example.jobportal.adapter.JobListAdapter;
import com.example.jobportal.adapter.RecentChatListAdapter;
import com.example.jobportal.model.Chats;
import com.example.jobportal.model.Company;
import com.example.jobportal.model.Jobs;
import com.example.jobportal.utility.Constants;
import com.example.jobportal.utility.DialogUtils;
import com.example.jobportal.utility.Helper;
import com.example.jobportal.utility.webServices.JSONParse;
import com.example.jobportal.utility.webServices.RestAPI;
import com.example.jobportal.utility.webServices.Utility;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class RecentChatsActivity extends AppCompatActivity {

    private RelativeLayout rlRecentChats;
    private TextView tvNoData;
    private RecyclerView rvRecentChats;

    private Context context;
    private RestAPI restAPI;
    private JSONParse jsonParse;

    private Chats entity;
    private List<Chats> chatsList;
    private RecentChatListAdapter chatListAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recent_chats);

        initToolbar();
        initUI();
        initObj();

    }

    private void initToolbar() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        TextView tvTitle = toolbar.findViewById(R.id.tvTitle);
        tvTitle.setText(Constants.JOBS);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null)
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);

    }

    private void initUI() {
        rlRecentChats = findViewById(R.id.rlRecentChats);
        tvNoData = findViewById(R.id.tvNoData);
        rvRecentChats = findViewById(R.id.rvRecentChats);

        tvNoData.setVisibility(View.VISIBLE);
        rvRecentChats.setVisibility(View.GONE);
    }

    private void initObj() {
        context = this;
        restAPI = new RestAPI();
        jsonParse = new JSONParse();
        entity = new Chats();
        chatsList = new ArrayList<>();
    }

    private void loadItems() {
        new AsyncGetJobs().execute();
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (chatListAdapter != null) {
            chatsList.clear();
            entity = new Chats();
            rvRecentChats.setAdapter(null);
        }
        loadItems();
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void setUpRecyclerView() {
        chatListAdapter = new RecentChatListAdapter(this,
                chatsList);
        rvRecentChats.setAdapter(chatListAdapter);
        rvRecentChats.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL,
                false));
        chatListAdapter.notifyDataSetChanged();
    }

    private void saveDataToEntityAndSetupRecyclerView(JSONObject json) {
        try {
            JSONArray jsonArray = json.getJSONArray("Data");
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObj = jsonArray.getJSONObject(i);
                entity.setUserName(jsonObj.getString("data0"));
                entity.setMessage(jsonObj.getString("data1"));
                chatsList.add(entity);
                entity = new Chats();
            }
            setUpRecyclerView();
        } catch (Exception exception) {
            exception.printStackTrace();
            Log.e(Constants.COMPANY, exception.getMessage());
        }
    }

    private class AsyncGetJobs extends AsyncTask<String, String, String> {

        private Dialog dialog;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            dialog = DialogUtils.showLoadingDialog(context, Constants.PLEASE_WAIT);
        }


        @Override
        protected String doInBackground(String... strings) {
            String a;
            try {
                JSONObject json = restAPI.GetJobByCompanyId(strings[0]);
                a = jsonParse.parse(json);
            } catch (Exception e) {
                a = e.getMessage();
            }
            return a;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            DialogUtils.dismissLoadingDialog(dialog);
            try {
                if (Utility.checkConnection(s)) {
                    Pair<String, String> pair = Utility.GetErrorMessage(s);
                    Utility.ShowAlertDialog(context, pair.first, pair.second, false);
                } else {
                    //main
                    JSONObject json = new JSONObject(s);

                    //string value
                    String jsonString = json.getString("status");

                    if (jsonString.compareToIgnoreCase("no") == 0) {
                        Helper.makeSnackBar(rlRecentChats, "No Data found");

                    } else if (jsonString.compareToIgnoreCase("ok") == 0) {
                        tvNoData.setVisibility(View.GONE);
                        rvRecentChats.setVisibility(View.VISIBLE);
                        saveDataToEntityAndSetupRecyclerView(json);
                    } else {

                        Helper.makeSnackBar(rlRecentChats, "Something Went Wrong");
                    }

                }
            } catch (Exception e) {
                Helper.makeSnackBar(rlRecentChats, "Something Went Wrong");
            }

        }
    }

}