package com.example.jobportal.fragments;

import android.app.Dialog;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.util.Pair;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.jobportal.R;
import com.example.jobportal.adapter.UserApplicantHistoryAdapter;
import com.example.jobportal.model.UserApplicant;
import com.example.jobportal.utility.Constants;
import com.example.jobportal.utility.DialogUtils;
import com.example.jobportal.utility.Helper;
import com.example.jobportal.utility.UserPref;
import com.example.jobportal.utility.webServices.JSONParse;
import com.example.jobportal.utility.webServices.RestAPI;
import com.example.jobportal.utility.webServices.Utility;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class PendingApplicationFragment extends Fragment {

    private RelativeLayout rlManageCandidateLayout;
    private TextView tvNoData;
    private RecyclerView rvCandidate;

    private Context context;
    private RestAPI restAPI;
    private JSONParse jsonParse;
    private UserApplicant entity;
    private List<UserApplicant> userApplicantList;
    private UserApplicantHistoryAdapter userApplicantListAdapter;

    private String userId;

    public PendingApplicationFragment() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View inflate = inflater.inflate(R.layout.fragment_accepted, container, false);
        initUI(inflate);
        initObj();
        return inflate;
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        this.context = context;
    }

    private void initUI(View inflate) {
        rlManageCandidateLayout = inflate.findViewById(R.id.rlManageCandidateLayout);
        tvNoData = inflate.findViewById(R.id.tvNoData);
        rvCandidate = inflate.findViewById(R.id.rvCandidate);

        tvNoData.setVisibility(View.VISIBLE);
        rvCandidate.setVisibility(View.GONE);
    }

    private void initObj() {
        restAPI = new RestAPI();
        jsonParse = new JSONParse();
        entity = new UserApplicant();
        userApplicantList = new ArrayList<>();

        userId = UserPref.getUser(context);
    }

    private void loadItems() {
        new AsyncGetAcceptedApplication().execute(userId);
    }

    @Override
    public void onViewStateRestored(@Nullable Bundle savedInstanceState) {
        super.onViewStateRestored(savedInstanceState);
        if (userApplicantListAdapter != null) {
            userApplicantList.clear();
            entity = new UserApplicant();
            rvCandidate.setAdapter(null);
        }
        loadItems();
    }


    private void setUpRecyclerView() {
        if (userApplicantList.size() > 0){
            userApplicantListAdapter = new UserApplicantHistoryAdapter(context,rlManageCandidateLayout,
                    userApplicantList);
            rvCandidate.setAdapter(userApplicantListAdapter);
            rvCandidate.setLayoutManager(new LinearLayoutManager(context, LinearLayoutManager.VERTICAL,
                    false));
            userApplicantListAdapter.notifyDataSetChanged();
        }else{
            tvNoData.setVisibility(View.VISIBLE);
            rvCandidate.setVisibility(View.GONE);
        }
    }

    private class AsyncGetAcceptedApplication extends AsyncTask<String, String, String> {

        private Dialog dialog;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            dialog = DialogUtils.showLoadingDialog(context, Constants.PLEASE_WAIT);
        }


        @Override
        protected String doInBackground(String... strings) {
            String a;
            try {
                JSONObject json = restAPI.GetUserApplicationByUserId(strings[0]);
                a = jsonParse.parse(json);
            } catch (Exception e) {
                a = e.getMessage();
            }
            return a;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            DialogUtils.dismissLoadingDialog(dialog);
            try {
                if (Utility.checkConnection(s)) {
                    Pair<String, String> pair = Utility.GetErrorMessage(s);
                    Utility.ShowAlertDialog(context, pair.first, pair.second, false);
                } else {
                    //main
                    JSONObject json = new JSONObject(s);

                    //string value
                    String jsonString = json.getString("status");

                    if (jsonString.compareToIgnoreCase("no") == 0) {
                    } else if (jsonString.compareToIgnoreCase("ok") == 0) {
                        tvNoData.setVisibility(View.GONE);
                        rvCandidate.setVisibility(View.VISIBLE);
                        saveDataToEntityAndSetupRecyclerView(json);
                    } else {
                        Helper.makeSnackBar(rlManageCandidateLayout, "Something Went Wrong");
                    }

                }
            } catch (Exception e) {
                Helper.makeSnackBar(rlManageCandidateLayout, "Something Went Wrong");
            }

        }
    }

    private void saveDataToEntityAndSetupRecyclerView(JSONObject json) {
        try {
            JSONArray jsonArray = json.getJSONArray("Data");
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObj = jsonArray.getJSONObject(i);
                String status = jsonObj.getString("data4");
                if (status.equalsIgnoreCase(Constants.PENDING)){
                    entity.setApplicantId(jsonObj.getString("data0"));
                    entity.setUserId(jsonObj.getString("data1"));
                    entity.setJobId(jsonObj.getString("data2"));
                    entity.setDateOfApplication(jsonObj.getString("data3"));
                    entity.setStatus(jsonObj.getString("data4"));
                    userApplicantList.add(entity);
                }
                entity = new UserApplicant();
            }
            setUpRecyclerView();
        } catch (Exception exception) {
            exception.printStackTrace();
            Log.e(Constants.COMPANY, exception.getMessage());
        }
    }
}