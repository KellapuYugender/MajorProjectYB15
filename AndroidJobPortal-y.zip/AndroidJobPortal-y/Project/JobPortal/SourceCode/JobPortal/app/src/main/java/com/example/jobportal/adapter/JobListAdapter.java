package com.example.jobportal.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.jobportal.R;
import com.example.jobportal.activity.recruiter.AddJobsActivity;
import com.example.jobportal.activity.recruiter.ManageCandidatesActivity;
import com.example.jobportal.model.Jobs;
import com.example.jobportal.utility.Constants;
import com.example.jobportal.utility.Helper;

import java.io.Serializable;
import java.util.List;

public class JobListAdapter extends RecyclerView.Adapter<JobListAdapter.ViewHolder> implements View.OnClickListener {

    private Context context;
    private final List<Jobs> jobsList;
    private Jobs jobs;


    public JobListAdapter(Context context, List<Jobs> jobsList) {
        this.context = context;
        this.jobsList = jobsList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        context = parent.getContext();
        LayoutInflater inflater = LayoutInflater.from(context);
        View detailItem = inflater.inflate(R.layout.list_jobs, parent, false);
        return new ViewHolder(detailItem);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        if (jobsList.size() != 0) {
            jobs = jobsList.get(position);
            holder.tvJobName.setText(jobs.getJobName());
            holder.tvJobDatePublished.setText(jobs.getDatePublished());
            holder.tvJobPosition.setText(jobs.getJobPositionName());
            holder.tvManage.setOnClickListener(this);
            holder.tvViewCandidates.setOnClickListener(this);
        }
    }

    @Override
    public int getItemCount() {
        return jobsList.size();
    }

    @SuppressLint("NonConstantResourceId")
    @Override
    public void onClick(View view) {
        try {
            switch (view.getId()) {
                case R.id.tvManage:
                    Helper.goTo(context, AddJobsActivity.class, Constants.JOBS,
                            (Serializable) jobs);
                    break;
                case R.id.tvViewCandidates:
                    Helper.goTo(context, ManageCandidatesActivity.class, Constants.CANDIDATES,
                            (Serializable) jobs);
                    break;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        private final TextView tvJobName;
        private final TextView tvJobPosition;
        private final TextView tvJobDatePublished;
        private final TextView tvManage;
        private final TextView tvViewCandidates;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvJobName = itemView.findViewById(R.id.tvJobName);
            tvJobPosition = itemView.findViewById(R.id.tvJobPosition);
            tvJobDatePublished = itemView.findViewById(R.id.tvJobDatePublished);
            tvManage = itemView.findViewById(R.id.tvManage);
            tvViewCandidates = itemView.findViewById(R.id.tvViewCandidates);
        }
    }
}
