package com.example.jobportal.utility;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.view.View;
import android.widget.TextView;

import com.example.jobportal.R;
import com.example.jobportal.activity.MainActivity;

public class DialogUtils {

    public static Dialog showLoadingDialog(Context context, String message) {
        Dialog dialog = new Dialog(context, R.style.Theme_AppCompat_Dialog);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.parseColor("#00000000")));
        dialog.setContentView(R.layout.loading);
        TextView tvLoadingText = dialog.findViewById(R.id.tvLoadingText);
        if (message.trim().isEmpty()) {
            tvLoadingText.setVisibility(View.GONE);
        } else {
            tvLoadingText.setText(message);
            tvLoadingText.setVisibility(View.VISIBLE);
        }
        dialog.setCancelable(false);
        dialog.show();
        return dialog;
    }

    public static void dismissLoadingDialog(Dialog dialog) {
        if (dialog != null && dialog.isShowing()) {
            try {
                dialog.dismiss();
            } catch (Exception exception) {
                dialog.cancel();
                exception.printStackTrace();
            }
        }
    }

    public static void forceLogout(Context context) {
        AlertDialog.Builder alertDialog = new AlertDialog.Builder(context);
        alertDialog.setTitle("Unauthorized");
        alertDialog.setCancelable(false);
        alertDialog.setMessage("Unauthorized user found, Please login again");
        alertDialog.setNeutralButton("Login again", (dialog, which) -> {
            dialog.cancel();
            Intent i = new Intent(context, MainActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(i);
            ((Activity) context).finish();
        });
        alertDialog.show();
    }

    public static AlertDialog openAlertDialog(final Context context, String message, String positiveBtnText,
                                              boolean showNegativeBtn, boolean isFinish) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setMessage(message);

        builder.setPositiveButton(positiveBtnText, (dialog, id) -> {
            dialog.cancel();
            if (isFinish)
                ((Activity) context).finish();
        });

        if (showNegativeBtn)
            builder.setNegativeButton("No", (dialog, id) -> {
                dialog.cancel();
            });
        return builder.create();
    }

    public static AlertDialog openAlertDialog(final Context context, String title, String message, String positiveBtnText,
                                              boolean showNegativeBtn,boolean isFinish) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setMessage(message);
        builder.setTitle(title);

        builder.setPositiveButton(positiveBtnText, (dialog, id) -> {
            dialog.cancel();
            if (isFinish)
                ((Activity) context).finish();
        });

        if (showNegativeBtn)
            builder.setNegativeButton("No", (dialog, id) -> {
                dialog.cancel();
            });
        return builder.create();
    }

}
