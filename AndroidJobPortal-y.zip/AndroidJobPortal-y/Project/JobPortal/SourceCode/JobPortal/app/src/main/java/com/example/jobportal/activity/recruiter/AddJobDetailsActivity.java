package com.example.jobportal.activity.recruiter;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.app.Dialog;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.util.Pair;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.jobportal.R;
import com.example.jobportal.model.Company;
import com.example.jobportal.model.JobDetails;
import com.example.jobportal.model.Jobs;
import com.example.jobportal.utility.Constants;
import com.example.jobportal.utility.DialogUtils;
import com.example.jobportal.utility.Helper;
import com.example.jobportal.utility.webServices.JSONParse;
import com.example.jobportal.utility.webServices.RestAPI;
import com.example.jobportal.utility.webServices.Utility;

import org.json.JSONObject;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Objects;

public class AddJobDetailsActivity extends AppCompatActivity implements View.OnClickListener {

    private RelativeLayout rlAddJobDetailsActivity;
    private EditText etSSCPercentage, etHscPercentage, etGraduationPercentage,
            etPostGraduationPercentage, etSpecialization, etSkills;

    private Button btnAddDetails;
    private TextView tvTitle;

    private RestAPI restAPI;
    private JSONParse jsonParse;
    private Context context;
    private JobDetails entity;
    private String jobId;
    private ArrayList<String> skillList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_job_details);

        initToolbar();
        initUI();
        initObj();
    }

    private void initToolbar() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        tvTitle = toolbar.findViewById(R.id.tvTitle);
        tvTitle.setText(Constants.ADD_DETAILS);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null)
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

    private void initUI() {

        rlAddJobDetailsActivity = findViewById(R.id.rlAddJobDetailsActivity);
        etSSCPercentage = findViewById(R.id.etSSCPercentage);
        etHscPercentage = findViewById(R.id.etHscPercentage);
        etGraduationPercentage = findViewById(R.id.etGraduationPercentage);
        etPostGraduationPercentage = findViewById(R.id.etPostGraduationPercentage);
        etSpecialization = findViewById(R.id.etSpecialization);
        etSkills = findViewById(R.id.etSkills);
        btnAddDetails = findViewById(R.id.btnAddDetails);

        Helper.bulletPointsEditTextListener(etSkills);
        btnAddDetails.setOnClickListener(this);
    }

    private void initObj() {
        context = this;
        entity = new JobDetails();
        restAPI = new RestAPI();
        jsonParse = new JSONParse();

        skillList = new ArrayList<>();
        jobId = getIntent().getExtras().getString(Constants.JOBS);
    }

    @Override
    public void onClick(View view) {
        if (view.getId() == R.id.btnAddDetails) {
            onClickBtnAddDetails();
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void onClickBtnAddDetails() {
        if (isValidate()) {
            setDataToEntity();
            new AsyncAddJobDetails().execute(entity.getJobId(), entity.getSscPercentage(),
                    entity.getHscPercentage(), entity.getGraduationPercentage(),
                    entity.getPostGraduationPercentage(), entity.getSpecialization());
        }

    }

    private boolean isValidate() {
        String required = "required";
        String error = "";

        if (!Helper.checkPercentageValidation(etSSCPercentage, rlAddJobDetailsActivity)) {
            etSSCPercentage.setError(required);
            etSSCPercentage.requestFocus();
            error = required;
        } else if (!Helper.checkPercentageValidation(etHscPercentage, rlAddJobDetailsActivity)) {
            etHscPercentage.setError(required);
            etHscPercentage.requestFocus();
            error = required;
        } else if (!Helper.checkPercentageValidation(etGraduationPercentage, rlAddJobDetailsActivity)) {
            etGraduationPercentage.setError(required);
            etGraduationPercentage.requestFocus();
            error = required;
        } else if (!Helper.checkPercentageValidation(etPostGraduationPercentage, rlAddJobDetailsActivity)) {
            etPostGraduationPercentage.setError(required);
            etPostGraduationPercentage.requestFocus();
            error = required;
        }
        return error.equals("");
    }

    private void setDataToEntity() {
        entity.setJobId(jobId);
        entity.setSscPercentage(etSSCPercentage.getText().toString().trim());
        entity.setHscPercentage(etHscPercentage.getText().toString().trim());
        entity.setGraduationPercentage(etGraduationPercentage.getText().toString().trim());
        entity.setPostGraduationPercentage(etPostGraduationPercentage.getText().toString().trim());
        entity.setSpecialization(etSpecialization.getText().toString().trim());
    }

    private class AsyncAddJobDetails extends AsyncTask<String, String, String> {

        private Dialog dialog;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            dialog = DialogUtils.showLoadingDialog(context, Constants.SAVING);

        }

        @Override
        protected String doInBackground(String... strings) {
            String a;
            try {
                JSONObject json = restAPI.UpdateJobDetails(strings[0],
                        strings[1], strings[2], strings[3], strings[4], strings[5]);
                a = jsonParse.parse(json);
            } catch (Exception e) {
                a = e.getMessage();
            }
            return a;
        }

        @RequiresApi(api = Build.VERSION_CODES.N)
        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            DialogUtils.dismissLoadingDialog(dialog);
            if (Utility.checkConnection(s)) {
                Pair<String, String> pair = Utility.GetErrorMessage(s);
                Utility.ShowAlertDialog(context, pair.first, pair.second, false);
            } else {
                try {
                    JSONObject jsonObject = new JSONObject(s);
                    String statusValue = jsonObject.getString("status");
                    if (statusValue.compareTo("true") == 0) {
                        if (!etSkills.getText().toString().trim().isEmpty()) {
                            String[] split = etSkills.getText().toString().
                                    replaceAll("\\n", "").split("➼");
                            skillList = new ArrayList<>(Arrays.asList(split));
                            skillList.replaceAll(t -> Objects.isNull(t) ? "null" : t);
                            new AsyncAddSkills().execute(jobId);
                        }
                        DialogUtils.openAlertDialog(context,
                                "Details Added",
                                "OK",
                                false,
                                true);
                    } else {
                        Helper.makeSnackBar(rlAddJobDetailsActivity, Constants.SOMETHING_WENT_WRONG);
                    }
                } catch (Exception e) {
                    Helper.makeSnackBar(rlAddJobDetailsActivity, Constants.SOMETHING_WENT_WRONG);
                    e.printStackTrace();
                }
            }
        }
    }

    private class AsyncAddSkills extends AsyncTask<String, String, String> {

        private Dialog dialog;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            dialog = DialogUtils.showLoadingDialog(context, Constants.SAVING);

        }

        @Override
        protected String doInBackground(String... strings) {
            String a;
            try {
                JSONObject json = restAPI.AddJobSkillsRequirement(strings[0], skillList);
                a = jsonParse.parse(json);
            } catch (Exception e) {
                a = e.getMessage();
            }
            return a;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            DialogUtils.dismissLoadingDialog(dialog);
            if (Utility.checkConnection(s)) {
                Pair<String, String> pair = Utility.GetErrorMessage(s);
                Utility.ShowAlertDialog(context, pair.first, pair.second, false);
            } else {
                try {
                    JSONObject jsonObject = new JSONObject(s);
                    String statusValue = jsonObject.getString("status");
                    if (statusValue.compareTo("true") == 0) {
                        finish();
                    } else {
                        Toast.makeText(context, Constants.SOMETHING_WENT_WRONG
                                + "\nMinimum Skills cannot be added", Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception e) {
                    Helper.makeSnackBar(rlAddJobDetailsActivity, Constants.SOMETHING_WENT_WRONG);
                    e.printStackTrace();
                }
            }
        }
    }
}