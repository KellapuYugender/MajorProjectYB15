package com.example.jobportal.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.jobportal.R;
import com.example.jobportal.model.Chats;
import com.example.jobportal.utility.Constants;
import com.example.jobportal.utility.UserPref;

import java.util.List;

public class UserChatsAdapter extends RecyclerView.Adapter<UserChatsAdapter.ViewHolder> {

    private Context context;
    private List<Chats> chatsList;
    String chat = "";

    public UserChatsAdapter(Context context, List<Chats> chatsList) {
        this.context = context;
        this.chatsList = chatsList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        context = parent.getContext();
        LayoutInflater inflater = LayoutInflater.from(context);
        View detailItem = inflater.inflate(R.layout.list_chats, parent, false);
        return new ViewHolder(detailItem);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        if (chatsList.size() != 0) {
            if (UserPref.getUserType(context).equalsIgnoreCase(Constants.TYPE_USER)) {
                if (chatsList.get(position).getSentBy().equals(Constants.TYPE_RECRUITER)) {
                    holder.tvReceiverMessage.setText(chatsList.get(position).getMessage());
                    holder.tvReceiverMessageTime.setText(chatsList.get(position).getDateTime());
                    holder.llReceiverLayout.setVisibility(View.VISIBLE);
                    holder.llSenderLayout.setVisibility(View.GONE);
                } else {
                    holder.tvSenderMessage.setText(chatsList.get(position).getMessage());
                    holder.tvSenderMessageTime.setText(chatsList.get(position).getDateTime());
                    holder.llReceiverLayout.setVisibility(View.GONE);
                    holder.llSenderLayout.setVisibility(View.VISIBLE);
                }
            } else {
                if (chatsList.get(position).getSentBy().equals(Constants.TYPE_RECRUITER)) {
                    holder.tvSenderMessage.setText(chatsList.get(position).getMessage());
                    holder.tvSenderMessageTime.setText(chatsList.get(position).getDateTime());
                    holder.llSenderLayout.setVisibility(View.VISIBLE);
                    holder.llReceiverLayout.setVisibility(View.GONE);
                } else {
                    holder.tvReceiverMessage.setText(chatsList.get(position).getMessage());
                    holder.tvReceiverMessageTime.setText(chatsList.get(position).getDateTime());
                    holder.llSenderLayout.setVisibility(View.GONE);
                    holder.llReceiverLayout.setVisibility(View.VISIBLE);
                }
            }
        }
    }

    @Override
    public int getItemCount() {
        return chatsList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        LinearLayout llReceiverLayout, llSenderLayout;
        TextView tvSenderMessage, tvSenderMessageTime,
                tvReceiverMessage, tvReceiverMessageTime;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            llReceiverLayout = itemView.findViewById(R.id.llReceiverLayout);
            llSenderLayout = itemView.findViewById(R.id.llSenderLayout);
            tvSenderMessage = itemView.findViewById(R.id.tvSenderMessage);
            tvSenderMessageTime = itemView.findViewById(R.id.tvSenderMessageTime);
            tvReceiverMessage = itemView.findViewById(R.id.tvReceiverMessage);
            tvReceiverMessageTime = itemView.findViewById(R.id.tvReceiverMessageTime);
        }
    }
}
