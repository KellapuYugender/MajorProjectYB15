package com.example.jobportal.activity.recruiter;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.example.jobportal.R;
import com.example.jobportal.activity.LoginActivity;
import com.example.jobportal.activity.MainActivity;
import com.example.jobportal.activity.ProfileActivity;
import com.example.jobportal.activity.user.DashboardActivity;
import com.example.jobportal.utility.BackgroundNotificationService;
import com.example.jobportal.utility.Helper;
import com.example.jobportal.utility.MyNotificationService;
import com.example.jobportal.utility.UserPref;

public class RecruiterDashboardActivity extends AppCompatActivity implements View.OnClickListener {

    private AlertDialog alertDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recruiter_dashboard);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(Color.WHITE);
        }
        if (!Helper.isMyServiceRunning(this)) {
            Intent serviceIntent = new Intent(this, MyNotificationService.class);
            ContextCompat.startForegroundService(this, serviceIntent);
        }
        initUI();

    }

    private void initUI() {
        LinearLayout llJobsLayout = findViewById(R.id.llJobsLayout);
        LinearLayout llCandidateListLayout = findViewById(R.id.llCandidateListLayout);
        LinearLayout llProfileLayout = findViewById(R.id.llProfileLayout);
        LinearLayout llLogoutLayout = findViewById(R.id.llLogoutLayout);

        llJobsLayout.setOnClickListener(this);
        llCandidateListLayout.setOnClickListener(this);
        llProfileLayout.setOnClickListener(this);
        llLogoutLayout.setOnClickListener(this);

    }

    @SuppressLint("NonConstantResourceId")
    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.llJobsLayout:
                Helper.goTo(this, ManageCompanyActivity.class);
                break;
            case R.id.llCandidateListLayout:
                Helper.goTo(this, ManageCandidatesActivity.class);
                break;
            case R.id.llProfileLayout:
                Helper.goTo(this, ProfileActivity.class);
                break;
            case R.id.llLogoutLayout:
                logout();
                break;
            case R.id.alertBtnLogout:
                alertButtonLogoutClick();
                break;
            case R.id.alertBtnBack:
                alertDialog.dismiss();
        }
    }

    private void logout() {

        View alertView = getLayoutInflater().inflate(R.layout.alert_logout_confirmation, null);

        Button alertBtnBack = alertView.findViewById(R.id.alertBtnBack);
        Button alertBtnLogout = alertView.findViewById(R.id.alertBtnLogout);

        alertBtnBack.setOnClickListener(this);
        alertBtnLogout.setOnClickListener(this);

        AlertDialog.Builder alert = new AlertDialog.Builder(this);
        if (alertView.getParent() != null) {
            ((ViewGroup) alertView.getParent()).removeView(alertView);
        }
        alert.setView(alertView);
        alertDialog = alert.show();


    }

    private void alertButtonLogoutClick() {
        UserPref.setLoginStatus(this, false);
        UserPref.deleteAll(this);
        if (Helper.isMyServiceRunning(this)) {
            Intent serviceNotification = new Intent(this, MyNotificationService.class);
            stopService(serviceNotification);
        }
        int flags = Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK;
        Helper.goToWithFlags(this, MainActivity.class, flags);
        finish();
    }
}