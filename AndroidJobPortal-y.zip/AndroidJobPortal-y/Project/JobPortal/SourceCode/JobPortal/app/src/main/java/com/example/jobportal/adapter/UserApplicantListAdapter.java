package com.example.jobportal.adapter;

import android.app.Dialog;
import android.content.Context;
import android.os.AsyncTask;
import android.util.Pair;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import com.example.jobportal.R;
import com.example.jobportal.activity.ProfileActivity;
import com.example.jobportal.activity.ChatsActivity;
import com.example.jobportal.model.UserApplicant;
import com.example.jobportal.utility.Constants;
import com.example.jobportal.utility.DialogUtils;
import com.example.jobportal.utility.Helper;
import com.example.jobportal.utility.webServices.JSONParse;
import com.example.jobportal.utility.webServices.RestAPI;
import com.example.jobportal.utility.webServices.Utility;

import org.json.JSONObject;

import java.io.Serializable;
import java.util.List;

public class UserApplicantListAdapter extends RecyclerView.Adapter<UserApplicantListAdapter.ViewHolder> {
    private Context context;
    private RelativeLayout rlManageCandidateLayout;
    private final List<UserApplicant> userApplicantList;
    private UserApplicant userApplicant;

    private RestAPI restAPI;
    private JSONParse jsonParse;

    private String status;

    public UserApplicantListAdapter(Context context, RelativeLayout rlManageCandidateLayout,
                                    List<UserApplicant> userApplicantList) {
        this.context = context;
        this.rlManageCandidateLayout = rlManageCandidateLayout;
        this.userApplicantList = userApplicantList;
        restAPI = new RestAPI();
        jsonParse = new JSONParse();
    }

    @NonNull
    @Override
    public UserApplicantListAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        context = parent.getContext();
        LayoutInflater inflater = LayoutInflater.from(context);
        View detailItem = inflater.inflate(R.layout.list_user_applicant, parent, false);
        return new UserApplicantListAdapter.ViewHolder(detailItem);
    }

    @Override
    public void onBindViewHolder(@NonNull UserApplicantListAdapter.ViewHolder holder, int position) {
        if (userApplicantList.size() != 0) {
            userApplicant = userApplicantList.get(position);
            holder.tvUserName.setText(userApplicant.getUserName());
            holder.tvDateOfApplications.setText(userApplicant.getDateOfApplication());
            holder.tvStatus.setText(userApplicant.getStatus());

            if (!userApplicant.getStatus().equalsIgnoreCase("Pending")) {
                holder.tvAcceptReject.setVisibility(View.GONE);
            }
            holder.tvAcceptReject.setOnClickListener(view -> {
                onClickBtnAcceptReject(userApplicant, holder);
            });
            holder.tvChat.setOnClickListener(view -> {
                Helper.goTo(context, ChatsActivity.class, Constants.CHATS,
                        (Serializable) userApplicant.getUserId());
            });
            holder.rlListApplicantLayout.setOnClickListener(view -> {
                Helper.goTo(context, ProfileActivity.class, Constants.CANDIDATES,
                        userApplicant.getUserId());
            });
        }
    }

    private void onClickBtnAcceptReject(UserApplicant userApplicant, ViewHolder holder) {
        final String[] items = {"ACCEPT", "REJECT"};
        Dialog alertDialog = new Dialog(context);
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(context);
        Dialog finalAlertDialog = alertDialog;
        alertDialogBuilder.setItems(items, (dialog, which) -> {
            String selectedStatus = items[which];
            if (selectedStatus.compareToIgnoreCase("ACCEPT") == 0) {
                finalAlertDialog.dismiss();
                status = Constants.ACCEPTED;
                new AsyncUpdateStatus(holder).execute(userApplicant.getApplicantId(), status,
                        userApplicant.getUserId());

            }
            if (selectedStatus.compareToIgnoreCase("REJECT") ==0) {
                finalAlertDialog.dismiss();
                status = Constants.REJECTED;
                new AsyncUpdateStatus(holder).execute(userApplicant.getApplicantId(), status,
                        userApplicant.getUserId());
            }
        });
        alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }

    @Override
    public int getItemCount() {
        return userApplicantList.size();
    }


    public static class ViewHolder extends RecyclerView.ViewHolder {

        private final RelativeLayout rlListApplicantLayout;
        private final TextView tvUserName;
        private final TextView tvDateOfApplications;
        private final TextView tvAcceptReject;
        private final TextView tvStatus;
        private final TextView tvChat;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            rlListApplicantLayout = itemView.findViewById(R.id.rlListApplicantLayout);
            tvUserName = itemView.findViewById(R.id.tvUserName);
            tvDateOfApplications = itemView.findViewById(R.id.tvDateOfApplications);
            tvAcceptReject = itemView.findViewById(R.id.tvAcceptReject);
            tvStatus = itemView.findViewById(R.id.tvStatus);
            tvChat = itemView.findViewById(R.id.tvChat);
        }
    }

    private class AsyncUpdateStatus extends AsyncTask<String, String, String> {

        private Dialog dialog;
        private ViewHolder holder;
        private String user = "";

        public AsyncUpdateStatus(ViewHolder holder) {
            this.holder = holder;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            dialog = DialogUtils.showLoadingDialog(context, "Please Wait");

        }

        @Override
        protected String doInBackground(String... strings) {
            String a;
            try {
                JSONObject json = restAPI.ChangeUserApplicantStatus(strings[0], strings[1]);
                user = strings[2];
                a = jsonParse.parse(json);
            } catch (Exception e) {
                a = e.getMessage();
            }
            return a;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            DialogUtils.dismissLoadingDialog(dialog);
            if (Utility.checkConnection(s)) {
                Pair<String, String> pair = Utility.GetErrorMessage(s);
                Utility.ShowAlertDialog(context, pair.first, pair.second, false);
            } else {
                try {
                    JSONObject jsonObject = new JSONObject(s);
                    String statusValue = jsonObject.getString("status");

                    if (statusValue.compareTo("true") == 0) {
                        DialogUtils.openAlertDialog(context,
                                "Status Updated",
                                "OK",
                                false, false).show();
                        String title = "Job Status";
                        String message = "Application " + status;
                        String type = Constants.USER;
                        String userId = user;
                        new AsyncAddNotification().execute(title, message, type,
                                userId);
                        holder.tvStatus.setText(status);
                        if (!status.equalsIgnoreCase("Pending")) {
                            holder.tvAcceptReject.setVisibility(View.GONE);
                        }

                    } else {
                        Helper.makeSnackBar(rlManageCandidateLayout, Constants.SOMETHING_WENT_WRONG);
                    }
                } catch (Exception e) {
                    Helper.makeSnackBar(rlManageCandidateLayout, Constants.SOMETHING_WENT_WRONG);
                    e.printStackTrace();
                }
            }
        }
    }

    private class AsyncAddNotification extends AsyncTask<String, JSONObject, String> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(String... strings) {
            String ans;
            RestAPI restAPI = new RestAPI();
            try {
                JSONObject json = restAPI.AddNotification(strings[0], strings[1], strings[2]
                        , strings[3]);
                ans = jsonParse.parse(json);
            } catch (Exception e) {
                ans = e.getMessage();
            }
            return ans;
        }


        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            try {
                if (Utility.checkConnection(s)) {
                    Pair<String, String> pair = Utility.GetErrorMessage(s);
                    Utility.ShowAlertDialog(context, pair.first, pair.second, false);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }


}
