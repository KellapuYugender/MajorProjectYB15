package com.example.jobportal.activity.recruiter;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.util.Pair;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.jobportal.R;
import com.example.jobportal.model.Company;
import com.example.jobportal.model.JobDetails;
import com.example.jobportal.model.Jobs;
import com.example.jobportal.model.JobsPosition;
import com.example.jobportal.model.Registration;
import com.example.jobportal.utility.Constants;
import com.example.jobportal.utility.DateUtils;
import com.example.jobportal.utility.DialogUtils;
import com.example.jobportal.utility.Helper;
import com.example.jobportal.utility.UserPref;
import com.example.jobportal.utility.webServices.JSONParse;
import com.example.jobportal.utility.webServices.RestAPI;
import com.example.jobportal.utility.webServices.Utility;
import com.google.android.material.snackbar.Snackbar;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Objects;

public class AddJobsActivity extends AppCompatActivity implements View.OnClickListener {

    private RelativeLayout rlAddJobsActivity;
    private LinearLayout llDetailsLayout;
    private TextView tvTitle;
    private EditText etJobName, etJobStartDate, etJobSummary,
            etJobDescription, etJobNoOfVacancy,
            etJobCategory, etJobPlatform, etMinExperience, etMaximumExperience;
    private AutoCompleteTextView acJobCompany, acJobPosition;
    private EditText etSSCPercentage, etHscPercentage, etGraduationPercentage,
            etPostGraduationPercentage, etSpecialization, etSkills;
    private Button btnPostJob, btnDelete;
    ;

    private RestAPI restAPI;
    private JSONParse jsonParse;
    private Context context;
    private Jobs entity;
    private JobDetails jobDetails;
    private Company company;
    private JobsPosition jobsPosition;

    private String jobId = "";
    private Serializable serializableBundle;
    private ArrayList<String> skillList;

    private List<Company> companyList;
    private List<JobsPosition> jobsPositionList;

    private String companyId = "";
    private String jobPositionsId = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_jobs);

        initToolbar();
        initUI();
        initObj();
        loadIntentData();
    }

    private void initToolbar() {

        Toolbar toolbar = findViewById(R.id.toolbar);
        tvTitle = toolbar.findViewById(R.id.tvTitle);
        tvTitle.setText(Constants.POST_JOB);
        btnDelete = toolbar.findViewById(R.id.btnDelete);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null)
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

    private void initUI() {
        rlAddJobsActivity = findViewById(R.id.rlAddJobsActivity);
        llDetailsLayout = findViewById(R.id.llDetailsLayout);
        acJobCompany = findViewById(R.id.acJobCompany);
        etJobName = findViewById(R.id.etJobName);
        etJobStartDate = findViewById(R.id.etJobStartDate);
        etJobDescription = findViewById(R.id.etJobDescription);
        etJobSummary = findViewById(R.id.etJobSummary);
        acJobPosition = findViewById(R.id.acJobPosition);
        etJobNoOfVacancy = findViewById(R.id.etJobNoOfVacancy);
        etJobCategory = findViewById(R.id.etJobCategory);
        etJobPlatform = findViewById(R.id.etJobPlatform);
        etMinExperience = findViewById(R.id.etMinExperience);
        etMaximumExperience = findViewById(R.id.etMaximumExperience);

        etSSCPercentage = findViewById(R.id.etSSCPercentage);
        etHscPercentage = findViewById(R.id.etHscPercentage);
        etGraduationPercentage = findViewById(R.id.etGraduationPercentage);
        etPostGraduationPercentage = findViewById(R.id.etPostGraduationPercentage);
        etSpecialization = findViewById(R.id.etSpecialization);
        etSkills = findViewById(R.id.etSkills);

        btnPostJob = findViewById(R.id.btnPostJob);

        Helper.bulletPointsEditTextListener(etSkills);
        etJobStartDate.setOnClickListener(this);
        btnPostJob.setOnClickListener(this);
    }

    private void initObj() {
        context = this;
        entity = new Jobs();
        jobDetails = new JobDetails();
        company = new Company();
        jobsPosition = new JobsPosition();
        restAPI = new RestAPI();
        jsonParse = new JSONParse();
        companyList = new ArrayList<>();
        jobsPositionList = new ArrayList<>();
        skillList = new ArrayList<>();
        serializableBundle = loadIntentData();

    }

    @Override
    protected void onResume() {
        super.onResume();
        if (!jobId.trim().isEmpty()) {
            llDetailsLayout.setVisibility(View.VISIBLE);
            btnDelete.setVisibility(View.VISIBLE);
        } else {
            llDetailsLayout.setVisibility(View.GONE);
            btnDelete.setVisibility(View.GONE);
        }
        new AsyncGetCompany().execute();
        new AsyncGetJobPositions().execute();
    }

    private Serializable loadIntentData() {
        Serializable bundle = getIntent().getSerializableExtra(Constants.JOBS);
        if (bundle != null) {
            entity = (Jobs) bundle;
            setEntityDataToText();
        }
        return bundle;
    }

    @Override
    public void onClick(View view) {
        if (view.getId() == R.id.btnPostJob) {
            onClickBtnPostJob();
        } else if (view.getId() == R.id.etJobStartDate) {
            DateUtils.openDatePickerDialog(this, etJobStartDate);
        } else if (view.getId() == R.id.btnDelete) {
            onClickBtnDelete();
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void setCompanyAutoCompleteCompany() {

        List<String> companyNames = new ArrayList<>();
        for (Company company : companyList) {
            companyNames.add(company.getCompanyName());
        }
        ArrayAdapter<String> adapter = new ArrayAdapter<>
                (this, android.R.layout.select_dialog_item, companyNames);
        acJobCompany.setThreshold(1);
        acJobCompany.setAdapter(adapter);
        acJobCompany.setTextColor(Color.RED);

    }

    private void setAutoCompleteJobPosition() {
        List<String> jobPositions = new ArrayList<>();
        for (JobsPosition jobsPosition : jobsPositionList) {
            jobPositions.add(jobsPosition.getPositionName());
        }
        ArrayAdapter<String> adapter = new ArrayAdapter<>
                (this, android.R.layout.select_dialog_item, jobPositions);
        acJobPosition.setThreshold(1);
        acJobPosition.setAdapter(adapter);
        acJobPosition.setTextColor(Color.RED);
    }

    private void onClickBtnPostJob() {
        if (isValidate()) {
            if (isCompanyAdded()) {
                if (isJobPosition()) {
                    try {
                        setDataToEntity();
                        if (serializableBundle == null) {
                            postJob();
                        } else {
                            updateJob();
                        }
                    } catch (Exception exception) {
                        exception.printStackTrace();
                    }
                }
            }
        }
    }

    private void onClickBtnDelete() {
        if (jobId != null) {
            if (!jobId.trim().isEmpty()) {
                new AlertDialog.Builder(context)
                        .setTitle("Alert!!!")
                        .setMessage("Do you really want to delete job?")
                        .setIcon(android.R.drawable.ic_dialog_alert)
                        .setPositiveButton(android.R.string.yes, (dialog1, whichButton) ->
                                new AsyncDeleteJob().execute(jobId))
                        .setNegativeButton(android.R.string.no, (dialog12, which1) ->
                                dialog12.dismiss()).show();
            }
        }
    }

    private void updateJob() {
        jobId = String.valueOf(entity.getJobId());
        if (jobId != null) {
            setDataToHobDetailsEntity();

            if (!etSkills.getText().toString().trim().isEmpty()) {
                String[] split = etSkills.getText().toString().
                        replaceAll("\\n", "").split("➼");
                skillList = new ArrayList<>(Arrays.asList(split));
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    skillList.replaceAll(t -> Objects.isNull(t) ? "" : t);
                }
            }

            new AsyncUpdateJob().execute(
                    entity.getJobId(), entity.getJobName(), entity.getDescription(), entity.getDatePublished(),
                    entity.getJobStartDate(), entity.getNoOfVacancy(), entity.getSummary(), jobPositionsId,
                    entity.getJobCategory(), entity.getJobPlatform(), companyId,
                    entity.getMinExperience(), entity.getMaxExperience(),
                    UserPref.getUser(this));
        }
    }

    private void postJob() {
        new AsyncPostJob().execute(
                entity.getJobName(), entity.getDescription(), entity.getDatePublished(),
                entity.getJobStartDate(), entity.getNoOfVacancy(), entity.getSummary(),
                jobPositionsId, entity.getJobCategory(), entity.getJobPlatform(),
                companyId, entity.getMinExperience(), entity.getMaxExperience(),
                UserPref.getUser(this));
    }

    private void setEntityDataToText() {
        try {
            jobId = String.valueOf(entity.getJobId());
            etJobName.setText(entity.getJobName());
            etJobDescription.setText(entity.getDescription());
            etJobStartDate.setText(entity.getJobStartDate());
            etJobNoOfVacancy.setText(entity.getNoOfVacancy());
            etJobSummary.setText(entity.getSummary());
            acJobPosition.setText(String.valueOf(entity.getJobPositionId()));
            etJobCategory.setText(entity.getJobCategory());
            etJobPlatform.setText(entity.getJobPlatform());
            etMinExperience.setText(entity.getMinExperience());
            etMaximumExperience.setText(entity.getMaxExperience());
            companyId = entity.getCompanyId();
            jobPositionsId = entity.getJobPositionId();
            new AsyncGetJobDetails().execute();
            new AsyncGetSkills().execute();
        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    private void setDataToHobDetailsEntity() {
        jobDetails.setJobId(jobId);
        jobDetails.setSscPercentage(etSSCPercentage.getText().toString().trim());
        jobDetails.setHscPercentage(etHscPercentage.getText().toString().trim());
        jobDetails.setGraduationPercentage(etGraduationPercentage.getText().toString().trim());
        jobDetails.setPostGraduationPercentage(etPostGraduationPercentage.getText().toString().trim());
        jobDetails.setSpecialization(etSpecialization.getText().toString().trim());
    }

    private void setDataToEntity() {
        String[] currentDateTime = DateUtils.currentDateTime();
        entity.setJobName(etJobName.getText().toString().trim());
        entity.setDescription(etJobDescription.getText().toString().trim());
        entity.setDatePublished(currentDateTime[3]);
        entity.setJobStartDate(etJobStartDate.getText().toString().trim());
        entity.setNoOfVacancy(etJobNoOfVacancy.getText().toString().trim());
        entity.setSummary(etJobSummary.getText().toString().trim());
        entity.setJobCategory(etJobCategory.getText().toString().trim());
        entity.setJobPlatform(etJobPlatform.getText().toString().trim());
        entity.setMinExperience(etMinExperience.getText().toString().trim());
        entity.setMaxExperience(etMaximumExperience.getText().toString().trim());
    }

    private boolean isValidate() {
        String required = "required";
        String error = "";

        if (acJobCompany.getText().toString().trim().equals("")) {
            acJobCompany.setError(required);
            acJobCompany.requestFocus();
            error = required;
        } else if (etJobName.getText().toString().trim().equals("")) {
            etJobName.setError(required);
            etJobName.requestFocus();
            error = required;
        } else if (etJobDescription.getText().toString().trim().equals("")) {
            etJobDescription.setError(required);
            etJobDescription.requestFocus();
            error = required;
        } else if (etJobNoOfVacancy.getText().toString().trim().equals("")) {
            etJobNoOfVacancy.setError(required);
            etJobNoOfVacancy.requestFocus();
            error = required;
        } else if (etJobCategory.getText().toString().trim().equals("")) {
            etJobCategory.setError(required);
            etJobCategory.requestFocus();
            error = required;
        } else if (etJobPlatform.getText().toString().trim().equals("")) {
            etJobPlatform.setError(required);
            etJobPlatform.requestFocus();
            error = required;
        } else if (etMinExperience.getText().toString().trim().equals("")) {
            etMinExperience.setError(required);
            etMinExperience.requestFocus();
            error = required;
        } else if (etMaximumExperience.getText().toString().trim().equals("")) {
            etMaximumExperience.setError(required);
            etMaximumExperience.requestFocus();
            error = required;
        }
        return error.equals("");
    }

    private boolean isCompanyAdded() {
        for (int i = 0; i < companyList.size(); i++) {
            if (companyList.get(i).getCompanyName().equals(acJobCompany.getText().toString())) {
                companyId = String.valueOf(companyList.get(i).getCompanyId());
                return true;
            }
        }
        acJobCompany.setText("");
        Helper.makeSnackBarWithAction(rlAddJobsActivity,
                "Company Not Found Proceed To add Company",
                "Proceed", view -> Helper.goTo(context, AddCompanyActivity.class));
        return false;
    }

    private boolean isJobPosition() {
        for (int i = 0; i < jobsPositionList.size(); i++) {
            if (jobsPositionList.get(i).getPositionName().equals(
                    acJobPosition.getText().toString())) {
                jobPositionsId = String.valueOf(jobsPositionList.get(i).getJobPositionId());
                return true;
            }
        }
        acJobPosition.setText("");
        Helper.makeSnackBarWithAction(rlAddJobsActivity,
                "Job Position Not Found Proceed To add",
                "Proceed", view -> Helper.goTo(context, AddJobPositionActivity.class));
        return false;
    }

    private void onSuccessJobPost(@NonNull JSONObject jsonObject) throws JSONException {
        String jobId = "";
        JSONArray jsonArray = jsonObject.getJSONArray("Data");
        for (int i = 0; i < jsonArray.length(); i++) {
            JSONObject jsonObj = jsonArray.getJSONObject(i);
            jobId = jsonObj.getString("data0");
        }
        DialogUtils.openAlertDialog(context,
                "Job Posted\nProceed to add details",
                "OK",
                false,
                false).show();

        Helper.goTo(context, AddJobDetailsActivity.class,
                Constants.JOBS, jobId);
        finish();
    }

    private void setDataToEntityAndSetupAutoComplete(JSONObject json) {
        try {
            JSONArray jsonArray = json.getJSONArray("Data");
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObj = jsonArray.getJSONObject(i);
                company.setCompanyId(jsonObj.getString("data0"));
                company.setCompanyName(jsonObj.getString("data1"));
                company.setCompanyDescription(jsonObj.getString("data2"));
                companyList.add(company);
                company = new Company();
            }
            if (!companyId.trim().isEmpty()) {
                for (int i = 0; i < companyList.size(); i++) {
                    if (companyList.get(i).getCompanyId().equals(entity.getCompanyId())) {
                        acJobCompany.setText(companyList.get(i).getCompanyName());
                    }
                }
            }
            setCompanyAutoCompleteCompany();
        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    private void setDataToEntityAndSetupAutoCompleteJobPositions(JSONObject json) {
        try {
            JSONArray jsonArray = json.getJSONArray("Data");
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObj = jsonArray.getJSONObject(i);
                jobsPosition.setJobPositionId(jsonObj.getString("data0"));
                jobsPosition.setPositionName(jsonObj.getString("data1"));
                jobsPosition.setDescription(jsonObj.getString("data2"));
                jobsPositionList.add(jobsPosition);
                jobsPosition = new JobsPosition();
            }
            if (!jobPositionsId.trim().isEmpty()) {
                for (int i = 0; i < jobsPositionList.size(); i++) {
                    if (jobsPositionList.get(i).getJobPositionId().equals(entity.getJobPositionId())) {
                        acJobPosition.setText(jobsPositionList.get(i).getPositionName());
                    }
                }
            }
            setAutoCompleteJobPosition();
        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    private void setSkillsDataToText(JSONObject json) {
        try {
            etSkills.setText("➼ ");
            JSONArray jsonArray = json.getJSONArray("Data");
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObj = jsonArray.getJSONObject(i);
                String skillName = jsonObj.getString("data2");
                etSkills.setText(etSkills.getText().toString().trim() + skillName + "\n");
            }

        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    private void setJobDetailsDataToText(JSONObject json) {
        try {
            JSONArray jsonArray = json.getJSONArray("Data");
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObj = jsonArray.getJSONObject(i);
                etSSCPercentage.setText(jsonObj.getString("data2"));
                etHscPercentage.setText(jsonObj.getString("data3"));
                etGraduationPercentage.setText(jsonObj.getString("data4"));
                etPostGraduationPercentage.setText(jsonObj.getString("data5"));
                etSpecialization.setText(jsonObj.getString("data6"));
            }
        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    private class AsyncGetCompany extends AsyncTask<String, String, String> {

        private Dialog dialog;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            if (companyList.size() > 0) {
                companyList.clear();
            }
            dialog = DialogUtils.showLoadingDialog(context, Constants.PLEASE_WAIT);
        }


        @Override
        protected String doInBackground(String... strings) {
            String a;
            try {
                JSONObject json = restAPI.GetAllCompany();
                a = jsonParse.parse(json);
            } catch (Exception e) {
                a = e.getMessage();
            }
            return a;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            dialog.dismiss();
            try {
                if (Utility.checkConnection(s)) {
                    Pair<String, String> pair = Utility.GetErrorMessage(s);
                    Utility.ShowAlertDialog(context, pair.first, pair.second, false);
                } else {
                    //main
                    JSONObject json = new JSONObject(s);

                    //string value
                    String jsonString = json.getString("status");

                    if (jsonString.compareToIgnoreCase("no") == 0) {
                        Helper.makeSnackBar(rlAddJobsActivity, "No company found");
                    } else if (jsonString.compareToIgnoreCase("ok") == 0) {
                        setDataToEntityAndSetupAutoComplete(json);
                    }

                }
            } catch (Exception e) {
                e.printStackTrace();
            }

        }
    }

    private class AsyncGetJobPositions extends AsyncTask<String, String, String> {

        private Dialog dialog;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            if (companyList.size() > 0) {
                companyList.clear();
            }
            dialog = DialogUtils.showLoadingDialog(context, Constants.PLEASE_WAIT);
        }


        @Override
        protected String doInBackground(String... strings) {
            String a;
            try {
                JSONObject json = restAPI.GetAllJobPositions();
                a = jsonParse.parse(json);
            } catch (Exception e) {
                a = e.getMessage();
            }
            return a;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            dialog.dismiss();
            try {
                if (Utility.checkConnection(s)) {
                    Pair<String, String> pair = Utility.GetErrorMessage(s);
                    Utility.ShowAlertDialog(context, pair.first, pair.second, false);
                } else {
                    //main
                    JSONObject json = new JSONObject(s);

                    //string value
                    String jsonString = json.getString("status");

                    if (jsonString.compareToIgnoreCase("no") == 0) {
                        Helper.makeSnackBarWithAction(rlAddJobsActivity,
                                "Job positions need to be added",
                                "Proceed", view -> {
                                    Helper.goTo(context, AddJobPositionActivity.class);
                                });
                    } else if (jsonString.compareToIgnoreCase("ok") == 0) {
                        setDataToEntityAndSetupAutoCompleteJobPositions(json);
                    }

                }
            } catch (Exception e) {
                e.printStackTrace();
            }

        }
    }

    private class AsyncPostJob extends AsyncTask<String, String, String> {

        private Dialog dialog;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            dialog = DialogUtils.showLoadingDialog(context, Constants.SAVING);

        }

        @Override
        protected String doInBackground(String... strings) {
            String a;
            try {
                JSONObject json = restAPI.AddJobs(strings[0],
                        strings[1], strings[2], strings[3], strings[4], strings[5]
                        , strings[6], strings[7]
                        , strings[8], strings[9], strings[10]
                        , strings[11], strings[12]);
                a = jsonParse.parse(json);
            } catch (Exception e) {
                a = e.getMessage();
            }
            return a;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            DialogUtils.dismissLoadingDialog(dialog);
            if (Utility.checkConnection(s)) {
                Pair<String, String> pair = Utility.GetErrorMessage(s);
                Utility.ShowAlertDialog(context, pair.first, pair.second, false);
            } else {
                try {
                    JSONObject jsonObject = new JSONObject(s);
                    String statusValue = jsonObject.getString("status");
                    if (statusValue.compareToIgnoreCase("ok") == 0) {
                        onSuccessJobPost(jsonObject);
                    } else {
                        Helper.makeSnackBar(rlAddJobsActivity, Constants.SOMETHING_WENT_WRONG);
                    }
                } catch (Exception e) {
                    Helper.makeSnackBar(rlAddJobsActivity, Constants.SOMETHING_WENT_WRONG);
                    e.printStackTrace();
                }
            }
        }
    }

    private class AsyncUpdateJob extends AsyncTask<String, String, String> {

        private Dialog dialog;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            dialog = DialogUtils.showLoadingDialog(context, Constants.UPDATING);

        }

        @Override
        protected String doInBackground(String... strings) {
            String a;
            try {
                JSONObject json = restAPI.UpdateJobs(strings[0],
                        strings[1], strings[2], strings[3], strings[4], strings[5]
                        , strings[6], strings[7]
                        , strings[8], strings[9], strings[10]
                        , strings[11], strings[12], strings[13]);
                a = jsonParse.parse(json);
            } catch (Exception e) {
                a = e.getMessage();
            }
            return a;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            DialogUtils.dismissLoadingDialog(dialog);
            if (Utility.checkConnection(s)) {
                Pair<String, String> pair = Utility.GetErrorMessage(s);
                Utility.ShowAlertDialog(context, pair.first, pair.second, false);
            } else {
                try {
                    JSONObject jsonObject = new JSONObject(s);
                    String statusValue = jsonObject.getString("status");
                    if (statusValue.compareTo("true") == 0) {
                        DialogUtils.openAlertDialog(context,
                                "Job Updated",
                                "OK",
                                false,
                                false).show();
                        new AsyncUpdateJobDetails().execute(
                                jobId,
                                jobDetails.getSscPercentage(),
                                jobDetails.getHscPercentage(),
                                jobDetails.getGraduationPercentage(),
                                jobDetails.getPostGraduationPercentage(),
                                jobDetails.getSpecialization()
                        );
                    } else {
                        Helper.makeSnackBar(rlAddJobsActivity, Constants.SOMETHING_WENT_WRONG);
                    }
                } catch (Exception e) {
                    Helper.makeSnackBar(rlAddJobsActivity, Constants.SOMETHING_WENT_WRONG);
                    e.printStackTrace();
                }
            }
        }
    }

    private class AsyncUpdateJobDetails extends AsyncTask<String, String, String> {

        private Dialog dialog;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            dialog = DialogUtils.showLoadingDialog(context, Constants.SAVING);

        }

        @Override
        protected String doInBackground(String... strings) {
            String a;
            try {
                JSONObject json = restAPI.UpdateJobDetails(strings[0],
                        strings[1], strings[2], strings[3], strings[4], strings[5]);
                a = jsonParse.parse(json);
            } catch (Exception e) {
                a = e.getMessage();
            }
            return a;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            DialogUtils.dismissLoadingDialog(dialog);
            if (Utility.checkConnection(s)) {
                Pair<String, String> pair = Utility.GetErrorMessage(s);
                Utility.ShowAlertDialog(context, pair.first, pair.second, false);
            } else {
                try {
                    JSONObject jsonObject = new JSONObject(s);
                    String statusValue = jsonObject.getString("status");
                    if (statusValue.compareTo("true") == 0) {
                        if (skillList.size() > -1) {
                            new AsyncAddSkills().execute(jobId);
                        }
                        DialogUtils.openAlertDialog(context,
                                "Details Updated",
                                "OK",
                                false,
                                true);
                    } else {
                        Helper.makeSnackBar(rlAddJobsActivity, Constants.SOMETHING_WENT_WRONG);
                    }
                } catch (Exception e) {
                    Helper.makeSnackBar(rlAddJobsActivity, Constants.SOMETHING_WENT_WRONG);
                    e.printStackTrace();
                }
            }
        }
    }

    private class AsyncAddSkills extends AsyncTask<String, String, String> {

        private Dialog dialog;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            dialog = DialogUtils.showLoadingDialog(context, Constants.SAVING);

        }

        @Override
        protected String doInBackground(String... strings) {
            String a;
            try {
                JSONObject json = restAPI.AddJobSkillsRequirement(strings[0], skillList);
                a = jsonParse.parse(json);
            } catch (Exception e) {
                a = e.getMessage();
            }
            return a;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            DialogUtils.dismissLoadingDialog(dialog);
            if (Utility.checkConnection(s)) {
                Pair<String, String> pair = Utility.GetErrorMessage(s);
                Utility.ShowAlertDialog(context, pair.first, pair.second, false);
            } else {
                try {
                    JSONObject jsonObject = new JSONObject(s);
                    String statusValue = jsonObject.getString("status");
                    if (statusValue.compareTo("true") != 0) {
                        Toast.makeText(context, Constants.SOMETHING_WENT_WRONG
                                + "\nMinimum Skills cannot be updated", Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception e) {
                    Helper.makeSnackBar(rlAddJobsActivity, Constants.SOMETHING_WENT_WRONG);
                    e.printStackTrace();
                }
            }
        }
    }

    private class AsyncGetJobDetails extends AsyncTask<String, String, String> {

        private Dialog dialog;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            if (companyList.size() > 0) {
                companyList.clear();
            }
            dialog = DialogUtils.showLoadingDialog(context, Constants.PLEASE_WAIT);
        }


        @Override
        protected String doInBackground(String... strings) {
            String a;
            try {
                JSONObject json = restAPI.GetJobDetails(jobId);
                a = jsonParse.parse(json);
            } catch (Exception e) {
                a = e.getMessage();
            }
            return a;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            dialog.dismiss();
            try {
                if (Utility.checkConnection(s)) {
                    Pair<String, String> pair = Utility.GetErrorMessage(s);
                    Utility.ShowAlertDialog(context, pair.first, pair.second, false);
                } else {
                    //main
                    JSONObject json = new JSONObject(s);

                    //string value
                    String jsonString = json.getString("status");

                    if (jsonString.compareToIgnoreCase("no") == 0) {
                    } else if (jsonString.compareToIgnoreCase("ok") == 0) {
                        setJobDetailsDataToText(json);
                    }

                }
            } catch (Exception e) {
                e.printStackTrace();
            }

        }
    }

    private class AsyncGetSkills extends AsyncTask<String, String, String> {

        private Dialog dialog;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            if (companyList.size() > 0) {
                companyList.clear();
            }
            dialog = DialogUtils.showLoadingDialog(context, Constants.PLEASE_WAIT);
        }


        @Override
        protected String doInBackground(String... strings) {
            String a;
            try {
                JSONObject json = restAPI.GetJobSkillsRequirementSkills(jobId);
                a = jsonParse.parse(json);
            } catch (Exception e) {
                a = e.getMessage();
            }
            return a;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            dialog.dismiss();
            try {
                if (Utility.checkConnection(s)) {
                    Pair<String, String> pair = Utility.GetErrorMessage(s);
                    Utility.ShowAlertDialog(context, pair.first, pair.second, false);
                } else {
                    //main
                    JSONObject json = new JSONObject(s);

                    //string value
                    String jsonString = json.getString("status");

                    if (jsonString.compareToIgnoreCase("no") == 0) {
                    } else if (jsonString.compareToIgnoreCase("ok") == 0) {
                        setSkillsDataToText(json);
                    }

                }
            } catch (Exception e) {
                e.printStackTrace();
            }

        }
    }

    private class AsyncDeleteJob extends AsyncTask<String, String, String> {

        private Dialog dialog;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            dialog = DialogUtils.showLoadingDialog(context, "DELETING...");
        }

        @Override
        protected String doInBackground(String... strings) {
            String a;
            try {
                JSONObject json = null;
                json = restAPI.DeleteJob(strings[0]);
                a = jsonParse.parse(json);
            } catch (Exception e) {
                a = e.getMessage();
            }
            return a;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            DialogUtils.dismissLoadingDialog(dialog);
            if (Utility.checkConnection(s)) {
                Pair<String, String> pair = Utility.GetErrorMessage(s);
                Utility.ShowAlertDialog(context, pair.first, pair.second, false);
            } else {
                try {

                    JSONObject jsonObject = new JSONObject(s);
                    String jsonValue = jsonObject.getString("status");
                    if (jsonValue.compareTo("false") == 0) {
                        Helper.makeSnackBar(rlAddJobsActivity, Constants.SOMETHING_WENT_WRONG);
                    }
                    if (jsonValue.compareTo("true") == 0) {
                        DialogUtils.openAlertDialog(context,
                                "Job Deleted Successfully",
                                "OK",
                                false, true);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }

}