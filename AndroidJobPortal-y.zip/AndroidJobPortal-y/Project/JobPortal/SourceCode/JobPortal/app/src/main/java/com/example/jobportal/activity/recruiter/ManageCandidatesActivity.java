package com.example.jobportal.activity.recruiter;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.util.Pair;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.jobportal.R;
import com.example.jobportal.activity.user.SearchJobActivity;
import com.example.jobportal.adapter.CompanyListAdapter;
import com.example.jobportal.adapter.UserApplicantListAdapter;
import com.example.jobportal.model.Company;
import com.example.jobportal.model.UserApplicant;
import com.example.jobportal.model.UserSkills;
import com.example.jobportal.utility.Constants;
import com.example.jobportal.utility.DialogUtils;
import com.example.jobportal.utility.Helper;
import com.example.jobportal.utility.webServices.JSONParse;
import com.example.jobportal.utility.webServices.RestAPI;
import com.example.jobportal.utility.webServices.Utility;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class ManageCandidatesActivity extends AppCompatActivity implements View.OnClickListener {

    private RelativeLayout rlManageCandidateLayout;
    private CardView acSearchCardLayout;
    private TextView tvNoData, tvFilterBy;
    private ImageButton ibFilter;
    private AutoCompleteTextView acSearch;
    private RecyclerView rvCandidate;

    private View alertFilter;
    private AlertDialog alertDialog;
    private AlertDialog.Builder alertBuilder;
    private TextView alertTvAllJobs, alertTvJobName, alertTvSkills, alertTvCompany, alertTvSSCPercent,
            alertTvHSCPercent, alertTvGraduatePercent, alertTvPostGraduatePercent,
            alertTvSpecialization, alertBtnCancel;

    private Context context;
    private RestAPI restAPI;
    private JSONParse jsonParse;
    private UserApplicant entity;
    private UserSkills userSkills;
    private List<UserApplicant> userApplicantList;
    private List<String> userSkillsList;
    private UserApplicantListAdapter userApplicantListAdapter;

    private String jobId;

    private String filterBy = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_candidates);

        initToolbar();
        initUI();
        initObj();

    }

    private void initToolbar() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        TextView tvTitle = toolbar.findViewById(R.id.tvTitle);
        tvTitle.setText(Constants.CANDIDATES);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null)
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);

    }

    private void initUI() {
        rlManageCandidateLayout = findViewById(R.id.rlManageCandidateLayout);
        tvNoData = findViewById(R.id.tvNoData);
        tvFilterBy = findViewById(R.id.tvFilterBy);
        ibFilter = findViewById(R.id.ibFilter);
        acSearchCardLayout = findViewById(R.id.acSearchCardLayout);
        acSearch = findViewById(R.id.acSearch);
        rvCandidate = findViewById(R.id.rvCandidate);

        tvNoData.setVisibility(View.VISIBLE);
        rvCandidate.setVisibility(View.GONE);
        acSearchCardLayout.setVisibility(View.GONE);

        ibFilter.setOnClickListener(this);
    }

    private void initObj() {
        context = this;
        restAPI = new RestAPI();
        jsonParse = new JSONParse();
        entity = new UserApplicant();
        userSkills = new UserSkills();
        userApplicantList = new ArrayList<>();
        userSkillsList = new ArrayList<>();
        jobId = (String) getIntent().getSerializableExtra(Constants.JOBS);
    }

    private void loadItems() {
        if (jobId != null) {
            if (!jobId.trim().isEmpty()) {
                new AsyncGetCandidate().execute(jobId);
            } else {
                new AsyncGetAllCandidate().execute();
            }
        } else {
            new AsyncGetAllCandidate().execute();
        }
        new AsyncGetUserSkills().execute();
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (userApplicantListAdapter != null) {
            userApplicantList.clear();
            entity = new UserApplicant();
            rvCandidate.setAdapter(null);
        }
        loadItems();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.fabAddCompany:
                Helper.goTo(this, AddCompanyActivity.class);
                break;
            case R.id.ibFilter:
                onClickImageBtnSearch();
                break;
            case R.id.tvAllJobs:
                alertDialog.dismiss();
                filterBy = Constants.NAME;
                acSearch.setText(filterBy);
                acSearch.requestFocus();
                tvFilterBy.setText("Filter By : "+filterBy);
                break;
            case R.id.tvCompany:
                alertDialog.dismiss();
                filterBy = Constants.WORK_EXPERIENCE;
                acSearch.setText(filterBy);
                acSearch.requestFocus();
                tvFilterBy.setText("Filter By : "+filterBy);
                break;
            case R.id.tvSkills:
                alertDialog.dismiss();
                filterBy = Constants.SKILLS;
                acSearch.setText(filterBy);
                acSearch.requestFocus();
                tvFilterBy.setText("Filter By : "+filterBy);
                break;
            case R.id.tvSSCPercent:
                alertDialog.dismiss();
                filterBy = Constants.SSC_PERCENT;
                acSearch.setText(filterBy);
                acSearch.requestFocus();
                tvFilterBy.setText("Filter By : "+filterBy);
                break;
            case R.id.tvHSCPercent:
                alertDialog.dismiss();
                filterBy = Constants.HSC_PERCENT;
                acSearch.setText(filterBy);
                acSearch.requestFocus();
                tvFilterBy.setText("Filter By : "+filterBy);
                break;
            case R.id.tvGraduatePercent:
                alertDialog.dismiss();
                filterBy = Constants.GRADUATE_PERCENT;
                acSearch.setText(filterBy);
                acSearch.requestFocus();
                tvFilterBy.setText("Filter By : "+filterBy);
                break;
            case R.id.tvPostGraduatePercent:
                alertDialog.dismiss();
                filterBy = Constants.POST_GRADUATE_PERCENT;
                acSearch.setText(filterBy);
                acSearch.requestFocus();
                tvFilterBy.setText("Filter By : "+filterBy);
                break;
            case R.id.tvSpecialization:
                alertDialog.dismiss();
                filterBy = Constants.SPECIALIZATION;
                acSearch.setText(filterBy);
                acSearch.requestFocus();
                tvFilterBy.setText("Filter By : "+filterBy);
                break;
            case R.id.alertBtnCancel:
                alertDialog.dismiss();
        }
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void setUpAutoComplete() {
        List<String> adminItems = new ArrayList<>();
        for (UserApplicant userApplicant : userApplicantList) {
            adminItems.add(Constants.NAME + userApplicant.getUserName());
            adminItems.add(Constants.SSC_PERCENT + userApplicant.getSscPercentage());
            adminItems.add(Constants.HSC_PERCENT + userApplicant.getHscPercentage());
            adminItems.add(Constants.GRADUATE_PERCENT + userApplicant.getGraduationPercentage());
            adminItems.add(Constants.POST_GRADUATE_PERCENT + userApplicant.getPostGraduationPercentage());
            adminItems.add(Constants.SPECIALIZATION + userApplicant.getSpecialization());
            adminItems.add(Constants.WORK_EXPERIENCE + userApplicant.getWorkExperience());
            adminItems.addAll(userSkillsList);
        }
        ArrayAdapter<String> adapter = new ArrayAdapter<>
                (this, android.R.layout.select_dialog_item, adminItems);
        acSearch.setThreshold(1);
        acSearch.setAdapter(adapter);
        acSearch.setTextColor(Color.BLUE);
    }

    private void setUpRecyclerView() {
        userApplicantListAdapter = new UserApplicantListAdapter(this, rlManageCandidateLayout,
                userApplicantList);
        rvCandidate.setAdapter(userApplicantListAdapter);
        rvCandidate.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL,
                false));
        userApplicantListAdapter.notifyDataSetChanged();
    }

    public void onClickImageBtnSearch() {
        try {
            alertFilter = getLayoutInflater().inflate(R.layout.alert_filter, null);
            alertBuilder = new AlertDialog.Builder(this);
            if (alertFilter.getParent() != null) {
                ((ViewGroup) alertFilter.getParent()).removeView(alertFilter);
            }
            alertBuilder.setView(alertFilter);
            initPaymentAlertUI(alertFilter);
            alertDialog = alertBuilder.create();
        } catch (Exception exception) {
            exception.printStackTrace();
        }

        if (!alertDialog.isShowing())
            alertDialog = alertBuilder.show();
    }

    private void initPaymentAlertUI(View view) {
        alertTvAllJobs = view.findViewById(R.id.tvAllJobs);
        alertTvJobName = view.findViewById(R.id.tvJobName);
        alertTvSkills = view.findViewById(R.id.tvSkills);
        alertTvCompany = view.findViewById(R.id.tvCompany);
        alertTvSSCPercent = view.findViewById(R.id.tvSSCPercent);
        alertTvHSCPercent = view.findViewById(R.id.tvHSCPercent);
        alertTvGraduatePercent = view.findViewById(R.id.tvGraduatePercent);
        alertTvPostGraduatePercent = view.findViewById(R.id.tvPostGraduatePercent);
        alertTvSpecialization = view.findViewById(R.id.tvSpecialization);
        alertBtnCancel = view.findViewById(R.id.alertBtnCancel);
        alertBtnCancel.setOnClickListener(this);
        alertTvJobName.setOnClickListener(this);
        alertTvSkills.setOnClickListener(this);
        alertTvCompany.setOnClickListener(this);
        alertTvSSCPercent.setOnClickListener(this);
        alertTvHSCPercent.setOnClickListener(this);
        alertTvGraduatePercent.setOnClickListener(this);
        alertTvPostGraduatePercent.setOnClickListener(this);
        alertTvSpecialization.setOnClickListener(this);

        alertTvAllJobs.setVisibility(View.GONE);
        alertTvJobName.setText(Constants.NAME);
        alertTvCompany.setText(Constants.WORK_EXPERIENCE);
    }


    private void saveDataToEntityAndSetupRecyclerView(JSONObject json) {
        try {
            JSONArray jsonArray = json.getJSONArray("Data");
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObj = jsonArray.getJSONObject(i);
                entity.setApplicantId(jsonObj.getString("data0"));
                entity.setUserId(jsonObj.getString("data1"));
                entity.setJobId(jsonObj.getString("data2"));
                entity.setDateOfApplication(jsonObj.getString("data3"));
                entity.setStatus(jsonObj.getString("data4"));
                entity.setUserName(jsonObj.getString("data5"));
                entity.setSscPercentage(jsonObj.getString("data8"));
                entity.setHscPercentage(jsonObj.getString("data9"));
                entity.setGraduationPercentage(jsonObj.getString("data10"));
                entity.setPostGraduationPercentage(jsonObj.getString("data11"));
                entity.setSpecialization(jsonObj.getString("data12"));
                entity.setWorkExperience(jsonObj.getString("data13"));
                userApplicantList.add(entity);
                entity = new UserApplicant();
            }
            setUpAutoComplete();
            setUpRecyclerView();
        } catch (Exception exception) {
            exception.printStackTrace();
            Log.e(Constants.COMPANY, exception.getMessage());
        }
    }

    private class AsyncGetCandidate extends AsyncTask<String, String, String> {

        private Dialog dialog;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            dialog = DialogUtils.showLoadingDialog(context, Constants.PLEASE_WAIT);
        }


        @Override
        protected String doInBackground(String... strings) {
            String a;
            try {
                JSONObject json = restAPI.GetUserApplicationByJobId(strings[0]);
                a = jsonParse.parse(json);
            } catch (Exception e) {
                a = e.getMessage();
            }
            return a;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            DialogUtils.dismissLoadingDialog(dialog);
            try {
                if (Utility.checkConnection(s)) {
                    Pair<String, String> pair = Utility.GetErrorMessage(s);
                    Utility.ShowAlertDialog(context, pair.first, pair.second, false);
                } else {
                    //main
                    JSONObject json = new JSONObject(s);

                    //string value
                    String jsonString = json.getString("status");

                    if (jsonString.compareToIgnoreCase("no") == 0) {
                        Helper.makeSnackBar(rlManageCandidateLayout, "No Data found");

                    } else if (jsonString.compareToIgnoreCase("ok") == 0) {
                        tvNoData.setVisibility(View.GONE);
                        acSearchCardLayout.setVisibility(View.VISIBLE);
                        rvCandidate.setVisibility(View.VISIBLE);
                        saveDataToEntityAndSetupRecyclerView(json);
                    } else {
                        Helper.makeSnackBar(rlManageCandidateLayout, "Something Went Wrong");
                    }

                }
            } catch (Exception e) {
                Helper.makeSnackBar(rlManageCandidateLayout, "Something Went Wrong");
            }

        }
    }

    private class AsyncGetAllCandidate extends AsyncTask<String, String, String> {

        private Dialog dialog;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            dialog = DialogUtils.showLoadingDialog(context, Constants.PLEASE_WAIT);
        }


        @Override
        protected String doInBackground(String... strings) {
            String a;
            try {
                JSONObject json = restAPI.GetAllUserApplication();
                a = jsonParse.parse(json);
            } catch (Exception e) {
                a = e.getMessage();
            }
            return a;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            DialogUtils.dismissLoadingDialog(dialog);
            try {
                if (Utility.checkConnection(s)) {
                    Pair<String, String> pair = Utility.GetErrorMessage(s);
                    Utility.ShowAlertDialog(context, pair.first, pair.second, false);
                } else {
                    //main
                    JSONObject json = new JSONObject(s);

                    //string value
                    String jsonString = json.getString("status");

                    if (jsonString.compareToIgnoreCase("no") == 0) {
                        Helper.makeSnackBar(rlManageCandidateLayout, "No Data found");

                    } else if (jsonString.compareToIgnoreCase("ok") == 0) {
                        tvNoData.setVisibility(View.GONE);
                        acSearchCardLayout.setVisibility(View.VISIBLE);
                        rvCandidate.setVisibility(View.VISIBLE);
                        saveDataToEntityAndSetupRecyclerView(json);
                    } else {
                        Helper.makeSnackBar(rlManageCandidateLayout, "Something Went Wrong");
                    }

                }
            } catch (Exception e) {
                Helper.makeSnackBar(rlManageCandidateLayout, "Something Went Wrong");
            }

        }
    }

    private class AsyncGetUserSkills extends AsyncTask<String, String, String> {

        private Dialog dialog;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            dialog = DialogUtils.showLoadingDialog(context, Constants.PLEASE_WAIT);
        }


        @Override
        protected String doInBackground(String... strings) {
            String a;
            try {
                JSONObject json = restAPI.GetAllUserSkills();
                a = jsonParse.parse(json);
            } catch (Exception e) {
                a = e.getMessage();
            }
            return a;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            DialogUtils.dismissLoadingDialog(dialog);
            try {
                if (Utility.checkConnection(s)) {
                    Pair<String, String> pair = Utility.GetErrorMessage(s);
                    Utility.ShowAlertDialog(context, pair.first, pair.second, false);
                } else {
                    //main
                    JSONObject json = new JSONObject(s);

                    //string value
                    String jsonString = json.getString("status");

                    if (jsonString.compareToIgnoreCase("no") == 0) {
                        Helper.makeSnackBar(rlManageCandidateLayout, "No Data found");

                    } else if (jsonString.compareToIgnoreCase("ok") == 0) {
                        try {
                            JSONArray jsonArray = json.getJSONArray("Data");
                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject jsonObj = jsonArray.getJSONObject(i);
                                if (jsonObj.getString("data2") != null) {
                                    if (!jsonObj.getString("data2").isEmpty()) {
                                        userSkillsList.add(jsonObj.getString("data2"));
                                        userSkills = new UserSkills();
                                    }
                                }
                            }
                        } catch (Exception exception) {
                            exception.printStackTrace();
                            Log.e(Constants.COMPANY, exception.getMessage());
                        }
                    } else {
                        Helper.makeSnackBar(rlManageCandidateLayout, "Something Went Wrong");
                    }

                }
            } catch (Exception e) {
                Helper.makeSnackBar(rlManageCandidateLayout, "Something Went Wrong");
            }

        }
    }

}