package com.example.jobportal.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.jobportal.R;
import com.example.jobportal.activity.user.ViewJobDetailsOrApplyActivity;
import com.example.jobportal.model.Jobs;
import com.example.jobportal.utility.Constants;
import com.example.jobportal.utility.Helper;

import java.util.List;

public class SearchJobListAdapter extends RecyclerView.Adapter<SearchJobListAdapter.ViewHolder> implements View.OnClickListener {

    private Context context;
    private final List<Jobs> jobsList;
    private Jobs jobs;

    public SearchJobListAdapter(Context context, List<Jobs> jobsList) {
        this.context = context;
        this.jobsList = jobsList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        context = parent.getContext();
        LayoutInflater inflater = LayoutInflater.from(context);
        View detailItem = inflater.inflate(R.layout.list_job_with_details, parent, false);
        return new ViewHolder(detailItem);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        if (jobsList.size() != 0) {
            jobs = jobsList.get(position);
            holder.tvJobName.setText(jobs.getJobName());
            holder.tvJobStartDate.setText(jobs.getJobStartDate());
            holder.tvJobPosition.setText(jobs.getJobPositionName());
            holder.tvApplyOrViewDetails.setOnClickListener(this);
        }
    }

    @Override
    public int getItemCount() {
        return jobsList.size();
    }

    @Override
    public void onClick(View view) {
        if (view.getId() == R.id.tvApplyOrViewDetails) {
            onClickBtnApplyOrViewDetails();
        }
    }

    private void onClickBtnApplyOrViewDetails() {
        Helper.goTo(context, ViewJobDetailsOrApplyActivity.class,
                Constants.JOBS, jobs);
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        private final TextView tvJobName;
        private final TextView tvJobPosition;
        private final TextView tvJobStartDate;
        private final TextView tvApplyOrViewDetails;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            tvJobName = itemView.findViewById(R.id.tvJobName);
            tvJobPosition = itemView.findViewById(R.id.tvJobPosition);
            tvJobStartDate = itemView.findViewById(R.id.tvJobStartDate);
            tvApplyOrViewDetails = itemView.findViewById(R.id.tvApplyOrViewDetails);
        }
    }
}
