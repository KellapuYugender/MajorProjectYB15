package com.example.jobportal.activity.user;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.jobportal.R;
import com.example.jobportal.fragments.AcceptedFragment;
import com.example.jobportal.fragments.PendingApplicationFragment;
import com.example.jobportal.fragments.RejectedFragment;
import com.example.jobportal.utility.Constants;
import com.google.android.material.tabs.TabLayout;

public class ApplicationTabsActivity extends AppCompatActivity {

    private LinearLayout llApplicationHistoryTabActivityLayout;
    private static TabLayout tabLayout;
    private static ViewPager viewPager;
    private final static int int_items = 3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_application_tabs);

        initToolbar();
        initUI();
    }

    private void initToolbar() {

        Toolbar toolbar = findViewById(R.id.toolbar);
        TextView tvTitle = toolbar.findViewById(R.id.tvTitle);
        tvTitle.setText(Constants.HISTORY);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null)
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);

    }

    private void initUI() {
        llApplicationHistoryTabActivityLayout = findViewById(R.id.llApplicationHistoryTabActivityLayout);
        tabLayout = findViewById(R.id.tabs);
        viewPager = findViewById(R.id.viewpager);
        MyAdapter adapter = new MyAdapter(getSupportFragmentManager());
        viewPager.setAdapter(adapter);

        tabLayout.post(() -> tabLayout.setupWithViewPager(viewPager));

    }

    class MyAdapter extends FragmentPagerAdapter {

        public MyAdapter(FragmentManager fm) {
            super(fm);
        }

        @Override
        public Fragment getItem(int position) {
            switch (position) {
                case 0:
                    return new PendingApplicationFragment();
                case 1:
                    return new AcceptedFragment();
                case 2:
                    return new RejectedFragment();
            }
            return new PendingApplicationFragment();
        }

        @Override
        public int getCount() {
            return int_items;
        }

        @Override
        public CharSequence getPageTitle(int position) {

            switch (position) {
                case 0:
                    return "Pending";
                case 1:
                    return "Accepted";
                case 2:
                    return "Rejected";
            }
            return null;
        }
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

}