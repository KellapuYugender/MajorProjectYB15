package com.example.jobportal.model;

public class UserDetails {

    private String userDetailsId,userId;
    private String sscPercentage,hscPercentage,graduationPercentage,
            postGraduationPercentage,specialization,workExperience,cv;

    public String getUserDetailsId() {
        return userDetailsId;
    }

    public void setUserDetailsId(String userDetailsId) {
        this.userDetailsId = userDetailsId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getSscPercentage() {
        return sscPercentage;
    }

    public void setSscPercentage(String sscPercentage) {
        this.sscPercentage = sscPercentage;
    }

    public String getHscPercentage() {
        return hscPercentage;
    }

    public void setHscPercentage(String hscPercentage) {
        this.hscPercentage = hscPercentage;
    }

    public String getGraduationPercentage() {
        return graduationPercentage;
    }

    public void setGraduationPercentage(String graduationPercentage) {
        this.graduationPercentage = graduationPercentage;
    }

    public String getPostGraduationPercentage() {
        return postGraduationPercentage;
    }

    public void setPostGraduationPercentage(String postGraduationPercentage) {
        this.postGraduationPercentage = postGraduationPercentage;
    }

    public String getSpecialization() {
        return specialization;
    }

    public void setSpecialization(String specialization) {
        this.specialization = specialization;
    }

    public String getWorkExperience() {
        return workExperience;
    }

    public void setWorkExperience(String workExperience) {
        this.workExperience = workExperience;
    }

    public String getCv() {
        return cv;
    }

    public void setCv(String cv) {
        this.cv = cv;
    }
}
