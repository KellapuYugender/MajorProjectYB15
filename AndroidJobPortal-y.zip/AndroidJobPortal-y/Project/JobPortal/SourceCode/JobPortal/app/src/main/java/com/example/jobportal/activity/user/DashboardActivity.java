package com.example.jobportal.activity.user;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.util.Pair;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.example.jobportal.R;
import com.example.jobportal.activity.LoginActivity;
import com.example.jobportal.activity.MainActivity;
import com.example.jobportal.activity.ProfileActivity;
import com.example.jobportal.activity.recruiter.ManageCandidatesActivity;
import com.example.jobportal.activity.recruiter.ManageCompanyActivity;
import com.example.jobportal.utility.BackgroundNotificationService;
import com.example.jobportal.utility.Constants;
import com.example.jobportal.utility.DialogUtils;
import com.example.jobportal.utility.Helper;
import com.example.jobportal.utility.MyNotificationService;
import com.example.jobportal.utility.UserPref;
import com.example.jobportal.utility.webServices.JSONParse;
import com.example.jobportal.utility.webServices.RestAPI;
import com.example.jobportal.utility.webServices.Utility;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Random;

public class DashboardActivity extends AppCompatActivity implements View.OnClickListener {

    private AlertDialog alertDialog;
    private Context context;
    private Dialog dialog;
    private boolean userDetailCompletionStatus = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(Color.WHITE);
        }

        if (!Helper.isMyServiceRunning(this)) {
            Intent serviceIntent = new Intent(this, MyNotificationService.class);
            ContextCompat.startForegroundService(this, serviceIntent);
        }

        initUI();
        context = this;
        checkUserProfileStatus();
    }

    private void initUI() {
        LinearLayout llSearchJobsLayout = findViewById(R.id.llSearchJobsLayout);
        LinearLayout llApplicationHistory = findViewById(R.id.llApplicationHistory);
        LinearLayout llProfileLayout = findViewById(R.id.llProfileLayout);
        LinearLayout llLogoutLayout = findViewById(R.id.llLogoutLayout);

        llSearchJobsLayout.setOnClickListener(this);
        llApplicationHistory.setOnClickListener(this);
        llProfileLayout.setOnClickListener(this);
        llLogoutLayout.setOnClickListener(this);

    }

    @SuppressLint("NonConstantResourceId")
    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.llSearchJobsLayout:
                if (UserPref.getUserProfileStatus(this)) {
                    Helper.goTo(this, SearchJobActivity.class);
                } else {
                    Helper.goTo(this, AddUserDetailsActivity.class);
                }
                break;
            case R.id.llApplicationHistory:
                if (UserPref.getUserProfileStatus(this)) {
                    Helper.goTo(this, ApplicationTabsActivity.class);
                } else {
                    Helper.goTo(this, AddUserDetailsActivity.class);
                }
                break;
            case R.id.llProfileLayout:
                if (UserPref.getUserProfileStatus(this)) {
                    Helper.goTo(this, ProfileActivity.class);
                } else {
                    Helper.goTo(this, AddUserDetailsActivity.class);
                }
                break;
            case R.id.llLogoutLayout:
                logout();
                break;
            case R.id.alertBtnLogout:
                alertButtonLogoutClick();
                break;
            case R.id.alertBtnBack:
                alertDialog.dismiss();
        }
    }

    private void checkUserProfileStatus() {
        new AsyncGetUserDetails().execute(UserPref.getUser(context));
    }

    private void logout() {

        View alertView = getLayoutInflater().inflate(R.layout.alert_logout_confirmation, null);

        Button alertBtnBack = alertView.findViewById(R.id.alertBtnBack);
        Button alertBtnLogout = alertView.findViewById(R.id.alertBtnLogout);

        alertBtnBack.setOnClickListener(this);
        alertBtnLogout.setOnClickListener(this);

        AlertDialog.Builder alert = new AlertDialog.Builder(this);
        if (alertView.getParent() != null) {
            ((ViewGroup) alertView.getParent()).removeView(alertView);
        }
        alert.setView(alertView);
        alertDialog = alert.show();


    }

    private void alertButtonLogoutClick() {
        UserPref.setLoginStatus(this, false);
        UserPref.deleteAll(this);
        if (Helper.isMyServiceRunning(DashboardActivity.this)) {
            Intent serviceNotification = new Intent(DashboardActivity.this, MyNotificationService.class);
            stopService(serviceNotification);
        }
        int flags = Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK;
        Helper.goToWithFlags(this, MainActivity.class, flags);
        finish();
    }

    private class AsyncGetUserDetails extends AsyncTask<String, JSONObject, String> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            dialog = DialogUtils.showLoadingDialog(context, Constants.PLEASE_WAIT);
        }

        @Override
        protected String doInBackground(String... strings) {
            String data = null;
            RestAPI restAPI = new RestAPI();
            try {
                JSONObject json = restAPI.GetUserDetails(strings[0]);
                JSONParse jp = new JSONParse();
                data = jp.parse(json);
            } catch (Exception e) {
                data = e.getMessage();
            }
            return data;
        }


        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            DialogUtils.dismissLoadingDialog(dialog);
            try {
                if (Utility.checkConnection(s)) {
                    Pair<String, String> pair = Utility.GetErrorMessage(s);
                    Utility.ShowAlertDialog(context, pair.first, pair.second, false);
                } else {
                    JSONObject json = new JSONObject(s);
                    String StatusValue = json.getString("status");
                    if (StatusValue.compareTo("ok") == 0) {
                        UserPref.setProfileStatus(context, true);
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

}