package com.example.jobportal.utility;


import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.util.Log;
import android.util.Pair;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

import com.example.jobportal.R;
import com.example.jobportal.activity.LoginActivity;
import com.example.jobportal.utility.webServices.JSONParse;
import com.example.jobportal.utility.webServices.RestAPI;
import com.example.jobportal.utility.webServices.Utility;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;


public class MyNotificationService extends Service {
    private static final String TAG = MyNotificationService.class.getSimpleName();
    public static final int NOTIFICATION_ID = 101;
    private Context context;
    Timer timer;
    TimerTask timerTask;
    Handler hand = new Handler();

    @Override
    public void onCreate() {
        super.onCreate();
        context = this;
        startServices();
        timerTask = new TimerTask() {
            @Override
            public void run() {
                hand.post(new TimerTask() {
                    @Override
                    public void run() {
                        Log.i(TAG, "run: ");
                        if (UserPref.getUser(context) != null) {
                            if (!UserPref.getUser(context).isEmpty()) {
                                if (UserPref.getUserType(context).equalsIgnoreCase(Constants.TYPE_USER)) {
                                    new getUserNotification().execute(UserPref.getUser(context));
                                } else {
                                    new getRecruiterNotification().execute(UserPref.getUser(context));
                                }
                            }
                        }
                    }
                });
            }
        };
        timer = new Timer();
        timer.schedule(timerTask, 0, 10000);
    }

    private void startServices() {
        Intent notificationIntent = new Intent(this, LoginActivity.class);  //changes
        PendingIntent pendingIntent =
                PendingIntent.getActivity(this, 0, notificationIntent, 0);

        createNotificationChannel(getApplicationContext(), CHANNEL_ID);

        Notification notification = new NotificationCompat
                .Builder(getApplicationContext(), CHANNEL_ID)
                .setContentTitle("Job Portal")
                .setContentText("Job Portal is working in background to send notifications")
                .setSmallIcon(R.drawable.logo_24px)
                .setContentIntent(pendingIntent)
                .setAutoCancel(true)
                .build();

        startForeground(NOTIFICATION_ID, notification);
    }

    private static final String CHANNEL_ID = "JobPortal";

    public static void createNotificationChannel(@NonNull Context context, @NonNull String CHANNEL_ID) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "JobPortal";
            String description = "JobPortal";
            int importance = NotificationManager.IMPORTANCE_LOW;
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, name, importance);
            channel.setDescription(description);
            NotificationManager notificationManager = context.getSystemService(NotificationManager.class);
            if (notificationManager != null) {
                notificationManager.createNotificationChannel(channel);
            } else {
                Log.d("NotificationLog", "NotificationManagerNull");
            }
        }
    }


    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.i(TAG, "onStartCommand: " + flags + " " + startId);
        super.onStartCommand(intent, flags, startId);
        return START_STICKY;
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onDestroy() {
        if (timer != null && timerTask != null) {
            timer.cancel();
            timerTask.cancel();
        }
        Log.i(TAG, "onDestroy: ");
        super.onDestroy();
    }

    private class getUserNotification extends AsyncTask<String, JSONObject, String> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(String... strings) {
            String data = null;
            RestAPI restAPI = new RestAPI();
            try {
                JSONObject json = restAPI.GetUserNotification(strings[0]);
                JSONParse jp = new JSONParse();
                data = jp.parse(json);
                Log.d(TAG, data);
            } catch (Exception e) {
                Log.d(TAG, e.getMessage());
                data = e.getMessage();
            }
            return data;
        }


        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            Log.d(TAG, s);
            try {
                if (Utility.checkConnection(s)) {
                    Pair<String, String> pair = Utility.GetErrorMessage(s);
                    Utility.ShowAlertDialog(context, pair.first, pair.second, false);
                } else {
                    JSONObject json = new JSONObject(s);
                    String StatusValue = json.getString("status");
                    if (StatusValue.compareTo("ok") == 0) {
                        JSONArray jsonArray = json.getJSONArray("Data");
                        JSONObject jsonObj = jsonArray.getJSONObject(0);
                        String userId = jsonObj.getString("data0");
                        String Title = jsonObj.getString("data2");
                        String Message = jsonObj.getString("data4");
                        if (UserPref.getUser(context).equalsIgnoreCase(userId)) {
                            NotificationUtil noti = new NotificationUtil(MyNotificationService.this);
                            noti.showNotification(Title, Message);
                        }
                    }
                }
            } catch (Exception e) {
                Log.d(TAG + "EXE", e.getMessage());
            }
        }
    }

    private class getRecruiterNotification extends AsyncTask<String, JSONObject, String> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(String... strings) {
            String data = null;
            RestAPI restAPI = new RestAPI();
            try {
                JSONObject json = restAPI.GetRecruiterNotification(strings[0]);
                JSONParse jp = new JSONParse();
                data = jp.parse(json);
                Log.d(TAG, data);
            } catch (Exception e) {
                Log.d(TAG, e.getMessage());
                data = e.getMessage();
            }
            return data;
        }


        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            Log.d(TAG, s);
            try {
                if (Utility.checkConnection(s)) {
                    Pair<String, String> pair = Utility.GetErrorMessage(s);
                    Utility.ShowAlertDialog(context, pair.first, pair.second, false);
                } else {
                    JSONObject json = new JSONObject(s);
                    String StatusValue = json.getString("status");
                    if (StatusValue.compareTo("ok") == 0) {

                        JSONArray jsonArray = json.getJSONArray("Data");
                        JSONObject jsonObj = jsonArray.getJSONObject(0);
                        String userId = jsonObj.getString("data1");
                        String Title = jsonObj.getString("data2");
                        String Message = jsonObj.getString("data4");
                        if (UserPref.getUser(context).equalsIgnoreCase(userId)) {
                            NotificationUtil noti = new NotificationUtil(MyNotificationService.this);
                            noti.showNotification(Title, Message);
                        }
                    }
                }
            } catch (Exception e) {
                Log.d(TAG + "EXE", e.getMessage());
            }
        }
    }

}