package com.example.jobportal.model;

import java.io.Serializable;

public class JobSkills implements Serializable {

    private String jobSkillsId,jobId,skills;

    public String getJobSkillsId() {
        return jobSkillsId;
    }

    public void setJobSkillsId(String jobSkillsId) {
        this.jobSkillsId = jobSkillsId;
    }

    public String getJobId() {
        return jobId;
    }

    public void setJobId(String jobId) {
        this.jobId = jobId;
    }

    public String getSkills() {
        return skills;
    }

    public void setSkills(String skills) {
        this.skills = skills;
    }
}
