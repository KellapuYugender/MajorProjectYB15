package com.example.jobportal.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;

import com.example.jobportal.R;
import com.example.jobportal.activity.recruiter.RecruiterDashboardActivity;
import com.example.jobportal.activity.user.DashboardActivity;
import com.example.jobportal.utility.Constants;
import com.example.jobportal.utility.Helper;
import com.example.jobportal.utility.UserPref;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        checkForLoginStatusAndNavigate();
    }

    private void checkForLoginStatusAndNavigate() {
        boolean loginStatus = UserPref.getLoginStatus(this);
        if (loginStatus) {
            int flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
                    | Intent.FLAG_ACTIVITY_CLEAR_TASK
                    | Intent.FLAG_ACTIVITY_NEW_TASK;

            String userType = UserPref.getStringValue(this, Constants.USER_TYPE);
            if (userType.equalsIgnoreCase(Constants.TYPE_RECRUITER)) {
                Helper.goToWithFlags(this, RecruiterDashboardActivity.class, flags);
            } else {
                Helper.goToWithFlags(this, DashboardActivity.class, flags);
            }
            finish();

        } else {
            setContentView(R.layout.activity_main);
            initUI();
        }
    }

    private void initUI() {

        LinearLayout llUserLoginLayout = findViewById(R.id.llUserLoginLayout);
        LinearLayout llRecruiterLoginLayout = findViewById(R.id.llRecruiterLoginLayout);

        llUserLoginLayout.setOnClickListener(this);
        llRecruiterLoginLayout.setOnClickListener(this);

    }

    @SuppressLint("NonConstantResourceId")
    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.llUserLoginLayout:
                Helper.goTo(this, LoginActivity.class,
                        Constants.USER_TYPE, Constants.TYPE_USER);
                break;
            case R.id.llRecruiterLoginLayout:
                Helper.goTo(this, LoginActivity.class,
                        Constants.USER_TYPE, Constants.TYPE_RECRUITER);
                break;
        }
    }
}