/* JSON API for android appliation */
package com.example.jobportal.utility.webServices;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.net.HttpURLConnection;
import java.net.URL;
import org.json.JSONObject;
import org.json.JSONArray;

public class RestAPI {
    private final String urlString = "http://ajobportal.hostoise.com/handler1.ashx";

    private static String convertStreamToUTF8String(InputStream stream) throws IOException {
	    String result = "";
	    StringBuilder sb = new StringBuilder();
	    try {
            InputStreamReader reader = new InputStreamReader(stream, "UTF-8");
            char[] buffer = new char[4096];
            int readedChars = 0;
            while (readedChars != -1) {
                readedChars = reader.read(buffer);
                if (readedChars > 0)
                   sb.append(buffer, 0, readedChars);
            }
            result = sb.toString();
		} catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        return result;
    }


    private String load(String contents) throws IOException {
        URL url = new URL(urlString);
        HttpURLConnection conn = (HttpURLConnection)url.openConnection();
        conn.setRequestMethod("POST");
        conn.setConnectTimeout(60000);
        conn.setDoOutput(true);
        conn.setDoInput(true);
        OutputStreamWriter w = new OutputStreamWriter(conn.getOutputStream());
        w.write(contents);
        w.flush();
        InputStream istream = conn.getInputStream();
        String result = convertStreamToUTF8String(istream);
        return result;
    }


    private Object mapObject(Object o) {
		Object finalValue = null;
		if (o.getClass() == String.class) {
			finalValue = o;
		}
		else if (Number.class.isInstance(o)) {
			finalValue = String.valueOf(o);
		} else if (Date.class.isInstance(o)) {
			SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss", new Locale("en", "USA"));
			finalValue = sdf.format((Date)o);
		}
		else if (Collection.class.isInstance(o)) {
			Collection<?> col = (Collection<?>) o;
			JSONArray jarray = new JSONArray();
			for (Object item : col) {
				jarray.put(mapObject(item));
			}
			finalValue = jarray;
		} else {
			Map<String, Object> map = new HashMap<String, Object>();
			Method[] methods = o.getClass().getMethods();
			for (Method method : methods) {
				if (method.getDeclaringClass() == o.getClass()
						&& method.getModifiers() == Modifier.PUBLIC
						&& method.getName().startsWith("get")) {
					String key = method.getName().substring(3);
					try {
						Object obj = method.invoke(o, null);
						Object value = mapObject(obj);
						map.put(key, value);
						finalValue = new JSONObject(map);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}

		}
		return finalValue;
	}

    public JSONObject Register(String firstName,String lastName,String emailId,String phoneNumber,String password,String summary) throws Exception {
        JSONObject result = null;
        JSONObject o = new JSONObject();
        JSONObject p = new JSONObject();
        o.put("interface","RestAPI");
        o.put("method", "Register");
        p.put("firstName",mapObject(firstName));
        p.put("lastName",mapObject(lastName));
        p.put("emailId",mapObject(emailId));
        p.put("phoneNumber",mapObject(phoneNumber));
        p.put("password",mapObject(password));
        p.put("summary",mapObject(summary));
        o.put("parameters", p);
        String s = o.toString();
        String r = load(s);
        result = new JSONObject(r);
        return result;
    }

    public JSONObject UpdateUserDetails(String userId,String sscPercentage,String hscPercentage,String graduationPercentage,String postGraduationPercentage,String workExperience,String specialization,String cv) throws Exception {
        JSONObject result = null;
        JSONObject o = new JSONObject();
        JSONObject p = new JSONObject();
        o.put("interface","RestAPI");
        o.put("method", "UpdateUserDetails");
        p.put("userId",mapObject(userId));
        p.put("sscPercentage",mapObject(sscPercentage));
        p.put("hscPercentage",mapObject(hscPercentage));
        p.put("graduationPercentage",mapObject(graduationPercentage));
        p.put("postGraduationPercentage",mapObject(postGraduationPercentage));
        p.put("workExperience",mapObject(workExperience));
        p.put("specialization",mapObject(specialization));
        p.put("cv",mapObject(cv));
        o.put("parameters", p);
        String s = o.toString();
        String r = load(s);
        result = new JSONObject(r);
        return result;
    }

    public JSONObject Login(String emailId,String password) throws Exception {
        JSONObject result = null;
        JSONObject o = new JSONObject();
        JSONObject p = new JSONObject();
        o.put("interface","RestAPI");
        o.put("method", "Login");
        p.put("emailId",mapObject(emailId));
        p.put("password",mapObject(password));
        o.put("parameters", p);
        String s = o.toString();
        String r = load(s);
        result = new JSONObject(r);
        return result;
    }

    public JSONObject GetProfile(String userId) throws Exception {
        JSONObject result = null;
        JSONObject o = new JSONObject();
        JSONObject p = new JSONObject();
        o.put("interface","RestAPI");
        o.put("method", "GetProfile");
        p.put("userId",mapObject(userId));
        o.put("parameters", p);
        String s = o.toString();
        String r = load(s);
        result = new JSONObject(r);
        return result;
    }

    public JSONObject UpdateProfile(String userId,String firstName,String lastName,String phoneNumber,String summary) throws Exception {
        JSONObject result = null;
        JSONObject o = new JSONObject();
        JSONObject p = new JSONObject();
        o.put("interface","RestAPI");
        o.put("method", "UpdateProfile");
        p.put("userId",mapObject(userId));
        p.put("firstName",mapObject(firstName));
        p.put("lastName",mapObject(lastName));
        p.put("phoneNumber",mapObject(phoneNumber));
        p.put("summary",mapObject(summary));
        o.put("parameters", p);
        String s = o.toString();
        String r = load(s);
        result = new JSONObject(r);
        return result;
    }

    public JSONObject ChangePassword(String userId,String oldPass,String newPass) throws Exception {
        JSONObject result = null;
        JSONObject o = new JSONObject();
        JSONObject p = new JSONObject();
        o.put("interface","RestAPI");
        o.put("method", "ChangePassword");
        p.put("userId",mapObject(userId));
        p.put("oldPass",mapObject(oldPass));
        p.put("newPass",mapObject(newPass));
        o.put("parameters", p);
        String s = o.toString();
        String r = load(s);
        result = new JSONObject(r);
        return result;
    }

    public JSONObject GetUserDetails(String userId) throws Exception {
        JSONObject result = null;
        JSONObject o = new JSONObject();
        JSONObject p = new JSONObject();
        o.put("interface","RestAPI");
        o.put("method", "GetUserDetails");
        p.put("userId",mapObject(userId));
        o.put("parameters", p);
        String s = o.toString();
        String r = load(s);
        result = new JSONObject(r);
        return result;
    }

    public JSONObject AddUserSkills(String userId,ArrayList<String> skillsArray) throws Exception {
        JSONObject result = null;
        JSONObject o = new JSONObject();
        JSONObject p = new JSONObject();
        o.put("interface","RestAPI");
        o.put("method", "AddUserSkills");
        p.put("userId",mapObject(userId));
        p.put("skillsArray",mapObject(skillsArray));
        o.put("parameters", p);
        String s = o.toString();
        String r = load(s);
        result = new JSONObject(r);
        return result;
    }

    public JSONObject GetUserSkills(String userId) throws Exception {
        JSONObject result = null;
        JSONObject o = new JSONObject();
        JSONObject p = new JSONObject();
        o.put("interface","RestAPI");
        o.put("method", "GetUserSkills");
        p.put("userId",mapObject(userId));
        o.put("parameters", p);
        String s = o.toString();
        String r = load(s);
        result = new JSONObject(r);
        return result;
    }

    public JSONObject GetAllUserSkills() throws Exception {
        JSONObject result = null;
        JSONObject o = new JSONObject();
        JSONObject p = new JSONObject();
        o.put("interface","RestAPI");
        o.put("method", "GetAllUserSkills");
        o.put("parameters", p);
        String s = o.toString();
        String r = load(s);
        result = new JSONObject(r);
        return result;
    }

    public JSONObject AddUserApplicantion(String userId,String jobId,String dateOfApplication) throws Exception {
        JSONObject result = null;
        JSONObject o = new JSONObject();
        JSONObject p = new JSONObject();
        o.put("interface","RestAPI");
        o.put("method", "AddUserApplicantion");
        p.put("userId",mapObject(userId));
        p.put("jobId",mapObject(jobId));
        p.put("dateOfApplication",mapObject(dateOfApplication));
        o.put("parameters", p);
        String s = o.toString();
        String r = load(s);
        result = new JSONObject(r);
        return result;
    }

    public JSONObject GetAllUserApplication() throws Exception {
        JSONObject result = null;
        JSONObject o = new JSONObject();
        JSONObject p = new JSONObject();
        o.put("interface","RestAPI");
        o.put("method", "GetAllUserApplication");
        o.put("parameters", p);
        String s = o.toString();
        String r = load(s);
        result = new JSONObject(r);
        return result;
    }

    public JSONObject GetUserApplicationByJobId(String jobId) throws Exception {
        JSONObject result = null;
        JSONObject o = new JSONObject();
        JSONObject p = new JSONObject();
        o.put("interface","RestAPI");
        o.put("method", "GetUserApplicationByJobId");
        p.put("jobId",mapObject(jobId));
        o.put("parameters", p);
        String s = o.toString();
        String r = load(s);
        result = new JSONObject(r);
        return result;
    }

    public JSONObject GetUserApplicationByUserId(String userId) throws Exception {
        JSONObject result = null;
        JSONObject o = new JSONObject();
        JSONObject p = new JSONObject();
        o.put("interface","RestAPI");
        o.put("method", "GetUserApplicationByUserId");
        p.put("userId",mapObject(userId));
        o.put("parameters", p);
        String s = o.toString();
        String r = load(s);
        result = new JSONObject(r);
        return result;
    }

    public JSONObject ViewFilteredJobs(String filterType,String filterValue) throws Exception {
        JSONObject result = null;
        JSONObject o = new JSONObject();
        JSONObject p = new JSONObject();
        o.put("interface","RestAPI");
        o.put("method", "ViewFilteredJobs");
        p.put("filterType",mapObject(filterType));
        p.put("filterValue",mapObject(filterValue));
        o.put("parameters", p);
        String s = o.toString();
        String r = load(s);
        result = new JSONObject(r);
        return result;
    }

    public JSONObject Recruiter(String firstName,String lastName,String emailId,String phoneNumber,String password,String summary) throws Exception {
        JSONObject result = null;
        JSONObject o = new JSONObject();
        JSONObject p = new JSONObject();
        o.put("interface","RestAPI");
        o.put("method", "Recruiter");
        p.put("firstName",mapObject(firstName));
        p.put("lastName",mapObject(lastName));
        p.put("emailId",mapObject(emailId));
        p.put("phoneNumber",mapObject(phoneNumber));
        p.put("password",mapObject(password));
        p.put("summary",mapObject(summary));
        o.put("parameters", p);
        String s = o.toString();
        String r = load(s);
        result = new JSONObject(r);
        return result;
    }

    public JSONObject RecruiterLogin(String emailId,String password) throws Exception {
        JSONObject result = null;
        JSONObject o = new JSONObject();
        JSONObject p = new JSONObject();
        o.put("interface","RestAPI");
        o.put("method", "RecruiterLogin");
        p.put("emailId",mapObject(emailId));
        p.put("password",mapObject(password));
        o.put("parameters", p);
        String s = o.toString();
        String r = load(s);
        result = new JSONObject(r);
        return result;
    }

    public JSONObject GetRecruiterProfile(String recruiterId) throws Exception {
        JSONObject result = null;
        JSONObject o = new JSONObject();
        JSONObject p = new JSONObject();
        o.put("interface","RestAPI");
        o.put("method", "GetRecruiterProfile");
        p.put("recruiterId",mapObject(recruiterId));
        o.put("parameters", p);
        String s = o.toString();
        String r = load(s);
        result = new JSONObject(r);
        return result;
    }

    public JSONObject UpdateRecruiterProfile(String recruiterId,String firstName,String lastName,String phoneNumber,String summary) throws Exception {
        JSONObject result = null;
        JSONObject o = new JSONObject();
        JSONObject p = new JSONObject();
        o.put("interface","RestAPI");
        o.put("method", "UpdateRecruiterProfile");
        p.put("recruiterId",mapObject(recruiterId));
        p.put("firstName",mapObject(firstName));
        p.put("lastName",mapObject(lastName));
        p.put("phoneNumber",mapObject(phoneNumber));
        p.put("summary",mapObject(summary));
        o.put("parameters", p);
        String s = o.toString();
        String r = load(s);
        result = new JSONObject(r);
        return result;
    }

    public JSONObject ChangeRecruiterPassword(String recruiterId,String oldPass,String newPass) throws Exception {
        JSONObject result = null;
        JSONObject o = new JSONObject();
        JSONObject p = new JSONObject();
        o.put("interface","RestAPI");
        o.put("method", "ChangeRecruiterPassword");
        p.put("recruiterId",mapObject(recruiterId));
        p.put("oldPass",mapObject(oldPass));
        p.put("newPass",mapObject(newPass));
        o.put("parameters", p);
        String s = o.toString();
        String r = load(s);
        result = new JSONObject(r);
        return result;
    }

    public JSONObject AddCompany(String companyName,String companyDescription) throws Exception {
        JSONObject result = null;
        JSONObject o = new JSONObject();
        JSONObject p = new JSONObject();
        o.put("interface","RestAPI");
        o.put("method", "AddCompany");
        p.put("companyName",mapObject(companyName));
        p.put("companyDescription",mapObject(companyDescription));
        o.put("parameters", p);
        String s = o.toString();
        String r = load(s);
        result = new JSONObject(r);
        return result;
    }

    public JSONObject UpdateCompany(String companyId,String companyName,String companyDescription) throws Exception {
        JSONObject result = null;
        JSONObject o = new JSONObject();
        JSONObject p = new JSONObject();
        o.put("interface","RestAPI");
        o.put("method", "UpdateCompany");
        p.put("companyId",mapObject(companyId));
        p.put("companyName",mapObject(companyName));
        p.put("companyDescription",mapObject(companyDescription));
        o.put("parameters", p);
        String s = o.toString();
        String r = load(s);
        result = new JSONObject(r);
        return result;
    }

    public JSONObject GetAllCompany() throws Exception {
        JSONObject result = null;
        JSONObject o = new JSONObject();
        JSONObject p = new JSONObject();
        o.put("interface","RestAPI");
        o.put("method", "GetAllCompany");
        o.put("parameters", p);
        String s = o.toString();
        String r = load(s);
        result = new JSONObject(r);
        return result;
    }

    public JSONObject GetCompanyById(String companyId) throws Exception {
        JSONObject result = null;
        JSONObject o = new JSONObject();
        JSONObject p = new JSONObject();
        o.put("interface","RestAPI");
        o.put("method", "GetCompanyById");
        p.put("companyId",mapObject(companyId));
        o.put("parameters", p);
        String s = o.toString();
        String r = load(s);
        result = new JSONObject(r);
        return result;
    }

    public JSONObject AddJobPositions(String positionName,String description) throws Exception {
        JSONObject result = null;
        JSONObject o = new JSONObject();
        JSONObject p = new JSONObject();
        o.put("interface","RestAPI");
        o.put("method", "AddJobPositions");
        p.put("positionName",mapObject(positionName));
        p.put("description",mapObject(description));
        o.put("parameters", p);
        String s = o.toString();
        String r = load(s);
        result = new JSONObject(r);
        return result;
    }

    public JSONObject UpdateJobPositions(String jobPositionId,String positionName,String description) throws Exception {
        JSONObject result = null;
        JSONObject o = new JSONObject();
        JSONObject p = new JSONObject();
        o.put("interface","RestAPI");
        o.put("method", "UpdateJobPositions");
        p.put("jobPositionId",mapObject(jobPositionId));
        p.put("positionName",mapObject(positionName));
        p.put("description",mapObject(description));
        o.put("parameters", p);
        String s = o.toString();
        String r = load(s);
        result = new JSONObject(r);
        return result;
    }

    public JSONObject GetAllJobPositions() throws Exception {
        JSONObject result = null;
        JSONObject o = new JSONObject();
        JSONObject p = new JSONObject();
        o.put("interface","RestAPI");
        o.put("method", "GetAllJobPositions");
        o.put("parameters", p);
        String s = o.toString();
        String r = load(s);
        result = new JSONObject(r);
        return result;
    }

    public JSONObject GetJobPositionsById(String jobPositionId) throws Exception {
        JSONObject result = null;
        JSONObject o = new JSONObject();
        JSONObject p = new JSONObject();
        o.put("interface","RestAPI");
        o.put("method", "GetJobPositionsById");
        p.put("jobPositionId",mapObject(jobPositionId));
        o.put("parameters", p);
        String s = o.toString();
        String r = load(s);
        result = new JSONObject(r);
        return result;
    }

    public JSONObject AddJobs(String jobName,String description,String datePublished,String jobStartDate,String noOfVaccancy,String summary,String jobPositionId,String jobCategory,String jobPlatform,String companyId,String minExperience,String maxExperience,String recruiterId) throws Exception {
        JSONObject result = null;
        JSONObject o = new JSONObject();
        JSONObject p = new JSONObject();
        o.put("interface","RestAPI");
        o.put("method", "AddJobs");
        p.put("jobName",mapObject(jobName));
        p.put("description",mapObject(description));
        p.put("datePublished",mapObject(datePublished));
        p.put("jobStartDate",mapObject(jobStartDate));
        p.put("noOfVaccancy",mapObject(noOfVaccancy));
        p.put("summary",mapObject(summary));
        p.put("jobPositionId",mapObject(jobPositionId));
        p.put("jobCategory",mapObject(jobCategory));
        p.put("jobPlatform",mapObject(jobPlatform));
        p.put("companyId",mapObject(companyId));
        p.put("minExperience",mapObject(minExperience));
        p.put("maxExperience",mapObject(maxExperience));
        p.put("recruiterId",mapObject(recruiterId));
        o.put("parameters", p);
        String s = o.toString();
        String r = load(s);
        result = new JSONObject(r);
        return result;
    }

    public JSONObject UpdateJobs(String jobId,String jobName,String description,String datePublished,String jobStartDate,String noOfVacancy,String summary,String jobPositionId,String jobCategory,String jobPlatform,String companyId,String minExperience,String maxExperience,String recruiterId) throws Exception {
        JSONObject result = null;
        JSONObject o = new JSONObject();
        JSONObject p = new JSONObject();
        o.put("interface","RestAPI");
        o.put("method", "UpdateJobs");
        p.put("jobId",mapObject(jobId));
        p.put("jobName",mapObject(jobName));
        p.put("description",mapObject(description));
        p.put("datePublished",mapObject(datePublished));
        p.put("jobStartDate",mapObject(jobStartDate));
        p.put("noOfVacancy",mapObject(noOfVacancy));
        p.put("summary",mapObject(summary));
        p.put("jobPositionId",mapObject(jobPositionId));
        p.put("jobCategory",mapObject(jobCategory));
        p.put("jobPlatform",mapObject(jobPlatform));
        p.put("companyId",mapObject(companyId));
        p.put("minExperience",mapObject(minExperience));
        p.put("maxExperience",mapObject(maxExperience));
        p.put("recruiterId",mapObject(recruiterId));
        o.put("parameters", p);
        String s = o.toString();
        String r = load(s);
        result = new JSONObject(r);
        return result;
    }

    public JSONObject DeleteJob(String jobId) throws Exception {
        JSONObject result = null;
        JSONObject o = new JSONObject();
        JSONObject p = new JSONObject();
        o.put("interface","RestAPI");
        o.put("method", "DeleteJob");
        p.put("jobId",mapObject(jobId));
        o.put("parameters", p);
        String s = o.toString();
        String r = load(s);
        result = new JSONObject(r);
        return result;
    }

    public JSONObject GetAllJobs() throws Exception {
        JSONObject result = null;
        JSONObject o = new JSONObject();
        JSONObject p = new JSONObject();
        o.put("interface","RestAPI");
        o.put("method", "GetAllJobs");
        o.put("parameters", p);
        String s = o.toString();
        String r = load(s);
        result = new JSONObject(r);
        return result;
    }

    public JSONObject GetJobByCompanyId(String companyId) throws Exception {
        JSONObject result = null;
        JSONObject o = new JSONObject();
        JSONObject p = new JSONObject();
        o.put("interface","RestAPI");
        o.put("method", "GetJobByCompanyId");
        p.put("companyId",mapObject(companyId));
        o.put("parameters", p);
        String s = o.toString();
        String r = load(s);
        result = new JSONObject(r);
        return result;
    }

    public JSONObject GetJobByPositionId(String jobPositionId) throws Exception {
        JSONObject result = null;
        JSONObject o = new JSONObject();
        JSONObject p = new JSONObject();
        o.put("interface","RestAPI");
        o.put("method", "GetJobByPositionId");
        p.put("jobPositionId",mapObject(jobPositionId));
        o.put("parameters", p);
        String s = o.toString();
        String r = load(s);
        result = new JSONObject(r);
        return result;
    }

    public JSONObject AddJobDetails(String jobId,String sscPercentage,String hscPercentage,String graduationPercentage,String postGraduationPercentage,String specialization) throws Exception {
        JSONObject result = null;
        JSONObject o = new JSONObject();
        JSONObject p = new JSONObject();
        o.put("interface","RestAPI");
        o.put("method", "AddJobDetails");
        p.put("jobId",mapObject(jobId));
        p.put("sscPercentage",mapObject(sscPercentage));
        p.put("hscPercentage",mapObject(hscPercentage));
        p.put("graduationPercentage",mapObject(graduationPercentage));
        p.put("postGraduationPercentage",mapObject(postGraduationPercentage));
        p.put("specialization",mapObject(specialization));
        o.put("parameters", p);
        String s = o.toString();
        String r = load(s);
        result = new JSONObject(r);
        return result;
    }

    public JSONObject GetJobDetails(String jobId) throws Exception {
        JSONObject result = null;
        JSONObject o = new JSONObject();
        JSONObject p = new JSONObject();
        o.put("interface","RestAPI");
        o.put("method", "GetJobDetails");
        p.put("jobId",mapObject(jobId));
        o.put("parameters", p);
        String s = o.toString();
        String r = load(s);
        result = new JSONObject(r);
        return result;
    }

    public JSONObject UpdateJobDetails(String jobId,String sscPercentage,String hscPercentage,String graduationPercentage,String postGraduationPercentage,String specialization) throws Exception {
        JSONObject result = null;
        JSONObject o = new JSONObject();
        JSONObject p = new JSONObject();
        o.put("interface","RestAPI");
        o.put("method", "UpdateJobDetails");
        p.put("jobId",mapObject(jobId));
        p.put("sscPercentage",mapObject(sscPercentage));
        p.put("hscPercentage",mapObject(hscPercentage));
        p.put("graduationPercentage",mapObject(graduationPercentage));
        p.put("postGraduationPercentage",mapObject(postGraduationPercentage));
        p.put("specialization",mapObject(specialization));
        o.put("parameters", p);
        String s = o.toString();
        String r = load(s);
        result = new JSONObject(r);
        return result;
    }

    public JSONObject AddJobSkillsRequirement(String jobId,ArrayList<String> skillsArray) throws Exception {
        JSONObject result = null;
        JSONObject o = new JSONObject();
        JSONObject p = new JSONObject();
        o.put("interface","RestAPI");
        o.put("method", "AddJobSkillsRequirement");
        p.put("jobId",mapObject(jobId));
        p.put("skillsArray",mapObject(skillsArray));
        o.put("parameters", p);
        String s = o.toString();
        String r = load(s);
        result = new JSONObject(r);
        return result;
    }

    public JSONObject GetJobSkillsRequirementSkills(String jobId) throws Exception {
        JSONObject result = null;
        JSONObject o = new JSONObject();
        JSONObject p = new JSONObject();
        o.put("interface","RestAPI");
        o.put("method", "GetJobSkillsRequirementSkills");
        p.put("jobId",mapObject(jobId));
        o.put("parameters", p);
        String s = o.toString();
        String r = load(s);
        result = new JSONObject(r);
        return result;
    }

    public JSONObject GetJobSkillsRequirementBySkill(String jobId,ArrayList<String> skillsArray) throws Exception {
        JSONObject result = null;
        JSONObject o = new JSONObject();
        JSONObject p = new JSONObject();
        o.put("interface","RestAPI");
        o.put("method", "GetJobSkillsRequirementBySkill");
        p.put("jobId",mapObject(jobId));
        p.put("skillsArray",mapObject(skillsArray));
        o.put("parameters", p);
        String s = o.toString();
        String r = load(s);
        result = new JSONObject(r);
        return result;
    }

    public JSONObject ViewAllApplicants(String status) throws Exception {
        JSONObject result = null;
        JSONObject o = new JSONObject();
        JSONObject p = new JSONObject();
        o.put("interface","RestAPI");
        o.put("method", "ViewAllApplicants");
        p.put("status",mapObject(status));
        o.put("parameters", p);
        String s = o.toString();
        String r = load(s);
        result = new JSONObject(r);
        return result;
    }

    public JSONObject ViewFilteredApplicants(String filterType,String filterValue,String status) throws Exception {
        JSONObject result = null;
        JSONObject o = new JSONObject();
        JSONObject p = new JSONObject();
        o.put("interface","RestAPI");
        o.put("method", "ViewFilteredApplicants");
        p.put("filterType",mapObject(filterType));
        p.put("filterValue",mapObject(filterValue));
        p.put("status",mapObject(status));
        o.put("parameters", p);
        String s = o.toString();
        String r = load(s);
        result = new JSONObject(r);
        return result;
    }

    public JSONObject ChangeUserApplicantStatus(String applicationId,String status) throws Exception {
        JSONObject result = null;
        JSONObject o = new JSONObject();
        JSONObject p = new JSONObject();
        o.put("interface","RestAPI");
        o.put("method", "ChangeUserApplicantStatus");
        p.put("applicationId",mapObject(applicationId));
        p.put("status",mapObject(status));
        o.put("parameters", p);
        String s = o.toString();
        String r = load(s);
        result = new JSONObject(r);
        return result;
    }

    public JSONObject AddChats(String userId,String recruiterId,String message,String sentBy,String dateTime) throws Exception {
        JSONObject result = null;
        JSONObject o = new JSONObject();
        JSONObject p = new JSONObject();
        o.put("interface","RestAPI");
        o.put("method", "AddChats");
        p.put("userId",mapObject(userId));
        p.put("recruiterId",mapObject(recruiterId));
        p.put("message",mapObject(message));
        p.put("sentBy",mapObject(sentBy));
        p.put("dateTime",mapObject(dateTime));
        o.put("parameters", p);
        String s = o.toString();
        String r = load(s);
        result = new JSONObject(r);
        return result;
    }

    public JSONObject GetChatList(String userId,String recruiterId) throws Exception {
        JSONObject result = null;
        JSONObject o = new JSONObject();
        JSONObject p = new JSONObject();
        o.put("interface","RestAPI");
        o.put("method", "GetChatList");
        p.put("userId",mapObject(userId));
        p.put("recruiterId",mapObject(recruiterId));
        o.put("parameters", p);
        String s = o.toString();
        String r = load(s);
        result = new JSONObject(r);
        return result;
    }

    public JSONObject GetUserNotification(String userId) throws Exception {
        JSONObject result = null;
        JSONObject o = new JSONObject();
        JSONObject p = new JSONObject();
        o.put("interface","RestAPI");
        o.put("method", "GetUserNotification");
        p.put("userId",mapObject(userId));
        o.put("parameters", p);
        String s = o.toString();
        String r = load(s);
        result = new JSONObject(r);
        return result;
    }

    public JSONObject GetRecruiterNotification(String recruiterId) throws Exception {
        JSONObject result = null;
        JSONObject o = new JSONObject();
        JSONObject p = new JSONObject();
        o.put("interface","RestAPI");
        o.put("method", "GetRecruiterNotification");
        p.put("recruiterId",mapObject(recruiterId));
        o.put("parameters", p);
        String s = o.toString();
        String r = load(s);
        result = new JSONObject(r);
        return result;
    }

    public JSONObject AddNotification(String title,String message,String type,String userId) throws Exception {
        JSONObject result = null;
        JSONObject o = new JSONObject();
        JSONObject p = new JSONObject();
        o.put("interface","RestAPI");
        o.put("method", "AddNotification");
        p.put("title",mapObject(title));
        p.put("message",mapObject(message));
        p.put("type",mapObject(type));
        p.put("userId",mapObject(userId));
        o.put("parameters", p);
        String s = o.toString();
        String r = load(s);
        result = new JSONObject(r);
        return result;
    }

}


