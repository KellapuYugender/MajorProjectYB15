package com.example.jobportal.activity.recruiter;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.collection.ArraySet;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Dialog;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.util.Pair;
import android.view.MenuItem;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.jobportal.R;
import com.example.jobportal.adapter.CompanyListAdapter;
import com.example.jobportal.model.Company;
import com.example.jobportal.utility.Constants;
import com.example.jobportal.utility.DateUtils;
import com.example.jobportal.utility.DialogUtils;
import com.example.jobportal.utility.Helper;
import com.example.jobportal.utility.webServices.JSONParse;
import com.example.jobportal.utility.webServices.RestAPI;
import com.example.jobportal.utility.webServices.Utility;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class ManageCompanyActivity extends AppCompatActivity implements View.OnClickListener {

    private RelativeLayout rlManageCompanyLayout;
    private TextView tvNoData;
    private RecyclerView rvCompany;
    private FloatingActionButton fabAddCompany;

    private Context context;
    private RestAPI restAPI;
    private JSONParse jsonParse;
    private Company entity;
    private List<Company> companyList;
    private CompanyListAdapter companyListAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_company);

        initToolbar();
        initUI();
        initObj();

    }

    private void initToolbar() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        TextView tvTitle = toolbar.findViewById(R.id.tvTitle);
        tvTitle.setText(Constants.COMPANY);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null)
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);

    }

    private void initUI() {
        rlManageCompanyLayout = findViewById(R.id.rlManageCompanyLayout);
        fabAddCompany = findViewById(R.id.fabAddCompany);
        tvNoData = findViewById(R.id.tvNoData);
        rvCompany = findViewById(R.id.rvCompany);

        fabAddCompany.setOnClickListener(this);

        tvNoData.setVisibility(View.VISIBLE);
        rvCompany.setVisibility(View.GONE);
    }

    private void initObj() {
        context = this;
        restAPI = new RestAPI();
        jsonParse = new JSONParse();
        entity = new Company();
        companyList = new ArrayList<>();
    }

    private void loadItems() {
        new AsyncGetCompany().execute();
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (companyListAdapter != null) {
            companyList.clear();
            entity = new Company();
            rvCompany.setAdapter(null);
            loadItems();
        } else {
            loadItems();
        }
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.fabAddCompany) {
            Helper.goTo(this, AddCompanyActivity.class);
        }
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void setUpRecyclerView() {
        companyListAdapter = new CompanyListAdapter(this,
                companyList);
        rvCompany.setAdapter(companyListAdapter);
        rvCompany.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL,
                false));
        companyListAdapter.notifyDataSetChanged();
    }

    private void saveDataToEntityAndSetupRecyclerView(JSONObject json) {
        try {
            JSONArray jsonArray = json.getJSONArray("Data");
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObj = jsonArray.getJSONObject(i);
                entity.setCompanyId(jsonObj.getString("data0"));
                entity.setCompanyName(jsonObj.getString("data1"));
                entity.setCompanyDescription(jsonObj.getString("data2"));
                companyList.add(entity);
                entity = new Company();
            }
            setUpRecyclerView();
        } catch (Exception exception) {
            exception.printStackTrace();
            Log.e(Constants.COMPANY, exception.getMessage());
        }
    }

    private class AsyncGetCompany extends AsyncTask<String, String, String> {

        private Dialog dialog;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            dialog = DialogUtils.showLoadingDialog(context, Constants.PLEASE_WAIT);
        }


        @Override
        protected String doInBackground(String... strings) {
            String a;
            try {
                JSONObject json = restAPI.GetAllCompany();
                a = jsonParse.parse(json);
            } catch (Exception e) {
                a = e.getMessage();
            }
            return a;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            dialog.dismiss();
            try {
                if (Utility.checkConnection(s)) {
                    Pair<String, String> pair = Utility.GetErrorMessage(s);
                    Utility.ShowAlertDialog(context, pair.first, pair.second, false);
                } else {
                    //main
                    JSONObject json = new JSONObject(s);

                    //string value
                    String jsonString = json.getString("status");

                    if (jsonString.compareToIgnoreCase("no") == 0) {
                        Helper.makeSnackBar(rlManageCompanyLayout, "No Data found");

                    } else if (jsonString.compareToIgnoreCase("ok") == 0) {
                        tvNoData.setVisibility(View.GONE);
                        rvCompany.setVisibility(View.VISIBLE);
                        saveDataToEntityAndSetupRecyclerView(json);
                    } else {
                        Helper.makeSnackBar(rlManageCompanyLayout, "Something Went Wrong");
                    }

                }
            } catch (Exception e) {
                Helper.makeSnackBar(rlManageCompanyLayout, "Something Went Wrong");
            }

        }
    }

}