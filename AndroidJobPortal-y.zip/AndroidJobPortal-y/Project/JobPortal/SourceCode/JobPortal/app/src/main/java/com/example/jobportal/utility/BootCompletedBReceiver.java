package com.example.jobportal.utility;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class BootCompletedBReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent.getAction() != null && intent.getAction().equalsIgnoreCase(Intent.ACTION_BOOT_COMPLETED)) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.stopService(new Intent(context, MyNotificationService.class));
                context.startForegroundService(new Intent(context, MyNotificationService.class));
            } else {
                context.stopService(new Intent(context, MyNotificationService.class));
                context.startService(new Intent(context, MyNotificationService.class));
            }
        }
    }
}
