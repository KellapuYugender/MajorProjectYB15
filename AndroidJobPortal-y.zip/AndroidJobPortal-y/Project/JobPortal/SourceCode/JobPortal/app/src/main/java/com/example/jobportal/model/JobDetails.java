package com.example.jobportal.model;

import java.io.Serializable;

public class JobDetails implements Serializable {

    private String jobDetailsId,jobId, sscPercentage, hscPercentage, graduationPercentage,
            postGraduationPercentage, specialization;

    public String getJobDetailsId() {
        return jobDetailsId;
    }

    public void setJobDetailsId(String jobDetailsId) {
        this.jobDetailsId = jobDetailsId;
    }

    public String getJobId() {
        return jobId;
    }

    public void setJobId(String jobId) {
        this.jobId = jobId;
    }

    public String getSscPercentage() {
        return sscPercentage;
    }

    public void setSscPercentage(String sscPercentage) {
        this.sscPercentage = sscPercentage;
    }

    public String getHscPercentage() {
        return hscPercentage;
    }

    public void setHscPercentage(String hscPercentage) {
        this.hscPercentage = hscPercentage;
    }

    public String getGraduationPercentage() {
        return graduationPercentage;
    }

    public void setGraduationPercentage(String graduationPercentage) {
        this.graduationPercentage = graduationPercentage;
    }

    public String getPostGraduationPercentage() {
        return postGraduationPercentage;
    }

    public void setPostGraduationPercentage(String postGraduationPercentage) {
        this.postGraduationPercentage = postGraduationPercentage;
    }

    public String getSpecialization() {
        return specialization;
    }

    public void setSpecialization(String specialization) {
        this.specialization = specialization;
    }
}
