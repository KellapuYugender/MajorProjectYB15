package com.example.jobportal.model;

import java.io.Serializable;

public class UserApplicant implements Serializable {

    private String applicantId, userId, jobId, dateOfApplication, status,
            userName, sscPercentage, hscPercentage, graduationPercentage, postGraduationPercentage, specialization,
            workExperience,cv;

    public String getApplicantId() {
        return applicantId;
    }

    public void setApplicantId(String applicantId) {
        this.applicantId = applicantId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getJobId() {
        return jobId;
    }

    public void setJobId(String jobId) {
        this.jobId = jobId;
    }

    public String getDateOfApplication() {
        return dateOfApplication;
    }

    public void setDateOfApplication(String dateOfApplication) {
        this.dateOfApplication = dateOfApplication;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getSscPercentage() {
        return sscPercentage;
    }

    public void setSscPercentage(String sscPercentage) {
        this.sscPercentage = sscPercentage;
    }

    public String getHscPercentage() {
        return hscPercentage;
    }

    public void setHscPercentage(String hscPercentage) {
        this.hscPercentage = hscPercentage;
    }

    public String getGraduationPercentage() {
        return graduationPercentage;
    }

    public void setGraduationPercentage(String graduationPercentage) {
        this.graduationPercentage = graduationPercentage;
    }

    public String getPostGraduationPercentage() {
        return postGraduationPercentage;
    }

    public void setPostGraduationPercentage(String postGraduationPercentage) {
        this.postGraduationPercentage = postGraduationPercentage;
    }

    public String getSpecialization() {
        return specialization;
    }

    public void setSpecialization(String specialization) {
        this.specialization = specialization;
    }

    public String getWorkExperience() {
        return workExperience;
    }

    public void setWorkExperience(String workExperience) {
        this.workExperience = workExperience;
    }

    public String getCv() {
        return cv;
    }

    public void setCv(String cv) {
        this.cv = cv;
    }
}
