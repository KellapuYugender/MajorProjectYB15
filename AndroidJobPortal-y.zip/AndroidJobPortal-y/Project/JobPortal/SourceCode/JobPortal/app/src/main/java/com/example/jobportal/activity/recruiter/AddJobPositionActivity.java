package com.example.jobportal.activity.recruiter;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.app.Dialog;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Pair;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.jobportal.R;
import com.example.jobportal.model.Company;
import com.example.jobportal.model.JobsPosition;
import com.example.jobportal.utility.Constants;
import com.example.jobportal.utility.DialogUtils;
import com.example.jobportal.utility.Helper;
import com.example.jobportal.utility.webServices.JSONParse;
import com.example.jobportal.utility.webServices.RestAPI;
import com.example.jobportal.utility.webServices.Utility;

import org.json.JSONObject;

import java.io.Serializable;

public class AddJobPositionActivity extends AppCompatActivity implements View.OnClickListener {

    private RelativeLayout rlAddJobPositionLayout;
    private EditText etName, etDescription;
    private Button btnRegister;

    private RestAPI restAPI;
    private JSONParse jsonParse;
    private Context context;
    private JobsPosition entity;

    private Serializable serializableBundle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_job_position);

        initToolbar();
        initUI();
        initObj();
        loadIntentData();
    }

    private void initToolbar() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        TextView tvTitle = toolbar.findViewById(R.id.tvTitle);
        tvTitle.setText(Constants.JOB_POSITION);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null)
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

    private void initUI() {
        rlAddJobPositionLayout = findViewById(R.id.rlAddJobPositionLayout);
        etName = findViewById(R.id.etName);
        etDescription = findViewById(R.id.etDescription);
        btnRegister = findViewById(R.id.btnRegister);

        btnRegister.setOnClickListener(this);

    }

    private void initObj() {
        context = this;
        entity = new JobsPosition();
        restAPI = new RestAPI();
        jsonParse = new JSONParse();

        serializableBundle = loadIntentData();
    }

    private Serializable loadIntentData() {
        Serializable bundle = getIntent().getSerializableExtra(Constants.JOB_POSITION);
        if (bundle != null) {
            entity = (JobsPosition) bundle;
            setEntityDataToText();
        }
        return bundle;
    }

    @Override
    public void onClick(View view) {
        if (view.getId() == R.id.btnRegister) {
            onClickBtnRegister();
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void onClickBtnRegister() {
        if (isValidate()) {
            String name = etName.getText().toString();
            String description = etDescription.getText().toString();

            try {
                if (serializableBundle == null) {
                    new AsyncRegisterJobPosition().execute(
                            name, description
                    );
                } else {
                    String jobPositionId = String.valueOf(entity.getJobPositionId());
                    if (jobPositionId != null) {
                        new AsyncUpdateJobPosition().execute(
                                jobPositionId, name, description
                        );
                    }
                }
            } catch (Exception exception) {
                exception.printStackTrace();
            }
        }
    }

    private boolean isValidate() {
        String required = "required";
        String error = "";

        if (etName.getText().toString().trim().equals("")) {
            etName.setError(required);
            etName.requestFocus();
            error = required;
        }
        return error.equals("");
    }

    private void setEntityDataToText() {
        etName.setText(entity.getPositionName());
        etDescription.setText(entity.getDescription());
        btnRegister.setText(Constants.UPDATE);
    }

    private class AsyncRegisterJobPosition extends AsyncTask<String, String, String> {

        private Dialog dialog;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            dialog = DialogUtils.showLoadingDialog(context, "Please Wait");

        }

        @Override
        protected String doInBackground(String... strings) {
            String a;
            try {
                JSONObject json = restAPI.AddJobPositions(strings[0], strings[1]);
                a = jsonParse.parse(json);
            } catch (Exception e) {
                a = e.getMessage();
            }
            return a;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            DialogUtils.dismissLoadingDialog(dialog);
            if (Utility.checkConnection(s)) {
                Pair<String, String> pair = Utility.GetErrorMessage(s);
                Utility.ShowAlertDialog(context, pair.first, pair.second, false);
            } else {
                try {
                    JSONObject jsonObject = new JSONObject(s);
                    String statusValue = jsonObject.getString("status");

                    if (statusValue.compareTo("true") == 0) {
                        DialogUtils.openAlertDialog(context,
                                "Registered",
                                "OK",
                                false, true).show();

                    } else {
                        Helper.makeSnackBar(rlAddJobPositionLayout, Constants.SOMETHING_WENT_WRONG);
                    }
                } catch (Exception e) {
                    Helper.makeSnackBar(rlAddJobPositionLayout, Constants.SOMETHING_WENT_WRONG);
                    e.printStackTrace();
                }
            }
        }
    }

    private class AsyncUpdateJobPosition extends AsyncTask<String, String, String> {

        private Dialog dialog;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            dialog = DialogUtils.showLoadingDialog(context, "Please Wait");

        }

        @Override
        protected String doInBackground(String... strings) {
            String a;
            try {
                JSONObject json = restAPI.UpdateJobPositions(strings[0],
                        strings[1], strings[2]);
                a = jsonParse.parse(json);
            } catch (Exception e) {
                a = e.getMessage();
            }
            return a;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            DialogUtils.dismissLoadingDialog(dialog);
            if (Utility.checkConnection(s)) {
                Pair<String, String> pair = Utility.GetErrorMessage(s);
                Utility.ShowAlertDialog(context, pair.first, pair.second, false);
            } else {
                try {
                    JSONObject jsonObject = new JSONObject(s);
                    String statusValue = jsonObject.getString("status");

                    if (statusValue.compareTo("true") == 0) {
                        DialogUtils.openAlertDialog(context,
                                "Details Updated",
                                "OK",
                                false, true).show();

                    } else {
                        Helper.makeSnackBar(rlAddJobPositionLayout, Constants.SOMETHING_WENT_WRONG);
                    }
                } catch (Exception e) {
                    Helper.makeSnackBar(rlAddJobPositionLayout, Constants.SOMETHING_WENT_WRONG);
                    e.printStackTrace();
                }
            }
        }
    }
}