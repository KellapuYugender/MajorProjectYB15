package com.example.jobportal.utility;

import android.content.Context;
import android.content.SharedPreferences;

public class UserPref {

    public static String getUser(Context con) {

        String userID = "";
        boolean loginStatus = getLoginStatus(con);
        if (loginStatus) {
            userID = sharedPreferences(con).getString(Constants.LOGGED_IN_ID, "");
            if (!userID.isEmpty()) {
                return userID;
            } else {
                UserPref.deleteAll(con);
                DialogUtils.forceLogout(con);
            }
        } else {
            UserPref.deleteAll(con);
            DialogUtils.forceLogout(con);
        }

        return userID;
    }

    public static String getUserType(Context con) {
        return sharedPreferences(con).getString(Constants.USER_TYPE, "");
    }

    public static boolean getLoginStatus(Context con) {
        return sharedPreferences(con).getBoolean(Constants.BOOL_IS_LOGGED_IN, false);
    }

    public static boolean getUserProfileStatus(Context con) {
        return sharedPreferences(con).getBoolean(Constants.BOOL_PROFILE_COMPLETION_STATUS,
                false);
    }

    public static String getStringValue(Context con, String key) {
        return sharedPreferences(con).getString(key, "");
    }

    public static void setValue(Context con, String key, String value) {
        SharedPreferences.Editor editor = sharedPreferences(con).edit();
        editor.putString(key, value);
        editor.apply();
    }

    public static void setUserId(Context con, String value) {
        SharedPreferences.Editor editor = sharedPreferences(con).edit();
        editor.putString(Constants.LOGGED_IN_ID, value);
        editor.apply();
    }

    public static void setUserType(Context con, String value) {
        SharedPreferences.Editor editor = sharedPreferences(con).edit();
        editor.putString(Constants.USER_TYPE, value);
        editor.apply();
    }

    public static void setLoginStatus(Context con, boolean value) {
        SharedPreferences.Editor editor = sharedPreferences(con).edit();
        editor.putBoolean(Constants.BOOL_IS_LOGGED_IN, value);
        editor.apply();
    }

    public static void setProfileStatus(Context con, boolean value) {
        SharedPreferences.Editor editor = sharedPreferences(con).edit();
        editor.putBoolean(Constants.BOOL_PROFILE_COMPLETION_STATUS, value);
        editor.apply();
    }

    public static SharedPreferences sharedPreferences(Context con) {
        return con.getSharedPreferences(Constants.SHARED_PREF, Context.MODE_PRIVATE);
    }


    public static void deleteAll(Context context) {
        SharedPreferences sprefLogin = context.getSharedPreferences(Constants.SHARED_PREF,
                Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sprefLogin.edit();
        editor.clear();
        editor.apply();
    }
}