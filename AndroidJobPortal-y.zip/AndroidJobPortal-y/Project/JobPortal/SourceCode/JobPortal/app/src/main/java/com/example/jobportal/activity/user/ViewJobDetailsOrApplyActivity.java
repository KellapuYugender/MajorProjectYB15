package com.example.jobportal.activity.user;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.app.Dialog;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Pair;
import android.view.MenuItem;
import android.view.View;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.jobportal.R;
import com.example.jobportal.model.Company;
import com.example.jobportal.model.JobDetails;
import com.example.jobportal.model.Jobs;
import com.example.jobportal.model.JobsPosition;
import com.example.jobportal.utility.Constants;
import com.example.jobportal.utility.DateUtils;
import com.example.jobportal.utility.DialogUtils;
import com.example.jobportal.utility.Helper;
import com.example.jobportal.utility.UserPref;
import com.example.jobportal.utility.webServices.JSONParse;
import com.example.jobportal.utility.webServices.RestAPI;
import com.example.jobportal.utility.webServices.Utility;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.Serializable;
import java.util.ArrayList;

public class ViewJobDetailsOrApplyActivity extends AppCompatActivity implements View.OnClickListener {

    private RelativeLayout rlAddJobsActivity;
    private EditText etJobName, etJobStartDate, etJobSummary,
            etJobDescription, etJobNoOfVacancy,
            etJobCategory, etJobPlatform, etMinExperience, etMaximumExperience;
    private AutoCompleteTextView acJobCompany, acJobPosition;
    private EditText etSSCPercentage, etHscPercentage, etGraduationPercentage,
            etPostGraduationPercentage, etSpecialization, etSkills;
    private Button btnApply;

    private RestAPI restAPI;
    private JSONParse jsonParse;
    private Context context;
    private Jobs entity;
    private JobDetails jobDetails;
    private Company company;
    private JobsPosition jobsPosition;

    private String jobId = "";
    private Serializable serializableBundle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_job_details_or_apply);

        initToolbar();
        initUI();
        initObj();
        loadIntentData();
    }

    private void initToolbar() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        TextView tvTitle = toolbar.findViewById(R.id.tvTitle);
        tvTitle.setText(Constants.JOB_DETAILS);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null)
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

    private void initUI() {
        rlAddJobsActivity = findViewById(R.id.rlAddJobsActivity);
        acJobCompany = findViewById(R.id.acJobCompany);
        etJobName = findViewById(R.id.etJobName);
        etJobStartDate = findViewById(R.id.etJobStartDate);
        etJobDescription = findViewById(R.id.etJobDescription);
        etJobSummary = findViewById(R.id.etJobSummary);
        acJobPosition = findViewById(R.id.acJobPosition);
        etJobNoOfVacancy = findViewById(R.id.etJobNoOfVacancy);
        etJobCategory = findViewById(R.id.etJobCategory);
        etJobPlatform = findViewById(R.id.etJobPlatform);
        etMinExperience = findViewById(R.id.etMinExperience);
        etMaximumExperience = findViewById(R.id.etMaximumExperience);

        etSSCPercentage = findViewById(R.id.etSSCPercentage);
        etHscPercentage = findViewById(R.id.etHscPercentage);
        etGraduationPercentage = findViewById(R.id.etGraduationPercentage);
        etPostGraduationPercentage = findViewById(R.id.etPostGraduationPercentage);
        etSpecialization = findViewById(R.id.etSpecialization);
        etSkills = findViewById(R.id.etSkills);

        btnApply = findViewById(R.id.btnApply);

        Helper.bulletPointsEditTextListener(etSkills);
        btnApply.setOnClickListener(this);
    }

    private void initObj() {
        context = this;
        entity = new Jobs();
        jobDetails = new JobDetails();
        company = new Company();
        jobsPosition = new JobsPosition();
        restAPI = new RestAPI();
        jsonParse = new JSONParse();
        serializableBundle = loadIntentData();

    }

    private Serializable loadIntentData() {
        Serializable bundle = getIntent().getSerializableExtra(Constants.JOBS);
        if (bundle != null) {
            entity = (Jobs) bundle;
            setEntityDataToText();
        }
        return bundle;
    }

    @Override
    public void onClick(View view) {
        if (view.getId() == R.id.btnApply) {
            onBtnClickApply();
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void onBtnClickApply() {
        String[] currentDateTime = DateUtils.currentDateTime();
        new AsyncApplyForJob().execute(UserPref.getUser(this),
                entity.getJobId(), currentDateTime[0]);
    }

    private void setEntityDataToText() {
        try {
            jobId = String.valueOf(entity.getJobId());
            etJobName.setText(entity.getJobName());
            etJobDescription.setText(entity.getDescription());
            etJobStartDate.setText(entity.getJobStartDate());
            etJobNoOfVacancy.setText(entity.getNoOfVacancy());
            etJobSummary.setText(entity.getSummary());
            acJobPosition.setText(String.valueOf(entity.getJobPositionName()));
            etJobCategory.setText(entity.getJobCategory());
            etJobPlatform.setText(entity.getJobPlatform());
            etMinExperience.setText(entity.getMinExperience());
            etMaximumExperience.setText(entity.getMaxExperience());
            acJobCompany.setText(entity.getCompanyName());
            new AsyncGetJobDetails().execute();
            new AsyncGetSkills().execute();
        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    private void setSkillsDataToText(JSONObject json) {
        try {
            etSkills.setText("➼ ");
            JSONArray jsonArray = json.getJSONArray("Data");
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObj = jsonArray.getJSONObject(i);
                String skillName = jsonObj.getString("data2");
                etSkills.setText(etSkills.getText().toString().trim() + skillName + "\n");
            }

        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    private void setJobDetailsDataToText(JSONObject json) {
        try {
            JSONArray jsonArray = json.getJSONArray("Data");
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObj = jsonArray.getJSONObject(i);
                etSSCPercentage.setText(jsonObj.getString("data2"));
                etHscPercentage.setText(jsonObj.getString("data3"));
                etGraduationPercentage.setText(jsonObj.getString("data4"));
                etPostGraduationPercentage.setText(jsonObj.getString("data5"));
                etSpecialization.setText(jsonObj.getString("data6"));
            }
        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    private void onSuccessPostApplication() {
        btnApply.setText("Applied");
        btnApply.setEnabled(false);
        DialogUtils.openAlertDialog(context,
                "Applied For Job Successful\n" +
                        "Wait For the recruiter to review your application",
                "View Application History", false,
                false);
        String title = "Job";
        String message = "Applied for job " + entity.getJobName();
        String type = Constants.RECRUITER;
        String recruiterId = entity.getRecruiterId();
        new AsyncAddNotification().execute(title, message, type, recruiterId);
        Helper.goTo(context, ApplicationTabsActivity.class);
        finish();
    }

    private class AsyncGetJobDetails extends AsyncTask<String, String, String> {

        private Dialog dialog;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            dialog = DialogUtils.showLoadingDialog(context, Constants.PLEASE_WAIT);
        }


        @Override
        protected String doInBackground(String... strings) {
            String a;
            try {
                JSONObject json = restAPI.GetJobDetails(jobId);
                a = jsonParse.parse(json);
            } catch (Exception e) {
                a = e.getMessage();
            }
            return a;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            dialog.dismiss();
            try {
                if (Utility.checkConnection(s)) {
                    Pair<String, String> pair = Utility.GetErrorMessage(s);
                    Utility.ShowAlertDialog(context, pair.first, pair.second, false);
                } else {
                    //main
                    JSONObject json = new JSONObject(s);

                    //string value
                    String jsonString = json.getString("status");

                    if (jsonString.compareToIgnoreCase("no") == 0) {
                    } else if (jsonString.compareToIgnoreCase("ok") == 0) {
                        setJobDetailsDataToText(json);
                    }

                }
            } catch (Exception e) {
                e.printStackTrace();
            }

        }
    }

    private class AsyncGetSkills extends AsyncTask<String, String, String> {

        private Dialog dialog;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            dialog = DialogUtils.showLoadingDialog(context, Constants.PLEASE_WAIT);
        }


        @Override
        protected String doInBackground(String... strings) {
            String a;
            try {
                JSONObject json = restAPI.GetJobSkillsRequirementSkills(jobId);
                a = jsonParse.parse(json);
            } catch (Exception e) {
                a = e.getMessage();
            }
            return a;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            dialog.dismiss();
            try {
                if (Utility.checkConnection(s)) {
                    Pair<String, String> pair = Utility.GetErrorMessage(s);
                    Utility.ShowAlertDialog(context, pair.first, pair.second, false);
                } else {
                    //main
                    JSONObject json = new JSONObject(s);

                    //string value
                    String jsonString = json.getString("status");

                    if (jsonString.compareToIgnoreCase("no") == 0) {
                    } else if (jsonString.compareToIgnoreCase("ok") == 0) {
                        setSkillsDataToText(json);
                    }

                }
            } catch (Exception e) {
                e.printStackTrace();
            }

        }
    }

    private class AsyncApplyForJob extends AsyncTask<String, String, String> {
        private Dialog dialog;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            dialog = DialogUtils.showLoadingDialog(context, Constants.PLEASE_WAIT);
        }

        @Override
        protected String doInBackground(String... strings) {
            String a;
            try {
                JSONObject json = restAPI.AddUserApplicantion(strings[0],
                        strings[1], strings[2]);
                a = jsonParse.parse(json);
            } catch (Exception e) {
                a = e.getMessage();
            }
            return a;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            DialogUtils.dismissLoadingDialog(dialog);
            if (Utility.checkConnection(s)) {
                Pair<String, String> pair = Utility.GetErrorMessage(s);
                Utility.ShowAlertDialog(context, pair.first, pair.second, false);
            } else {
                try {
                    JSONObject jsonObject = new JSONObject(s);
                    String statusValue = jsonObject.getString("status");
                    if (statusValue.compareToIgnoreCase("true") == 0) {
                        onSuccessPostApplication();
                    } else if (statusValue.compareToIgnoreCase("already") == 0) {
                        Helper.makeSnackBar(rlAddJobsActivity, "Already applied for this job");
                        btnApply.setText("Applied");
                        btnApply.setEnabled(false);
                    } else {
                        Helper.makeSnackBar(rlAddJobsActivity, Constants.SOMETHING_WENT_WRONG);
                    }
                } catch (Exception e) {
                    Helper.makeSnackBar(rlAddJobsActivity, Constants.SOMETHING_WENT_WRONG);
                    e.printStackTrace();
                }
            }
        }

    }

    private class AsyncAddNotification extends AsyncTask<String, JSONObject, String> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(String... strings) {
            String ans;
            RestAPI restAPI = new RestAPI();
            try {
                JSONObject json = restAPI.AddNotification(strings[0], strings[1]
                        , strings[2], strings[3]);
                ans = jsonParse.parse(json);
            } catch (Exception e) {
                ans = e.getMessage();
            }
            return ans;
        }


        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            try {
                if (Utility.checkConnection(s)) {
                    Pair<String, String> pair = Utility.GetErrorMessage(s);
                    Utility.ShowAlertDialog(context, pair.first, pair.second, false);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

}