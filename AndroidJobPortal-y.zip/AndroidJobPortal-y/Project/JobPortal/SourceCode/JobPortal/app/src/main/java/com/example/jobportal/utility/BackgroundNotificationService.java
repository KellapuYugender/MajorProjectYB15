package com.example.jobportal.utility;

import android.Manifest;
import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.IntentSender;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationRequest;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.StrictMode;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.Log;
import android.util.Pair;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;

import com.airbnb.lottie.model.Marker;
import com.example.jobportal.R;
import com.example.jobportal.activity.recruiter.RecruiterDashboardActivity;
import com.example.jobportal.activity.user.DashboardActivity;
import com.example.jobportal.utility.webServices.JSONParse;
import com.example.jobportal.utility.webServices.RestAPI;
import com.example.jobportal.utility.webServices.Utility;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

public class BackgroundNotificationService extends Service {
    public static String CHANNEL_ID = "";
    public static final String CHANNEL_ID_1 = "channel1";
    String TAG = "RESPONSE:-";
    Handler hand = new Handler();
    Context mContext;
    private TimerTask timerTask;
    private Timer timer;

    public static void createNotificationChannel(@NonNull Context context, @NonNull String CHANNEL_ID) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "Channelname";
            String description = "Channel desription";
            int importance = NotificationManager.IMPORTANCE_LOW;
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, name, importance);
            channel.setDescription(description);
            NotificationManager notificationManager = context.getSystemService(NotificationManager.class);
            if (notificationManager != null) {
                notificationManager.createNotificationChannel(channel);
            } else {
                Log.d("NotificationLog", "NotificationManagerNull");
            }
        }
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        startServices();
        mContext = this;
        timerTask = new TimerTask() {
            @Override
            public void run() {
                hand.post(new TimerTask() {
                    @Override
                    public void run() {
                        if (!UserPref.getUser(mContext).isEmpty()) {
                            if (UserPref.getUserType(mContext).equalsIgnoreCase(Constants.TYPE_USER)) {
                                new getUserNotification().execute();
                            } else {
                                new getRecruiterNotification().execute();
                            }
                        }
                    }
                });
            }
        };
        timer = new Timer();
        timer.schedule(timerTask, 0, 2000);

    }

    private void startServices() {

        createNotificationChannel(getApplicationContext(), CHANNEL_ID);

        Notification notification = new NotificationCompat
                .Builder(getApplicationContext(), CHANNEL_ID)
                .setContentTitle(getString(R.string.app_name))
                .setContentText("TEST")
                .setAutoCancel(false)
                .build();

        startForeground(123, notification);

    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        super.onStartCommand(intent, flags, startId);
        return START_STICKY;
    }

    public void createNotificationChannel_new(@NonNull Context context, @NonNull String CHANNEL_ID) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "Notification";
            String description = "channeldescription";
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, name, importance);
            channel.setDescription(description);
            NotificationManager notificationManager = context.getSystemService(NotificationManager.class);
            if (notificationManager != null) {
                notificationManager.createNotificationChannel(channel);
            } else {
                Log.d("NotificationLog", "NotificationManagerNull");
            }
        }
    }

    public void showNotification(String title, String message, int randomValue) {
        StrictMode.VmPolicy.Builder sb = new StrictMode.VmPolicy.Builder();
        StrictMode.setVmPolicy(sb.build());
        sb.detectFileUriExposure();

        NotificationChannel notificationChannel1 = null;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            notificationChannel1 = new NotificationChannel(CHANNEL_ID_1, CHANNEL_ID_1,
                    NotificationManager.IMPORTANCE_HIGH);
            notificationChannel1.setDescription(message);

            NotificationManagerCompat notificationManagerCompat = NotificationManagerCompat.from(this);
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(notificationChannel1);

            Notification notification = new NotificationCompat.Builder(this, BackgroundNotificationService.CHANNEL_ID_1)
                    .setSmallIcon(R.drawable.logo_24px)
                    .setContentTitle(title)
                    .setContentText(message)
                    .build();
            notificationManagerCompat.notify(1, notification);
        }

    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        timer.cancel();
    }

    private class getUserNotification extends AsyncTask<String, JSONObject, String> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(String... strings) {
            String data = null;
            RestAPI restAPI = new RestAPI();
            try {
                JSONObject json = restAPI.GetUserNotification(strings[0]);
                JSONParse jp = new JSONParse();
                data = jp.parse(json);
                Log.d(TAG, data);
            } catch (Exception e) {
                Log.d(TAG, e.getMessage());
                data = e.getMessage();
            }
            return data;
        }


        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            Log.d(TAG, s);
            try {
                if (Utility.checkConnection(s)) {
                    Pair<String, String> pair = Utility.GetErrorMessage(s);
                    Utility.ShowAlertDialog(mContext, pair.first, pair.second, false);
                } else {
                    JSONObject json = new JSONObject(s);
                    String StatusValue = json.getString("status");
                    if (StatusValue.compareTo("ok") == 0) {
                        JSONArray jsonArray = json.getJSONArray("Data");
                        JSONObject jsonObj = jsonArray.getJSONObject(0);
                        String userId = jsonObj.getString("data0");
                        String Title = jsonObj.getString("data2");
                        String Message = jsonObj.getString("data5");
                        Random rand = new Random();
                        int randomValue = rand.nextInt(999);
                        if (UserPref.getUser(mContext).equalsIgnoreCase(userId)) {
                            showNotification(Title, Message, randomValue);
                        }
                    }
                }
            } catch (Exception e) {
                Log.d(TAG + "EXE", e.getMessage());
            }
        }
    }

    private class getRecruiterNotification extends AsyncTask<String, JSONObject, String> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(String... strings) {
            String data = null;
            RestAPI restAPI = new RestAPI();
            try {
                JSONObject json = restAPI.GetRecruiterNotification(strings[0]);
                JSONParse jp = new JSONParse();
                data = jp.parse(json);
                Log.d(TAG, data);
            } catch (Exception e) {
                Log.d(TAG, e.getMessage());
                data = e.getMessage();
            }
            return data;
        }


        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            Log.d(TAG, s);
            try {
                if (Utility.checkConnection(s)) {
                    Pair<String, String> pair = Utility.GetErrorMessage(s);
                    Utility.ShowAlertDialog(mContext, pair.first, pair.second, false);
                } else {
                    JSONObject json = new JSONObject(s);
                    String StatusValue = json.getString("status");
                    if (StatusValue.compareTo("ok") == 0) {

                        JSONArray jsonArray = json.getJSONArray("Data");
                        JSONObject jsonObj = jsonArray.getJSONObject(0);
                        String userId = jsonObj.getString("data1");
                        String Title = jsonObj.getString("data2");
                        String Message = jsonObj.getString("data4");
                        Random rand = new Random();
                        int randomValue = rand.nextInt(999);
                        if (UserPref.getUser(mContext).equalsIgnoreCase(userId)) {
                            showNotification(Title, Message, randomValue);
                        }
                    }
                }
            } catch (Exception e) {
                Log.d(TAG + "EXE", e.getMessage());
            }
        }
    }

}
