package com.example.jobportal.activity.user;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.collection.ArraySet;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.util.Pair;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.jobportal.R;
import com.example.jobportal.adapter.JobListAdapter;
import com.example.jobportal.adapter.SearchJobListAdapter;
import com.example.jobportal.model.JobDetails;
import com.example.jobportal.model.JobSkills;
import com.example.jobportal.model.Jobs;
import com.example.jobportal.model.UserApplicant;
import com.example.jobportal.utility.Constants;
import com.example.jobportal.utility.DialogUtils;
import com.example.jobportal.utility.Helper;
import com.example.jobportal.utility.webServices.JSONParse;
import com.example.jobportal.utility.webServices.RestAPI;
import com.example.jobportal.utility.webServices.Utility;
import com.google.android.material.textfield.MaterialAutoCompleteTextView;
import com.google.android.material.textfield.TextInputEditText;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class SearchJobActivity extends AppCompatActivity implements View.OnClickListener {

    private RelativeLayout rlSearchJobsLayout;
    private MaterialAutoCompleteTextView acSearch;
    private ImageButton ibSearch;
    private RecyclerView rvJobs;
    private TextView tvNoData;

    private String filterBy;

    private View alertFilter;
    private AlertDialog alertDialog;
    private AlertDialog.Builder alertBuilder;
    private TextView alertTvAllJobs,alertTvJobName,alertTvSkills, alertTvCompany, alertTvSSCPercent,
            alertTvHSCPercent, alertTvGraduatePercent, alertTvPostGraduatePercent,
            alertTvSpecialization, alertBtnCancel;

    private Context context;
    private RestAPI restAPI;
    private JSONParse jsonParse;

    private Jobs entity;
    private JobDetails jobDetailsEntity;
    private JobSkills jobSkillsEntity;
    private List<Jobs> jobsList;
    private List<JobDetails> jobDetailsList;
    private List<JobSkills> jobSkillsList;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_job);

        initToolbar();
        initUI();
        initObj();

    }

    private void initToolbar() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        TextView tvTitle = toolbar.findViewById(R.id.tvTitle);
        tvTitle.setText(Constants.SEARCH_JOB);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null)
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

    private void initUI() {
        rlSearchJobsLayout = findViewById(R.id.rlSearchJobsLayout);
        acSearch = findViewById(R.id.acSearch);
        ibSearch = findViewById(R.id.ibSearch);
        rvJobs = findViewById(R.id.rvJobs);
        tvNoData = findViewById(R.id.tvNoData);

        ibSearch.setOnClickListener(this);
    }

    private void initObj() {
        context = this;
        restAPI = new RestAPI();
        jsonParse = new JSONParse();
        entity = new Jobs();
        jobsList = new ArrayList<>();
        filterBy = Constants.ALL_JOBS;
    }

    @Override
    protected void onResume() {
        super.onResume();
        new AsyncGetAllJobs().execute();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @SuppressLint("NonConstantResourceId")
    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.ibSearch:
                onClickImageBtnSearch();
                break;
            case R.id.tvAllJobs:
                alertDialog.dismiss();
                filterBy = Constants.ALL_JOBS;
                searchJob();
                break;
            case R.id.tvJobName:
                alertDialog.dismiss();
                filterBy = Constants.JOB_NAME;
                searchJob();
                break;
            case R.id.tvSkills:
                alertDialog.dismiss();
                filterBy = Constants.SKILLS;
                searchJob();
                break;
            case R.id.tvCompany:
                alertDialog.dismiss();
                filterBy = Constants.COMPANY_FILTER;
                new AsyncSearchJobByParams().execute(filterBy,
                        acSearch.getText().toString());
                break;
            case R.id.tvSSCPercent:
                alertDialog.dismiss();
                filterBy = Constants.SSC_PERCENT;
                searchJob();
                break;
            case R.id.tvHSCPercent:
                alertDialog.dismiss();
                filterBy = Constants.HSC_PERCENT;
                searchJob();
                break;
            case R.id.tvGraduatePercent:
                alertDialog.dismiss();
                filterBy = Constants.GRADUATE_PERCENT;
                searchJob();
                break;
            case R.id.tvPostGraduatePercent:
                alertDialog.dismiss();
                filterBy = Constants.POST_GRADUATE_PERCENT;
                searchJob();
                break;
            case R.id.tvSpecialization:
                alertDialog.dismiss();
                filterBy = Constants.SPECIALIZATION;
                searchJob();
                break;
        }
    }

    private void searchJob() {
        if (filterBy.equalsIgnoreCase(Constants.ALL_JOBS)){
            new AsyncSearchJobByParams().execute(filterBy,"null");
        }else{
            if (!acSearch.getText().toString().trim().isEmpty()) {
                new AsyncSearchJobByParams().execute(filterBy, acSearch.getText().toString());
            } else {
                acSearch.setError("required");
                acSearch.requestFocus();
            }
        }

    }

    private void setUpRecyclerView() {
        SearchJobListAdapter searchJobListAdapter = new SearchJobListAdapter(this,
                jobsList);
        rvJobs.setAdapter(searchJobListAdapter);
        rvJobs.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL,
                false));
        searchJobListAdapter.notifyDataSetChanged();
    }

    public void onClickImageBtnSearch() {
        try {
            alertFilter = getLayoutInflater().inflate(R.layout.alert_filter, null);
            alertBuilder = new AlertDialog.Builder(this);
            if (alertFilter.getParent() != null) {
                ((ViewGroup) alertFilter.getParent()).removeView(alertFilter);
            }
            alertBuilder.setView(alertFilter);
            initPaymentAlertUI(alertFilter);
            alertDialog = alertBuilder.create();
        } catch (Exception exception) {
            exception.printStackTrace();
        }

        if (!alertDialog.isShowing())
            alertDialog = alertBuilder.show();
    }

    private void initPaymentAlertUI(View view) {
        alertTvAllJobs = view.findViewById(R.id.tvAllJobs);
        alertTvJobName = view.findViewById(R.id.tvJobName);
        alertTvSkills = view.findViewById(R.id.tvSkills);
        alertTvSkills = view.findViewById(R.id.tvSkills);
        alertTvCompany = view.findViewById(R.id.tvCompany);
        alertTvSSCPercent = view.findViewById(R.id.tvSSCPercent);
        alertTvHSCPercent = view.findViewById(R.id.tvHSCPercent);
        alertTvGraduatePercent = view.findViewById(R.id.tvGraduatePercent);
        alertTvPostGraduatePercent = view.findViewById(R.id.tvPostGraduatePercent);
        alertTvSpecialization = view.findViewById(R.id.tvSpecialization);
        alertBtnCancel = view.findViewById(R.id.alertBtnCancel);
        alertBtnCancel.setOnClickListener(this);
        alertTvAllJobs.setOnClickListener(this);
        alertTvJobName.setOnClickListener(this);
        alertTvSkills.setOnClickListener(this);
        alertTvCompany.setOnClickListener(this);
        alertTvSSCPercent.setOnClickListener(this);
        alertTvHSCPercent.setOnClickListener(this);
        alertTvGraduatePercent.setOnClickListener(this);
        alertTvPostGraduatePercent.setOnClickListener(this);
        alertTvSpecialization.setOnClickListener(this);
    }

    private void saveDataToEntityAndSetupRecyclerView(JSONObject json) {
        try {
            JSONArray jsonArray = json.getJSONArray("Data");
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObj = jsonArray.getJSONObject(i);
                entity.setJobId(jsonObj.getString("data0"));
                entity.setJobName(jsonObj.getString("data1"));
                entity.setDescription(jsonObj.getString("data2"));
                entity.setJobStartDate(jsonObj.getString("data4"));
                entity.setNoOfVacancy(jsonObj.getString("data5"));
                entity.setSummary(jsonObj.getString("data6"));
                entity.setJobCategory(jsonObj.getString("data8"));
                entity.setJobPlatform(jsonObj.getString("data9"));
                entity.setMinExperience(jsonObj.getString("data11"));
                entity.setMaxExperience(jsonObj.getString("data12"));
                entity.setRecruiterId(jsonObj.getString("data13"));
                entity.setCompanyName(jsonObj.getString("data15"));
                entity.setJobPositionName(jsonObj.getString("data18"));
                jobsList.add(entity);
                entity = new Jobs();
            }
            setUpRecyclerView();
        } catch (Exception exception) {
            exception.printStackTrace();
            Log.e(Constants.COMPANY, exception.getMessage());
        }
    }

    private void setDataToEntityAndSetAutoComplete(JSONObject json) {
        List<Jobs> jobsListAutoCompete = new ArrayList<>();
        Jobs jobEntity = new Jobs();
        try {
            JSONArray jsonArray = json.getJSONArray("Data");
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObj = jsonArray.getJSONObject(i);
                jobEntity.setJobName(jsonObj.getString("data1"));
                jobsListAutoCompete.add(jobEntity);
                jobEntity = new Jobs();
            }
            List<String> jobName = new ArrayList<>();
            for (Jobs job : jobsListAutoCompete) {
                jobName.add(job.getJobName());
            }
           ArrayAdapter<String> adapter = new ArrayAdapter<>
                    (this, android.R.layout.select_dialog_item, jobName);
            acSearch.setThreshold(1);
            acSearch.setAdapter(adapter);
            acSearch.setTextColor(Color.RED);

        } catch (Exception exception) {
            exception.printStackTrace();
            Log.e(Constants.COMPANY, exception.getMessage());
        }
    }

    private class AsyncSearchJobByParams extends AsyncTask<String, String, String> {
        private Dialog dialog;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            jobsList = new ArrayList<>();
            entity = new Jobs();
            rvJobs.setAdapter(null);
            dialog = DialogUtils.showLoadingDialog(context, Constants.PLEASE_WAIT);

        }

        @Override
        protected String doInBackground(String... strings) {
            String a;
            try {
                JSONObject json = restAPI.ViewFilteredJobs(strings[0], strings[1]);
                a = jsonParse.parse(json);
            } catch (Exception e) {
                a = e.getMessage();
            }
            return a;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            DialogUtils.dismissLoadingDialog(dialog);
            try {
                if (Utility.checkConnection(s)) {
                    Pair<String, String> pair = Utility.GetErrorMessage(s);
                    Utility.ShowAlertDialog(context, pair.first, pair.second, false);
                } else {
                    //main
                    JSONObject json = new JSONObject(s);

                    //string value
                    String jsonString = json.getString("status");

                    if (jsonString.compareToIgnoreCase("no") == 0) {
                        Helper.makeSnackBar(rlSearchJobsLayout, "No Data found");

                    } else if (jsonString.compareToIgnoreCase("ok") == 0) {
                        tvNoData.setVisibility(View.GONE);
                        rvJobs.setVisibility(View.VISIBLE);
                        saveDataToEntityAndSetupRecyclerView(json);
                    } else {
                        Helper.makeSnackBar(rlSearchJobsLayout, "Something Went Wrong");
                    }

                }
            } catch (Exception e) {
                Helper.makeSnackBar(rlSearchJobsLayout, "Something Went Wrong");
            }
        }


    }

    private class AsyncGetAllJobs extends AsyncTask<String, String, String> {

        private Dialog dialog;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            jobsList = new ArrayList<>();
            entity = new Jobs();
            rvJobs.setAdapter(null);
            dialog = DialogUtils.showLoadingDialog(context, Constants.PLEASE_WAIT);

        }

        @Override
        protected String doInBackground(String... strings) {
            String a;
            try {
                JSONObject json = restAPI.GetAllJobs();
                a = jsonParse.parse(json);
            } catch (Exception e) {
                a = e.getMessage();
            }
            return a;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            DialogUtils.dismissLoadingDialog(dialog);
            try {
                if (Utility.checkConnection(s)) {
                    Pair<String, String> pair = Utility.GetErrorMessage(s);
                    Utility.ShowAlertDialog(context, pair.first, pair.second, false);
                } else {
                    //main
                    JSONObject json = new JSONObject(s);

                    //string value
                    String jsonString = json.getString("status");

                    if (jsonString.compareToIgnoreCase("no") == 0) {
                    } else if (jsonString.compareToIgnoreCase("ok") == 0) {
                        setDataToEntityAndSetAutoComplete(json);
                    }

                }
            } catch (Exception e) {
                Helper.makeSnackBar(rlSearchJobsLayout, "Something Went Wrong");
            }
        }

    }

}